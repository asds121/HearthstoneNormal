"use strict";
hearthstone.use(function(lib, game, ui, get, ai, _status) {
    var funcs = {
        HSline: function(player, target, config) {
            if (!get.HSVV()
                .anif) player.line(target);
            else {
                if (get.itemtype(target) == "players") {
                    target.forEach(t => player.HSline(t, config));
                } else {
                    if (target == player) return;
                    if (target && target.tagName.toLocaleLowerCase() == 'div') {
                        var from = [player.offsetLeft + player.offsetWidth / 2, player.offsetTop + player.offsetHeight / 2];
                        var to = [target.offsetLeft + target.offsetWidth / 2, target.offsetTop + target.offsetHeight / 2];
                        get.HSF("lineHS", ["金龙指示线", ui.arena, false, [from, to]]);
                    }
                }
            }
        },
        loadHS: function() {
            get.HSVV()
                .anif = {};
            var animations = ["金龙指示线"];
            var folders1 = [];
            game.getFileList(get.HSA("animationpath")
                .slice(0, -1), function(folders, files) {
                for (var i = 0; i < folders.length; i++) {
                    var folder = folders[i];
                    if (animations.contains(folder)) folders1.push(folder);
                };
                var loadImage = function() {
                    var folder = folders1[0];
                    game.getFileList(get.HSA("animationpath") + folder, function(folders, files) {
                        var type = '.jpg';
                        var num = files.length;
                        for (var i = 0; i < files.length; i++) {
                            var file = files[i];
                            if (file == 'line.png') num--;
                        };
                        if (get.HSVV("anif")[folder] == undefined || (get.HSVV("anif")[folder] != undefined && get.HSVV("anif")[folder].num != num)) {
                            for (var i = 0; i < files.length; i++) {
                                var file = files[i];
                                if (file.indexOf('.jpg') != -1) {
                                    type = '.jpg';
                                } else if (file.indexOf('.JPG') != -1) {
                                    type = '.JPG';
                                } else if (file.indexOf('.png') != -1) {
                                    type = '.png';
                                } else if (file.indexOf('.PNG') != -1) {
                                    type = '.PNG';
                                } else {
                                    continue;
                                };
                                var img = document.createElement('img');
                                img.src = lib.assetURL + get.HSA("animationpath") + folder + '/' + file;
                                img.style.display = "none";
                                document.body.appendChild(img);
                            };
                            get.HSVV("anif")[folder] = {
                                type: type,
                                num: num,
                            };
                        };
                        folders1.remove(folder);
                        if (folders1.length > 0) loadImage();
                    });
                };
                if (folders1.length > 0) loadImage();
            });
        },
        lineHS: function(name, node, fake, points) {
            if (!get.HSVV()
                .anif) {
                alert("指示线特效没有打开，请联系一条咸鱼解决");
                return;
            }
            var animation = get.HSA("line");
            if (_status.kzol_onAnimation == undefined) _status.kzol_onAnimation = 0;
            _status.kzol_onAnimation++;
            var src;
            src = get.HSA("animationpath") + name + '?' + new Date()
                .getTime();
            var finish = function() {
                var animationID;
                var timeoutID;
                var interval;
                var div = ui.create.div();
                node.appendChild(div);
                div.style.width = animation.width;
                div.style.height = animation.height;
                div.style.backgroundSize = animation.backgroundSize;
                div.style.opacity = animation.opacity;
                div.style.zIndex = 1001;
                div.style.boHSerRadius = '5px';
                div.style['pointer-events'] = 'none';
                if (src != undefined) {
                    var type_frame1 = 0;
                    var type_frame = '.jpg';
                    var num_frame = 1;
                    if (get.HSVV("anif")[name] != undefined) {
                        type_frame = get.HSVV("anif")[name].type;
                        num_frame = get.HSVV("anif")[name].num;
                    };
                    var folder_frame = lib.assetURL + get.HSA("animationpath") + name + '/';
                    var div1 = ui.create.div();
                    div1.style.height = '100%';
                    div1.style.width = '100%';
                    div1.style.top = '0px';
                    div1.style.left = '0px';
                    div.appendChild(div1);
                    var play = function() {
                        if (type_frame1 >= num_frame) return;
                        div1.innerHTML = "<img width=100% height=100% src='" + folder_frame + type_frame1 + type_frame + "'></img>";
                        type_frame1++;
                        if (type_frame1 >= num_frame) type_frame1 = 0;
                    };
                    interval = setInterval(play, 1000 / 18);
                };

                div.style.top = (points[0][1] - div.offsetHeight / 2) + 'px';
                div.style.left = (points[0][0]) + 'px';
                var timeS = ((animation.fade == true ? animation.time - 450 : animation.time - 100) / 1000) / 2;
                var getAngle = function(x1, y1, x2, y2, bool) {
                    var x = x1 - x2;
                    var y = y1 - y2;
                    var z = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
                    var cos = y / z;
                    var radina = Math.acos(cos);
                    var angle = 180 / (Math.PI / radina);
                    if (x2 > x1 && y2 === y1) angle = 0;
                    if (x2 > x1 && y2 < y1) angle = angle - 90;
                    if (x2 === x1 && y1 > y2) angle = -90;
                    if (x2 < x1 && y2 < y1) angle = 270 - angle;
                    if (x2 < x1 && y2 === y1) angle = 180;
                    if (x2 < x1 && y2 > y1) angle = 270 - angle;
                    if (x2 === x1 && y2 > y1) angle = 90;
                    if (x2 > x1 && y2 > y1) angle = angle - 90;
                    if (bool == true && angle > 90) angle -= 180;
                    return angle;
                };
                var p1 = points[0];
                var p2 = points[1];
                var x0 = p1[0];
                var y0 = p1[1];
                var x1 = p2[0];
                var y1 = p2[1];
                div.style.transition = 'all 0s';
                div.style.transform = 'rotate(' + getAngle(x0, y0, x1, y1, true) + 'deg)' + (x0 > x1 ? '' : ' rotateY(180deg)');
                div.style['transform-origin'] = '0 50%';
                var div2 = ui.create.div();
                /*我添加的*/
                div2.hide();
                div2.style.zIndex = 1000;
                div2.style['pointer-events'] = 'none';
                div2.style.height = '20px';
                div2.style.width = (Math.pow(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2), 0.5) + 2) + 'px';
                div2.style.left = (x0) + 'px';
                div2.style.top = (y0 - 10) + 'px';
                div2.style.transform = 'rotate(' + getAngle(x0, y0, x1, y1) + 'deg) scaleX(0)';
                div2.style['transform-origin'] = '0 50%';
                div2.style.transition = 'all ' + (timeS * 4 / 3) + 's';
                if (src != undefined && name.indexOf('.') == -1) {
                    div2.style.backgroundSize = '100% 100%';
                    div2.setBackgroundImage(get.HSA("animationpath") + name + '/line.png');
                } else {
                    div2.style.background = '#ffffff';
                };
                /*我添加的*/
                setTimeout(function() {
                    div2.show()
                }, 100);
                setTimeout(function() {
                    div.style.transition = 'all ' + (timeS * 4 / 3) + 's';
                    div.style.transform += ' translateX(' + (-(Math.pow(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2), 0.5) + 2)) + 'px)';
                    div2.style.transform = 'rotate(' + getAngle(x0, y0, x1, y1) + 'deg) scaleX(1)';
                }, 50);
                setTimeout(function() {
                    div2.style.transition = 'all ' + (timeS * 2 / 3) + 's';
                    div2.style.transform = 'rotate(' + getAngle(x0, y0, x1, y1) + 'deg) translateX(' + (Math.pow(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2), 0.5) + 2 - Math.pow(Math.pow(div.offsetHeight / 2, 2) + Math.pow(div.offsetWidth / 2, 2), 0.5)) + 'px) scaleX(0.01)';
                }, 50 + timeS * 4 / 3 * 1000);
                node.appendChild(div2);
                if (animation.fade == true) {
                    if (div2 != undefined) {
                        setTimeout(function() {
                            div2.hide();
                        }, animation.time - 350);
                        setTimeout(function() {
                            div.hide();
                        }, animation.time - 400);
                    } else {
                        setTimeout(function() {
                            div.hide();
                        }, animation.time - 350);
                    };
                };
                setTimeout(function() {
                    if (interval != undefined) clearInterval(interval);
                    if (timeoutID != undefined) clearTimeout(timeoutID);
                    if (animationID != undefined) cancelAnimationFrame(animationID);
                    node.removeChild(div);
                    if (div2 != undefined) node.removeChild(div2);
                    _status.kzol_onAnimation--;
                }, animation.time);
            };
            setTimeout(finish, 1);
        },
    };
    for (var i in funcs) {
        hearthstone.funcs[i] = funcs[i];
    }
    hearthstone.player.HSline = function(target, config) {
        get.HSF("HSline", [this, target, config]);
    };
});