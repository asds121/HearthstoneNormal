	"use strict";
	hearthstone.cardPack = {
	    monsterRD: {
	        "River Crocolisk": ["淡水鳄", "essential",
	            "“左撇子”爱德华·史密斯曾经试着从一条淡水鳄的嘴里把行李夺回来。", ["HS_normal", "2", "", "wildbeast", "2", "3"]],
	        "Murloc Raider": ["鱼人袭击者", "essential",
	            "姆啦啦咯哈姆噶啊啊嘎，姆啦嘎嘎咯，啵啦啦嗯嘞噶哈，姆啦嗝，咯啦哈哈吧啦咯。加尔鲁什咯嘛啦喝，嘛啦咯呵！", ["HS_normal", "1", "", "murloc", "2", "1"]],
	        "Murloc Tidehunter": ["鱼人猎潮者", "essential",
	            "战吼：召唤一个1/1的鱼人斥候。", ["HS_effect", "2", "", "murloc", "2", "1"],
	            ["battleRoal:鱼人斥候"]
	        ],
	        "Murloc Scout": ["鱼人斥候", "essential", "", ["HS_normal", "1", "", "murloc", "1", "1"],
	            ["token"]
	        ],
	        "Goldshire Footman": ["闪金镇步兵", "essential",
	            "嘲讽", ["HS_effect", "1", "", "none", "1", "2"]],
	        "Wolfrider": ["狼骑兵", "essential",
	            "冲锋", ["HS_effect", "3", "", "none", "3", "1"]],
	        "Annoy Tron": ["吵吵机器人", "ordinary",
	            "嘲讽，圣盾", ["HS_effect", "2", "", "machine", "1", "2"]],
	        "Raging Worgen": ["暴怒的狼人", "ordinary",
	            "激怒：+1攻击力并具有风怒。", ["HS_effect", "3", "", "none", "3", "3"]],
	        "Cruel Taskmaster": ["严酷的监工", "ordinary",
	            "战吼：对一个随从造成1点伤害，并使其获得+2攻击力。", ["HS_effect", "2", "hs_warrior", "none", "2", "2"],
	            ['battleRoal:buff>A2,d1']
	        ],
	        "Stonetusk Boar": ["石牙野猪", "essential",
	            "冲锋", ["HS_effect", "1", "", "wildbeast", "1", "1"]],
	        "Frostwolf Grunt": ["霜狼步兵", "essential",
	            "嘲讽", ["HS_effect", "2", "", "none", "2", "2"]],
	        "Archmage Antonidas": ["大法师安东尼达斯", "legend", "每当你施放一个法术，便将一张火球术置入你的手牌。", ["HS_effect", "7", "hs_mage", "none", "5", "7"],
	            ["legend"]
	        ],
	        "Ragnaros the Firelord": ["炎魔之王拉格纳罗斯", "legend", "无法攻击。在你的回合结束时，随机对一个敌人造成8点伤害。", ["HS_effect", "8", "", "none", "8", "8"],
	            ["legend", "anm:fireatk"]
	        ],
	        "Argent Squire": ["银色侍从", "ordinary", "圣盾", ["HS_effect", "1", "", "none", "1", "1"]],
	        "Injured Blademaster": ["负伤剑圣", "rare", "战吼：对自身造成4点伤害。", ["HS_effect", "3", "", "none", "4", "7"]],
	        "Socerer s Apprentice": ["巫师学徒", "ordinary", "你的法术的法力值消耗减少（1）点。", ["HS_effect", "2", "hs_mage", "none", "3", "2"]],
	        "Worgen Infiltrator": ["狼人渗透者", "ordinary", "潜行", ["HS_effect", "1", "", "none", "2", "1"]],
	        "Doomsayer": ["末日预言者", "epic", "在你的回合开始时，消灭所有随从。", ["HS_effect", "2", "", "none", "0", "7"]],
	        "Mana Wyrm": ["法力浮龙", "ordinary", "每当你施放一个法术，便获得+1攻击力。", ["HS_effect", "1", "hs_mage", "none", "1", "3"]],
	        "Bloodmage Thalnos": ["血法师萨尔诺斯", "legend", "法术伤害+1，亡语：抽一张牌。", ["HS_effect", "2", "", "none", "1", "1"],
	            ["legend"]
	        ],
	        "Malygos": ["玛里苟斯", "legend", "法术伤害+5", ["HS_effect", "9", "", "dragon", "4", "12"],
	            ["legend"]
	        ],
	        "Unstable Ghoul": ["蹒跚的食尸鬼", "ordinary", "嘲讽，亡语：对所有随从造成1点伤害。", ["HS_effect", "2", "", "none", "1", "3"]],
	        "Water Elemental": ["水元素", "essential", "冻结任何受到该随从伤害的角色。", ["HS_effect", "4", "hs_mage", "none", "3", "6"]],
	        "Brann Bronzebeard": ["布莱恩·铜须", "legend", "你的战吼会触发两次。", ["HS_effect", "3", "", "none", "2", "4"],
	            ["legend", "skillgh:doublebattleroal"]
	        ],
	        "Grommash Hellscream": ["格罗玛什·地狱咆哮", "legend", "冲锋，激怒：+6攻击力。", ["HS_effect", "8", "hs_warrior", "none", "4", "9"],
	            ["legend"]
	        ],
	        "Snowchugger": ["碎雪机器人", "ordinary", "冻结任何受到该随从伤害的角色。", ["HS_effect", "2", "hs_mage", "machine", "2", "3"]],
	        "Azure Drake": ["碧蓝幼龙", "rare", "法术伤害+1，战吼：抽一张牌。", ["HS_effect", "5", "", "dragon", "4", "4"]],
	        "Argent Commander": ["银色指挥官", "rare", "冲锋，圣盾", ["HS_effect", "6", "", "", "4", "2"]],
	        "Elven Archer": ["精灵弓箭手", "essential", "战吼：造成1点伤害。", ["HS_effect", "1", "", "none", "1", "1"]],
	        "Leper Gnome": ["麻风侏儒", "ordinary", "亡语：对敌方英雄造成2点伤害。", ["HS_effect", "1", "", "none", "2", "1"]],
	        "Abusive Sergeant": ["叫嚣的中士", "ordinary", "战吼：在本回合中，使一个随从获得+2攻击力。", ["HS_effect", "1", "", "none", "2", "1"]],
	        "Flame Imp": ["烈焰小鬼", "ordinary", "战吼：对你的英雄造成3点伤害。", ["HS_effect", "1", "hs_warlock", "demon", "3", "2"],
	            ["anm:fireatk"]
	        ],
	        "Voidwalker": ["虚空行者", "essential", "嘲讽", ["HS_effect", "1", "hs_warlock", "demon", "1", "3"]],
	        "Zombie Chow": ["肉用僵尸", "ordinary", "亡语：为敌方英雄恢复5点生命值。", ["HS_effect", "1", "", "none", "2", "3"]],
	        "Doomguard": ["末日守卫", "rare", "冲锋，战吼：随机弃两张牌。", ["HS_effect", "5", "hs_warlock", "demon", "5", "7"]],
	        "Knife Juggler": ["飞刀杂耍者", "rare", "在你召唤一个随从后，随机对一个敌人造成1点伤害。", ["HS_effect", "2", "", "none", "3", "2"]],
	        "Nerubian Egg": ["蛛魔之卵", "rare", "亡语：召唤一个4/4的蛛魔。", ["HS_effect", "2", "", "none", "0", "2"],
	            ["deathRattle:蛛魔"]
	        ],
	        "Nerubian": ["蛛魔", "essential", "", ["HS_normal", "4", "", "none", "4", "4"],
	            ["token"]
	        ],
	        "Dr boom": ["砰砰博士", "legend", "战吼： 召唤两个1/1的砰砰机器人。警告：该机器人随时可能爆炸。", ["HS_effect", "7", "", "none", "7", "7"],
	            ["legend", "battleRoal:['砰砰机器人',2]"]
	        ],
	        "Boom Bot": ["砰砰机器人", "essential", "亡语：随机对一个敌人造成1-4点伤害。", ["HS_effect", "1", "", "machine", "1", "1"],
	            ["tokened"]
	        ],
	        "Confessor Paletress": ["银色神官帕尔崔丝", "legend", "激励：随机召唤一个传说随从。", ["HS_effect", "7", "hs_priest", "none", "5", "4"],
	            ["legend", "jili:['range:传说']"]
	        ],
	        "Onyxia": ["奥妮克希亚", "legend", "战吼：召唤数条1/1的雏龙，直到你的随从数量达到上限。", ["HS_effect", "9", "", "dragon", "8", "8"],
	            ["legend", "battleRoal:['雏龙',7]"]
	        ],
	        "Whelp": ["雏龙", "essential", "", ["HS_normal", "1", "", "dragon", "1", "1"],
	            ["tokened"]
	        ],
	        "Auchenai Soulpriest": ["奥金尼灵魂祭司", "rare", "你的恢复生命值的牌和技能改为造成等量的伤害。", ["HS_effect", "4", "hs_priest", "none", "3", "5"],
	            ["skillgh:auchenai"]
	        ],
	        "Prophet Velen": ["先知维伦", "legend", "使你的法术和英雄技能的伤害和治疗效果翻倍。", ["HS_effect", "7", "hs_priest", "none", "7", "7"],
	            ["legend", "skillgh:velen"]
	        ],
	        "Nefarian": ["奈法利安", "legend", "战吼：随机将两张（你对手职业的）法术牌置入你的手牌。", ["HS_effect", "9", "", "dragon", "8", "8"],
	            ["legend"]
	        ],
	        "Illidan Stormrage": ["伊利丹·怒风", "legend", "每当你使用一张牌时，召唤一个2/1的埃辛诺斯之焰。", ["HS_effect", "6", "", "demon", "7", "5"],
	            ["legend", "useCard:埃辛诺斯之焰"]
	        ],
	        "Flame of Azzinoth": ["埃辛诺斯之焰", "essential", "", ["HS_normal", "1", "", "none", "2", "1"],
	            ["token"]
	        ],
	        "Haunted Creeper": ["鬼灵爬行者", "ordinary", "亡语：召唤两只1/1的鬼灵蜘蛛。", ["HS_effect", "2", "", "wildbeast", "1", "2"],
	            ["deathRattle:['鬼灵蜘蛛',2]"]
	        ],
	        "Spectral Spider": ["鬼灵蜘蛛", "essential", "", ["HS_normal", "1", "", "none", "1", "1"],
	            ["tokened"]
	        ],
	        "Imp Gang Boss": ["小鬼首领", "ordinary", "每当该随从受到伤害，召唤一个1/1的小鬼。", ["HS_effect", "3", "hs_warlock", "demon", "2", "4"],
	            ["hsdmg:小鬼"]
	        ],
	        "Imp": ["小鬼", "essential", "", ["HS_normal", "1", "hs_warlock", "demon", "1", "1"],
	            ["tokened"]
	        ],
	        "Defender of Argus": ["阿古斯防御者", "rare", "战吼：使相邻的随从获得+1/+1和嘲讽。", ["HS_effect", "4", "", "none", "2", "3"]],
	        "Grim Patron": ["恐怖的奴隶主", "rare", "在该随从受到伤害并没有死亡后，召唤另一个恐怖的奴隶主。", ["HS_effect", "5", "", "none", "3", "3"]],
	        "Acolyte of Pain": ["苦痛侍僧", "ordinary", "每当该随从受到伤害，抽一张牌。", ["HS_effect", "3", "", "none", "1", "3"]],
	        "Warsong Commander": ["战歌指挥官", "essential", "每当你召唤一个攻击力小于或等于3的随从，使其获得冲锋。", ["HS_effect", "3", "hs_warrior", "none", "2", "3"]],
	        "Deathwing": ["死亡之翼", "legend", "战吼： 消灭所有其他随从，并弃掉你的手牌。", ["HS_effect", "10", "", "dragon", "12", "12"],
	            ["legend"]
	        ],
	        "Leokk": ["雷欧克", "essential", "你的其他随从获得+1攻击力。", ["HS_effect", "3", "hs_hunter", "wildbeast", "2", "4"],
	            ["token"]
	        ],
	        "Huffer": ["霍弗", "essential", "冲锋", ["HS_effect", "3", "hs_hunter", "wildbeast", "4", "2"],
	            ["token"]
	        ],
	        "Misha": ["米莎", "essential", "嘲讽", ["HS_effect", "3", "hs_hunter", "wildbeast", "4", "4"],
	            ["token"]
	        ],
	        "Dire Wolf Alpha": ["恐狼前锋", "ordinary", "相邻的随从获得+1攻击力。", ["HS_effect", "2", "", "wildbeast", "2", "2"]],
	        "Mal Ganis": ["玛尔加尼斯", "legend", "你的其他恶魔获得+2/+2。你的英雄获得免疫。", ["HS_effect", "9", "hs_warlock", "demon", "9", "7"],
	            ["legend"]
	        ],
	        "Silverback Patriarch": ["银背族长", "essential",
	            "嘲讽", ["HS_effect", "3", "", "wildbeast", "1", "4"]],
	        "Fierce Monkey": ["凶暴猿猴", "ordinary",
	            "嘲讽", ["HS_effect", "3", "hs_warrior", "wildbeast", "3", "4"]],
	        "Murloc Warleader": ["鱼人领军", "epic", "所有其他鱼人获得+2/+1。", ["HS_effect", "3", "", "murloc", "3", "3"]],
	        "Grimscale Oracle": ["暗鳞先知", "essential", "所有其他鱼人获得+1攻击力。", ["HS_effect", "1", "", "murloc", "1", "1"]],
	        "Murloc Tinyfin": ["鱼人宝宝", "ordinary", "鱼人宝宝实在是太可爱了，以至于谁见了都想抱一抱，结果因窒息所导致的死亡率极高。", ["HS_normal", "0", "", "murloc", "1", "1"]],
	        "Bluegill Warrior": ["蓝腮战士", "ordinary", "冲锋", ["HS_effect", "2", "", "murloc", "2", "1"]],
	        "Old Murk Eye": ["老瞎眼", "legend", "冲锋，在战场上每有一个其他鱼人便获得+1攻击力。", ["HS_effect", "4", "", "murloc", "2", "4"],
	            ["legend"]
	        ],
	        "Murloc Knight": ["鱼人骑士", "ordinary",
	            "激励：随机召唤一个鱼人。", ["HS_effect", "4", "hs_paladin", "murloc", "3", "4"],
	            ["jili:['range:鱼人']"]
	        ],
	        "Boar1": ["野猪", "essential", "冲锋", ["HS_effect", "3", "", "wildbeast", "4", "2"],
	            ["tokened", "nosearch"]
	        ],
	        "Mounted Raptor": ["骑乘迅猛龙", "ordinary", "亡语：随机召唤一个法力值消耗为（1）的随从。", ["HS_effect", "3", "hs_druid", "wildbeast", "3", "2"]],
	        "Enhance O Mechano": ["强化机器人", "epic", "战吼：随机使你的其他随从分别获得风怒，嘲讽，或者圣盾效果中的一种。", ["HS_effect", "4", "", "machine", "3", "2"]],
	        "Piloted Shredder": ["载人收割机", "ordinary", "亡语：随机召唤一个法力值消耗为（2）的随从。", ["HS_effect", "4", "", "machine", "4", "3"]],
	        "Piloted Sky Golem": ["载人飞天魔像", "epic", "亡语：随机召唤一个法力值消耗为（4）的随从。", ["HS_effect", "6", "", "machine", "6", "4"]],
	        "Faerie Dragon": ["精灵龙", "ordinary", "无法成为法术或英雄技能的目标。", ["HS_effect", "2", "", "dragon", "3", "2"]],
	        "Spectral Knight": ["鬼灵骑士", "ordinary", "无法成为法术或英雄技能的目标。", ["HS_effect", "5", "", "none", "4", "6"]],
	        "Arcane Nullifier X21": ["施法者克星X-21", "rare", "嘲讽，无法成为法术或英雄技能的目标。", ["HS_effect", "4", "", "machine", "2", "5"]],
	        "Wee Spellstopper": ["小个子扰咒师", "epic", "相邻的随从无法成为法术或英雄技能的目标。", ["HS_effect", "4", "hs_mage", "none", "2", "5"]],
	        "Sunfury Protector": ["日怒保卫者", "rare", "战吼：使相邻的随从获得嘲讽。", ["HS_effect", "2", "", "none", "2", "3"]],
	        "Tauren Warrior": ["牛头人战士", "ordinary", "嘲讽，激怒：+3攻击力。", ["HS_effect", "3", "", "none", "2", "3"]],
	        "Webspinner": ["结网蛛", "ordinary", "亡语：随机将一张野兽牌置入你的手牌。", ["HS_effect", "1", "hs_hunter", "wildbeast", "1", "1"],
	            ["deathRattle:rangain>野兽"]
	        ],
	        "Gormok the Impaler": ["穿刺者戈莫克", "legend", "战吼：如果你拥有至少四个其他随从，则造成4点伤害。", ["HS_effect", "4", "", "none", "4", "4"],
	            ["legend", "rareEff"]
	        ],
	        "Aviana": ["艾维娜", "legend", "你的随从牌的法力值消耗为（1）点。", ["HS_effect", "9", "hs_druid", "none", "5", "5"],
	            ["legend", "quetu"]
	        ],
	        "Leeroy Jenkins": ["火车王里诺艾", "legend", "冲锋，战吼：为你的对手召唤两条1/1的雏龙。", ["HS_effect", "5", "", "none", "6", "2"],
	            ["legend", "battleRoal:['雏龙',2],true"]
	        ],
	        "the Beast": ["比斯巨兽", "legend", "亡语：为你的对手召唤1个3/3的芬克·恩霍尔。", ["HS_effect", "6", "", "wildbeast", "9", "7"],
	            ["legend", "deathRattle:['芬克'],true"]
	        ],
	        "Finkle Einhorn": ["芬克·恩霍尔", "legend", "", ["HS_normal", "3", "", "none", "3", "3"],
	            ["legend", "token"]
	        ],
	        "Silvermoon Guardian": ["银月城卫兵", "ordinary", "圣盾", ["HS_effect", "4", "", "none", "3", "3"]],
	        "Scarlet Crusader": ["血色十字军战士", "ordinary", "圣盾", ["HS_effect", "3", "", "none", "3", "1"]],
	        "Shieldbearer": ["持盾卫士", "ordinary", "嘲讽", ["HS_effect", "1", "", "none", "0", "4"]],
	        "MWarden": ["魔古山守望者", "ordinary", "嘲讽", ["HS_effect", "4", "", "none", "1", "7"]],
	        "Young Dragonhawk": ["幼龙鹰", "ordinary", "风怒", ["HS_effect", "1", "", "wildbeast", "1", "1"]],
	        "RAssassin": ["拉文霍德刺客", "rare", "潜行", ["HS_effect", "7", "", "none", "7", "5"]],
	        "JPanther": ["丛林猎豹", "ordinary", "潜行", ["HS_effect", "3", "", "wildbeast", "4", "2"]],
	        "Stranglethorn Tiger": ["荆棘谷猛虎", "ordinary", "潜行", ["HS_effect", "5", "", "wildbeast", "5", "5"]],
	        "Fen": ["沼泽爬行者", "ordinary", "嘲讽", ["HS_effect", "5", "", "none", "3", "6"]],
	        "Venture Co Mercenary": ["风险投资公司雇佣兵", "ordinary", "你的随从牌的法力值消耗增加（3）点。", ["HS_effect", "5", "", "none", "7", "6"]],
	        "Baron Geddon": ["迦顿男爵", "legend", "在你的回合结束时，对所有其他角色造成2点伤害。", ["HS_effect", "7", "", "none", "7", "5"],
	            ["legend"]
	        ],
	        "King Krush": ["暴龙王克鲁什", "legend", "冲锋", ["HS_effect", "9", "hs_hunter", "wildbeast", "8", "8"],
	            ["legend"]
	        ],
	        "Savannah Highmane": ["长鬃草原狮", "rare", "亡语：召唤两只2/2的土狼。", ["HS_effect", "6", "hs_hunter", "wildbeast", "6", "5"],
	            ["deathRattle:['土狼',2]"]
	        ],
	        "Hyena": ["土狼", "essential", "", ["HS_normal", "2", "hs_hunter", "wildbeast", "2", "2"],
	            ["tokened"]
	        ],
	        "Gahzrilla": ["加兹瑞拉", "legend", "每当该随从受到伤害，便使其攻击力翻倍。", ["HS_effect", "7", "hs_hunter", "wildbeast", "6", "9"],
	            ["legend"]
	        ],
	        "Timber Wolf": ["森林狼", "essential", "你的其他野兽获得+1攻击力。", ["HS_effect", "1", "hs_hunter", "wildbeast", "1", "1"]],
	        "Tundra Rhino": ["苔原犀牛", "essential", "你的野兽获得冲锋。", ["HS_effect", "5", "hs_hunter", "wildbeast", "2", "5"]],
	        "Northshire Cleric": ["北郡牧师", "ordinary", "每当一个随从获得治疗时，抽一张牌。", ["HS_effect", "1", "hs_priest", "none", "1", "3"]],
	        "Silver Hand Recruit": ["白银之手新兵", "essential", "", ["HS_normal", "1", "hs_paladin", "none", "1", "1"],
	            ["token"]
	        ],
	        "Aldor Peacekeeper": ["奥尔多卫士", "rare", "战吼：使一个敌方随从的攻击力变为1。", ["HS_effect", "3", "hs_paladin", "none", "3", "3"],
	            ["battleRoal:embuff>a1"]
	        ],
	        "Treant1": ["树人", "essential", "冲锋，在回合结束时，消灭该随从。", ["HS_effect", "1", "hs_druid", "none", "2", "2"],
	            ["token", "nosearch"]
	        ],
	        "Flame Waker": ["火妖", "rare", "在你施放一个法术后，造成2点伤害，随机分配到所有敌人身上。", ["HS_effect", "3", "hs_mage", "none", "2", "4"]],
	        "Molten Giant": ["熔核巨人", "epic", "你的英雄每受到1点伤害，该牌的法力值消耗便减少（1）点。", ["HS_effect", "20", "", "none", "8", "8"],
	            ["changecost:return p.getDamagedHp();"]
	        ],
	        "Sea Giant": ["海巨人", "epic", "战场上每有一个其他随从，该牌的法力值消耗便减少（1）点。", ["HS_effect", "10", "", "none", "8", "8"],
	            ["changecost:return p.sctp('mns').length;"]
	        ],
	        "Clockwork Giant": ["发条巨人", "epic", "你的对手每有一张手牌，该牌的法力值消耗便减少（1）点。", ["HS_effect", "12", "", "machine", "8", "8"],
	            ["changecost:return p.getOppo().countCards('h');"]
	        ],
	        "Mountain Giant": ["山岭巨人", "epic", "你每有一张其他手牌，该牌的法力值消耗便减少（1）点。", ["HS_effect", "12", "", "none", "8", "8"],
	            ["changecost:return p.countCards('h')-1;"]
	        ],
	        "Frost Giant": ["冰霜巨人", "epic", "在本局对战中，每当你使用一次英雄技能，该牌的法力值消耗便减少（1）点。", ["HS_effect", "10", "", "none", "8", "8"],
	            ["changecost:return p.hs_state.hrsk;"]
	        ],
	        "Mirror Image": ["镜像", "essential", "嘲讽", ["HS_effect", "0", "hs_mage", "none", "0", "2"],
	            ["token"]
	        ],
	        "Jeeves": ["基维斯", "rare", "在每个玩家的回合结束时，该玩家抽若干牌，直至其手牌数量达到3张。", ["HS_effect", "4", "", "machine", "1", "4"]],
	        "Wisp": ["小精灵", "ordinary", "如果你用足够多的小精灵攻击艾瑞达领主的话，他就会爆炸。但这是为什么呢？", ["HS_normal", "0", "", "none", "1", "1"]],
	        "Target Dummy": ["活动假人", "rare", "嘲讽", ["HS_effect", "0", "", "machine", "0", "2"]],
	        "Chillwind Yeti": ["冰风雪人", "essential",
	            "他梦想着有一天能够下山开一间拉面店。但他没有那个勇气。", ["HS_normal", "4", "", "none", "4", "5"]],
	        "Twilight Whelp": ["暮光雏龙", "ordinary", "战吼：如果你的手牌中有龙牌，便获得+2生命值。", ["HS_effect", "1", "hs_priest", "dragon", "2", "1"],
	            ["rareEff"]
	        ],
	        "Wyrmrest Agent": ["龙眠教官", "rare", "战吼：如果你的手牌中有龙牌，便获得+1攻击力和嘲讽。", ["HS_effect", "2", "hs_priest", "none", "1", "4"],
	            ["rareEff"]
	        ],
	        "Twilight Guardian": ["暮光守护者", "epic", "战吼：如果你的手牌中有龙牌，便获得+1攻击力和嘲讽。", ["HS_effect", "4", "", "dragon", "2", "6"],
	            ["rareEff"]
	        ],
	        "Blackwing Corruptor": ["黑翼腐蚀者", "ordinary", "战吼：如果你的手牌中有龙牌，则造成3点伤害。", ["HS_effect", "5", "", "none", "5", "4"],
	            ["rareEff"]
	        ],
	        "Blackwing Technician": ["黑翼技师", "ordinary", "战吼：如果你的手牌中有龙牌，便获得+1/+1。", ["HS_effect", "3", "", "none", "2", "4"],
	            ["rareEff"]
	        ],
	        "Dragonkin Sorcerer": ["龙人巫师", "ordinary", "每当你以该随从为目标施放一个法术时，便获得+1/+1。", ["HS_effect", "4", "", "dragon", "3", "5"]],
	        "Drakonid Crusher": ["龙人打击者", "ordinary", "战吼：如果你对手的生命值小于或等于15点，便获得+3/+3。", ["HS_effect", "6", "", "dragon", "6", "6"],
	            ["rareEff"]
	        ],
	        "Wild Pyromancer": ["狂野炎术师", "rare", "在你施放一个法术后，对所有随从造成1点伤害。", ["HS_effect", "2", "", "none", "3", "2"]],
	        "Alexstrasza": ["阿莱克丝塔萨", "legend", "战吼：将一方英雄的剩余生命值变为15。", ["HS_effect", "9", "", "dragon", "8", "8"],
	            ["legend"]
	        ],
	        "Frothing Berserker": ["暴乱狂战士", "rare", "每当一个随从受到伤害，便获得+1攻击力。", ["HS_effect", "3", "hs_warrior", "none", "2", "4"]],
	        "Armor Smith": ["铸甲师", "rare", "每当一个友方随从受到伤害，便获得1点护甲值。", ["HS_effect", "2", "hs_warrior", "none", "1", "4"]],
	        "Loot Hoarder": ["战利品贮藏者", "ordinary", "亡语：抽一张牌。", ["HS_effect", "2", "", "none", "2", "1"]],
	        "Windfury Harpy": ["风怒鹰身人", "ordinary", "风怒", ["HS_effect", "6", "", "none", "4", "5"]],
	        "Emperor Thaurissan": ["索瑞森大帝", "legend", "在你的回合结束时，你所有手牌的法力值消耗减少（1）点。", ["HS_effect", "6", "", "none", "5", "5"],
	            ["legend"]
	        ],
	        "Loatheb": ["洛欧塞布", "legend", "战吼：下个回合敌方法术的法力值消耗增加（5）点。", ["HS_effect", "5", "", "none", "5", "5"],
	            ["legend"]
	        ],
	        "Millhouse Manastorm": ["米尔豪斯·法力风暴", "legend", "战吼：下个回合敌方法术的法力值消耗为（0）点。", ["HS_effect", "2", "", "none", "4", "4"],
	            ["legend"]
	        ],
	        "Novice Engineer": ["工程师学徒", "essential", "战吼：抽一张牌。", ["HS_effect", "2", "", "none", "1", "1"]],
	        "Gnomish Inventor": ["侏儒发明家", "essential", "战吼：抽一张牌。", ["HS_effect", "4", "", "none", "2", "4"]],
	        "Sun Walker": ["烈日行者", "rare", "嘲讽，圣盾", ["HS_effect", "6", "", "none", "4", "5"]],
	        "Amani Berserker": ["阿曼尼狂战士", "ordinary", "激怒：+3攻击力。", ["HS_effect", "2", "", "none", "2", "3"]],
	        "Lowly Squire": ["低阶侍从", "ordinary", "激励：获得+1攻击力。", ["HS_effect", "1", "", "none", "1", "2"]],
	        "Puddlestomper": ["淤泥践踏者", "ordinary", "他非常崇拜伟大的鱼人先知摩戈尔！（哪个鱼人不是呢？）", ["HS_normal", "2", "", "murloc", "3", "2"]],
	        "Force Tank Max": ["强袭坦克", "ordinary", "圣盾", ["HS_effect", "8", "", "machine", "7", "7"]],
	        "North Sea Kraken": ["北海海怪", "ordinary", "战吼：造成4点伤害。", ["HS_effect", "9", "", "none", "9", "7"]],
	        "Dark Iron Dwarf": ["黑铁矮人", "ordinary", "战吼：在本回合中，使一个随从获得+2攻击力。", ["HS_effect", "4", "", "none", "4", "4"]],
	        "Scavenging Hyena": ["食腐土狼", "ordinary", "每当一个友方野兽死亡，便获得+2/+1。", ["HS_effect", "2", "hs_hunter", "wildbeast", "2", "2"]],
	        "Cult Master": ["诅咒教派领袖", "ordinary", "在一个友方随从死亡后，抽一张牌。", ["HS_effect", "4", "", "none", "4", "2"]],
	        "Flesheating Ghoul": ["腐肉食尸鬼", "ordinary", "每当一个随从死亡，便获得+1攻击力。", ["HS_effect", "3", "", "none", "3", "3"]],
	        "Succubus": ["魅魔", "ordinary", "战吼：随机弃一张牌。", ["HS_effect", "2", "hs_warlock", "demon", "4", "3"],
	            ["quetu"]
	        ],
	        "Ironbeak Owl": ["铁喙猫头鹰", "ordinary", "战吼：沉默一个随从。", ["HS_effect", "2", "", "wildbeast", "2", "1"],
	            ["battleRoal:buff>cm"]
	        ],
	        "Spellbreaker": ["破法者", "ordinary", "战吼：沉默一个随从。", ["HS_effect", "4", "", "none", "4", "3"],
	            ["battleRoal:buff>cm"]
	        ],
	        "Reno Jackson": ["雷诺·杰克逊", "legend", "战吼：如果你的牌库里没有相同的牌，则为你的英雄恢复所有生命值。", ["HS_effect", "6", "", "none", "4", "6"],
	            ["legend", "rareEff"]
	        ],
	        "ColdlightOracle": ["寒光智者", "rare", "战吼：每个玩家抽两张牌。", ["HS_effect", "3", "", "murloc", "2", "2"]],
	        "Ancient Watcher": ["上古看守者", "rare", "无法攻击。", ["HS_effect", "2", "", "none", "4", "5"]],
	        "Voodoo Doctor": ["巫医", "essential", "战吼：恢复2点生命值。", ["HS_effect", "1", "", "none", "2", "1"]],
	        "Earthen Ring Farseer": ["大地之环先知", "ordinary", "战吼：恢复3点生命值。", ["HS_effect", "3", "", "none", "3", "3"]],
	        "Senjin Shieldmasta": ["森金持盾卫士", "essential", "嘲讽", ["HS_effect", "4", "", "none", "3", "5"]],
	        "Boulderfist Ogre": ["石拳食人魔", "essential", "“我非常厉害，绝对值这个价格！”", ["HS_normal", "6", "", "none", "6", "7"]],
	        //从这里开始放嘲讽
	        "Lord of the Arena": ["竞技场主宰", "essential", "嘲讽", ["HS_effect", "6", "", "none", "6", "5"]],
	        "Evil Heckler": ["邪灵拷问者", "ordinary", "嘲讽", ["HS_effect", "4", "", "none", "5", "4"]],
	        "Booty Bay Bodyguard": ["藏宝海湾保镖", "essential", "嘲讽", ["HS_effect", "5", "", "none", "5", "4"]],
	        "Ironfur Grizzly": ["铁鬃灰熊", "essential", "嘲讽", ["HS_effect", "3", "", "wildbeast", "3", "3"]],
	        "Tournament Attendee": ["赛场观众", "ordinary", "嘲讽", ["HS_effect", "1", "", "none", "2", "1"]],
	        "Gnomeregan Infantry": ["诺莫瑞根步兵", "ordinary", "冲锋，嘲讽", ["HS_effect", "3", "", "none", "1", "4"]],
	        "Silent Knight": ["沉默的骑士", "ordinary", "潜行，圣盾", ["HS_effect", "3", "", "none", "2", "2"]],
	        "Flying Machine": ["飞行器", "ordinary", "风怒", ["HS_effect", "3", "", "machine", "1", "4"]],
	        "Stormwind Knight": ["暴风城骑士", "essential", "冲锋", ["HS_effect", "4", "", "none", "2", "5"]],
	        "Gilblin Stalker": ["海地精猎手", "ordinary", "潜行", ["HS_effect", "2", "", "none", "2", "3"]],
	        "Korkron Elite": ["库卡隆精英卫士", "essential", "冲锋", ["HS_effect", "4", "hs_warrior", "none", "4", "3"]],
	        "Emperor Cobra": ["帝王眼镜蛇", "rare", "剧毒", ["HS_effect", "3", "", "wildbeast", "2", "3"]],
	        "Thrallmar Farseer": ["萨尔玛先知", "ordinary", "风怒", ["HS_effect", "3", "", "none", "2", "3"]],
	        //结束
	        "Lorewalker Cho": ["游学者周卓", "legend", "每当一个玩家施放一个法术，复制该法术，将其置入另一个玩家的手牌。", ["HS_effect", "2", "", "none", "0", "4"],
	            ["legend"]
	        ],
	        "Questing Adventurer": ["任务达人", "rare", "每当你使用一张牌时，便获得+1/+1。", ["HS_effect", "3", "", "none", "2", "2"]],
	        "Mad Bomber": ["疯狂投弹者", "ordinary", "战吼：造成3点伤害，随机分配到所有其他角色身上。", ["HS_effect", "2", "", "none", "3", "2"]],
	        "Madder Bomber": ["疯狂爆破者", "rare", "战吼：造成6点伤害，随机分配到所有其他角色身上。", ["HS_effect", "5", "", "none", "5", "4"]],
	        "Abomination": ["憎恶", "rare", "嘲讽，亡语：对所有角色造成2点伤害。", ["HS_effect", "5", "", "none", "4", "4"]],
	        "Angry Chicken": ["愤怒的小鸡", "rare",
	            "激怒：+5攻击力。", ["HS_effect", "1", "", "wildbeast", "1", "1"]],
	        "Imp Master": ["小鬼召唤师", "rare", "你的回合结束时，对该随从造成1点伤害并召唤一个1/1的小鬼。", ["HS_effect", "3", "", "none", "1", "5"],
	            ["guimu:小鬼"]
	        ],
	        "Antique Healbot": ["老式治疗机器人", "ordinary", "战吼：为你的英雄恢复8点生命值。", ["HS_effect", "5", "", "machine", "3", "3"]],
	        "Stormwind Champion": ["暴风城勇士", "essential", "你的其他随从获得+1/+1。", ["HS_effect", "7", "", "none", "6", "6"]],
	        "Faceless Manipulator": ["无面操纵者", "epic", "战吼：选择一个随从，成为它的复制。", ["HS_effect", "5", "", "none", "3", "3"]],
	        "Spider Tank": ["蜘蛛坦克", "ordinary", "我想在这家伙上面装上一门炮，你觉得怎么样?”菲兹布里兹看着蜘蛛运输装置说道", ["HS_normal", "3", "", "machine", "3", "4"]],
	        "Explosive Sheep": ["自爆绵羊", "ordinary", "亡语：对所有随从造成2点伤害。", ["HS_effect", "2", "", "machine", "1", "1"]],
	        "Ironforge Rifleman": ["铁炉堡火枪手", "essential", "战吼：造成1点伤害。", ["HS_effect", "3", "", "none", "2", "2"]],
	        "Stormpike Commando": ["雷矛特种兵", "essential", "战吼：造成2点伤害。", ["HS_effect", "5", "", "none", "4", "2"]],
	        "Nightblade": ["夜刃刺客", "essential", "战吼：对敌方英雄造成3点伤害。", ["HS_effect", "5", "", "none", "4", "4"]],
	        "Twilight Drake": ["暮光幼龙", "rare", "战吼： 你每有一张手牌，便获得+1生命值。", ["HS_effect", "4", "", "dragon", "4", "1"]],
	        "Silver Hand Regent": ["白银之手教官", "ordinary", "激励：召唤一个1/1的白银之手新兵。", ["HS_effect", "3", "", "none", "3", "3"],
	            ["jili:白银之手新兵"]
	        ],
	        "Shade of Naxxramas": ["纳克萨玛斯之影", "epic", "潜行。在你的回合开始时，获得+1/+1。", ["HS_effect", "3", "", "none", "2", "2"]],
	        "Baron Rivendare": ["瑞文戴尔男爵", "legend", "你的随从的亡语将触发两次。", ["HS_effect", "4", "", "none", "1", "7"],
	            ["legend", "skillgh:doubledeathrattle"]
	        ],
	        "Harvest Golem": ["麦田傀儡", "ordinary",
	            "亡语：召唤一个2/1的损坏的傀儡。", ["HS_effect", "3", "", "machine", "2", "3"],
	            ["deathRattle:损坏的傀儡"]
	        ],
	        "Damaged Golem": ["损坏的傀儡", "essential", "", ["HS_normal", "1", "", "machine", "2", "1"],
	            ["token"]
	        ],
	        "Captured Jormungar": ["俘获的冰虫", "ordinary",
	            "你可以把它养着做宠物。但你要保证每天准点喂食，还要清理它的水缸！", ["HS_normal", "7", "", "wildbeast", "5", "9"]],
	        "Dragonling Mechanic": ["机械幼龙技工", "essential",
	            "战吼：召唤一个2/1的机械幼龙。", ["HS_effect", "4", "", "none", "2", "4"],
	            ["battleRoal:机械幼龙"]
	        ],
	        "Mechanical Dragonling": ["机械幼龙", "essential", "", ["HS_normal", "1", "", "machine", "2", "1"],
	            ["token"]
	        ],
	        "Sludge Belcher": ["淤泥喷射者", "rare",
	            "嘲讽。亡语：召唤一个1/2并具有嘲讽的泥浆怪。", ["HS_effect", "5", "", "none", "3", "5"],
	            ["deathRattle:泥浆怪"]
	        ],
	        "Slime": ["泥浆怪", "essential", "嘲讽", ["HS_effect", "1", "", "none", "1", "2"],
	            ["token"]
	        ],
	        "Mechwarper": ["机械跃迁者", "ordinary", "你的机械的法力值消耗减少（1）点。", ["HS_effect", "2", "", "machine", "2", "3"]],
	        "Cogmaster": ["齿轮大师", "ordinary", "如果你控制任何机械，便获得+2攻击力。", ["HS_effect", "1", "", "none", "1", "2"]],
	        "Sheep": ["绵羊", "essential", "", ["HS_normal", "1", "", "wildbeast", "1", "1"],
	            ["token"]
	        ],
	        "Shielded Minibot": ["护盾机器人", "ordinary", "圣盾", ["HS_effect", "2", "hs_paladin", "machine", "2", "2"]],
	        "Guardian of Kings": ["列王守卫", "essential", "战吼：为你的英雄恢复6点生命值。", ["HS_effect", "7", "hs_paladin", "none", "5", "6"]],
	        "Violet Teacher": ["紫罗兰教师", "rare", "每当你施放一个法术，便召唤一个1/1的紫罗兰学徒。", ["HS_effect", "4", "", "none", "3", "5"],
	            ["法前:紫罗兰学徒"]
	        ],
	        "Violet Apprentice": ["紫罗兰学徒", "essential", "", ["HS_normal", "1", "", "none", "1", "1"],
	            ["tokened"]
	        ],
	        "Silver Hand Knight": ["白银之手骑士", "ordinary", "战吼：召唤一个2/2的侍从。", ["HS_effect", "5", "", "none", "4", "4"],
	            ["battleRoal:侍从"]
	        ],
	        "Squire": ["侍从", "essential", "", ["HS_normal", "1", "", "none", "2", "2"],
	            ["token"]
	        ],
	        "Pit Fighter": ["格斗士", "ordinary", "他们的血液里充斥着尚武精神，想要打一架吗？", ["HS_normal", "5", "", "none", "5", "6"]],
	        "Raid Leader": ["团队领袖", "essential", "你的其他随从获得+1攻击力。", ["HS_effect", "3", "", "none", "2", "2"]],
	        "Nerubar Weblord": ["尼鲁巴蛛网领主", "ordinary", "具有战吼的随从法力值消耗增加（2）点。", ["HS_effect", "2", "", "none", "1", "4"]],
	        "Mana Wraith": ["法力怨魂", "rare", "召唤所有随从的法力值消耗增加（1）点。", ["HS_effect", "2", "", "none", "2", "2"]],
	        "Hound": ["猎犬", "essential", "冲锋", ["HS_effect", "1", "hs_hunter", "wildbeast", "1", "1"],
	            ["token"]
	        ],
	        "Cairne Bloodhoof": ["凯恩·血蹄", "legend",
	            "亡语：召唤一个4/5的贝恩·血蹄。", ["HS_effect", "6", "", "none", "4", "5"],
	            ["deathRattle:贝恩·血蹄"]
	        ],
	        "Baine Bloodhoof": ["贝恩·血蹄", "essential", "", ["HS_normal", "4", "", "none", "4", "5"],
	            ["token"]
	        ],
	        "Ice Rager": ["冰霜暴怒者", "ordinary", "再怎么说他也要比岩浆暴怒者冷静多了。", ["HS_normal", "3", "", "none", "5", "2"]],
	        "Salty Dog": ["熟练的水手", "ordinary", "他喜欢在船上颠簸的感觉，比在陆地上走路更有安全感。", ["HS_normal", "5", "", "pirate", "7", "4"]],
	        "Fearsome Doomguard": ["恐怖末日守卫", "ordinary", "恐怖都写在名字里了，还能有比这更恐怖的家伙吗？", ["HS_normal", "7", "hs_warlock", "demon", "6", "8"]],
	        "War Golem": ["作战傀儡", "essential", "傀儡们从来不会胆怯，但是出于某种原因，当你对它们施放“恐惧”的时候，它们依然会逃跑。也许这就是天性？或是想要融入这个世界的渴望？", ["HS_normal", "7", "", "none", "7", "7"]],
	        "Core Hound": ["熔火恶犬", "essential", "你无法驯服一头熔火恶犬。你只能通过训练让它在吃掉你之前先吃掉其他人。", ["HS_normal", "7", "", "wildbeast", "9", "5"]],
	        "Dread Infernal": ["恐惧地狱火", "essential", "战吼：对所有其他角色造成1点伤害。", ["HS_effect", "6", "hs_warlock", "demon", "6", "6"]],
	        "Pit Lord": ["深渊领主", "epic", "战吼：对你的英雄造成5点伤害。", ["HS_effect", "4", "hs_warlock", "demon", "5", "6"]],
	        "Priestess of Elune": ["艾露恩的女祭司", "ordinary", "战吼：为你的英雄恢复4点生命值。", ["HS_effect", "6", "", "none", "5", "4"]],
	        "Frigid Snobold": ["雪地狗头人", "ordinary", "法术伤害+1", ["HS_effect", "4", "", "none", "2", "6"]],
	        "Soot Spewer": [" 煤烟喷吐装置", "rare", "法术伤害+1", ["HS_effect", "3", "hs_mage", "machine", "3", "3"]],
	        "Ogre Magi": ["食人魔法师", "essential", "法术伤害+1", ["HS_effect", "4", "", "none", "4", "4"]],
	        "Archmage": ["大法师", "essential", "法术伤害+1", ["HS_effect", "6", "", "none", "4", "7"]],
	        "Dalaran Mage": ["达拉然法师", "essential", "法术伤害+1", ["HS_effect", "3", "", "none", "1", "4"]],
	        "Kobold Geomancer": ["狗头人地卜师", "essential", "法术伤害+1", ["HS_effect", "2", "", "none", "2", "2"]],
	        "Mini-Mage": ["小个子法师", "epic", "潜行，法术伤害+1", ["HS_effect", "3", "", "none", "3", "1"]],
	        "Fire Elemental": ["火元素", "essential", "战吼：造成3点伤害。", ["HS_effect", "6", "hs_shaman", "none", "6", "5"]],
	        "Queen of Pain": ["痛苦女王", "rare", "吸血", ["HS_effect", "2", "hs_warlock", "demon", "1", "4"],
	            ["quetu"]
	        ],
	        "Southsea Captain": ["南海船长", "epic", "你的其他海盗获得+1/+1。", ["HS_effect", "3", "", "pirate", "3", "3"]],
	        "Junkbot": ["回收机器人", "epic", "每当一个友方机械死亡，便获得+2/+2。", ["HS_effect", "5", "", "machine", "1", "5"]],
	        "Tongue Totem": ["火舌图腾", "essential", "相邻的随从获得+2攻击力。", ["HS_effect", "2", "hs_shaman", "totem", "0", "3"]],
	        "Razorfen Hunter": ["剃刀猎手", "essential", "战吼：召唤一个 1/1 的野猪。", ["HS_effect", "3", "", "none", "2", "3"],
	            ["battleRoal:野猪"]
	        ],
	        "Boar": ["野猪", "essential", "", ["HS_normal", "1", "", "wildbeast", "1", "1"],
	            ["token"]
	        ],
	        "Ironbark Protector": ["埃隆巴克保护者", "essential", "嘲讽", ["HS_effect", "8", "hs_druid", "", "8", "8"]],
	        "Pit Snake": ["深渊巨蟒", "ordinary", "剧毒", ["HS_effect", "1", "hs_rogue", "wildbeast", "2", "1"]],
	        "Patient Assassin": ["耐心的刺客", "epic", "潜行，剧毒", ["HS_effect", "2", "hs_rogue", "none", "1", "2"]],
	        "Reckless Rocketeer": ["鲁莽火箭兵", "essential", "冲锋", ["HS_effect", "6", "", "none", "5", "2"]],
	        "Nat Pagle": ["纳特·帕格", "legend", "在你的回合开始时，你有50%的几率额外抽一张牌。", ["HS_effect", "2", "", "none", "0", "4"],
	            ["legend"]
	        ],
	        "Gruul": ["格鲁尔", "legend", "在每个回合结束时，获得+1/+1。", ["HS_effect", "8", "", "none", "7", "7"],
	            ["legend"]
	        ],
	        "Magma Rager": ["岩浆暴怒者", "essential", "尽管现在每个人都能单刷熔火之心了，但他依然觉得自己很厉害。", ["HS_normal", "3", "", "none", "5", "1"]],
	        "Houndmaster": ["驯兽师", "essential", "战吼：使一个友方野兽获得+2/+2和嘲讽。", ["HS_effect", "4", "hs_hunter", "none", "4", "3"],
	            ["rareEff", "battleRoal:fltbuff>mine_,wildbeast：22,chaofeng"]
	        ],
	        "Dreadscale": ["恐鳞", "legend", "在你的回合结束时，对所有其他随从造成1点伤害。", ["HS_effect", "3", "hs_hunter", "wildbeast", "4", "2"],
	            ["legend"]
	        ],
	        "Ram Wrangler": ["暴躁的牧羊人", "rare", "战吼：如果你控制任何野兽，则随机召唤一个野兽。", ["HS_effect", "5", "hs_hunter", "none", "3", "3"],
	            ["rareEff"]
	        ],
	        "Stablemaster": ["兽栏大师", "epic", "战吼：在本回合中，使一个友方野兽获得免疫。", ["HS_effect", "3", "hs_hunter", "none", "4", "2"],
	            ["rareEff", "battleRoal:fltbuff>mine_,wildbeast：mianyi:1"]
	        ],
	        "Shieldmaiden": ["盾甲侍女", "rare", "战吼：获得5点护甲值。", ["HS_effect", "6", "hs_warrior", "none", "5", "5"]],
	        "Obsidian Destroyer": ["黑曜石毁灭者", "ordinary", "在你的回合结束时，召唤一只1/1并具有嘲讽的甲虫。", ["HS_effect", "7", "hs_warrior", "none", "7", "7"],
	            ["ending:圣甲虫"]
	        ],
	        "Scarab": ["圣甲虫", "essential", "嘲讽", ["HS_effect", "1", "hs_warrior", "wildbeast", "1", "1"],
	            ["token"]
	        ],
	        "Wildwalker": ["荒野行者", "ordinary", "战吼：使一个友方野兽获得+3生命值。", ["HS_effect", "4", "hs_druid", "none", "4", "4"],
	            ["rareEff", "battleRoal:fltbuff>mine_,wildbeast：H3"]
	        ],
	        "Jungle Moonkin": ["丛林枭兽", "rare", "每个玩家获得法术伤害+2。", ["HS_effect", "4", "hs_druid", "none", "4", "4"]],
	        "Savage Combatant": ["狂野争斗者", "rare", "激励：在本回合中，使你的英雄获得+2攻击力。", ["HS_effect", "4", "hs_druid", "wildbeast", "5", "4"]],
	        "Darnassus Aspirant": ["达纳苏斯豹骑士", "rare", "战吼：获得一个空的法力水晶。亡语：失去一个法力水晶。", ["HS_effect", "2", "hs_druid", "none", "2", "3"]],
	        "Argent Protector": ["银色保卫者", "ordinary", "战吼：使一个其他友方随从获得圣盾。", ["HS_effect", "2", "hs_paladin", "none", "2", "2"],
	            ["battleRoal:mebuff>shengdun"]
	        ],
	        "Frost Elemental": ["冰霜元素", "ordinary", "战吼：冻结一个角色。", ["HS_effect", "6", "", "none", "5", "5"],
	            ["battleRoal:allbuff>dongjied"]
	        ],
	        "Justicar Trueheart": ["裁决者图哈特", "legend", "战吼：以更强的英雄技能来替换你的初始英雄技能。", ["HS_effect", "6", "", "none", "6", "3"],
	            ["legend"]
	        ],
	        "Rhonin": ["罗宁", "legend", "亡语：将三张奥术飞弹置入你的手牌。", ["HS_effect", "8", "hs_mage", "none", "7", "7"],
	            ["legend", "deathRattle:gain>['奥术飞弹',3]"]
	        ],
	        "Mimirons Head": ["米米尔隆的头部", "legend", "在你的回合开始时，如果你控制至少三个机械，则消灭这些机械，并将其组合成V-07-TR-0N。", ["HS_effect", "5", "", "machine", "4", "5"],
	            ["legend"]
	        ],
	        "V-07-TR-0N": ["V-07-TR-0N", "legend", "冲锋，超级风怒", ["HS_effect", "8", "", "machine", "4", "8"],
	            ["token"]
	        ],
	        "Undertaker": ["送葬者", "ordinary", "每当你召唤一个具有亡语的随从，便获得+1攻击力。", ["HS_effect", "1", "", "none", "1", "2"]],
	        "Wrath of Air Totem": ["空气之怒图腾", "essential", "法术伤害+1", ["HS_effect", "1", "hs_shaman", "totem", "0", "2"],
	            ["token"]
	        ],
	        "Searing Totem": ["灼热图腾", "essential", "", ["HS_normal", "1", "hs_shaman", "totem", "1", "1"],
	            ["token"]
	        ],
	        "Stoneclaw Totem": ["石爪图腾", "essential", "嘲讽", ["HS_effect", "1", "hs_shaman", "totem", "0", "2"],
	            ["token"]
	        ],
	        "Healing Totem": ["治疗图腾", "essential", "在你的回合结束时，为所有友方随从恢复1点生命值。", ["HS_effect", "1", "hs_shaman", "totem", "0", "2"],
	            ["token", "结束:aoercv>player.sctp('mine'),1"]
	        ],
	        "Arathi Weaponsmith": ["阿拉希武器匠", "ordinary", "战吼：装备一把2/2的武器。", ["HS_effect", "4", "hs_warrior", "none", "3", "3"],
	            ["battleRoal:weapon>'战斧'"]
	        ],
	        "Buccaneer": ["锈水海盗", "ordinary", "每当你装备一把武器，使武器获得+1攻击力。", ["HS_effect", "1", "hs_rogue", "pirate", "2", "1"]],
	        "Tirion Fordring": ["提里奥·弗丁", "legend", "圣盾，嘲讽，亡语：装备一把5/3的灰烬使者。", ["HS_effect", "8", "hs_paladin", "none", "6", "6"],
	            ["legend", "deathRattle:weapon>'灰烬使者'"]
	        ],
	        "AlAkir the Windlord": ["风领主奥拉基尔", "legend", "冲锋，圣盾，嘲讽，风怒", ["HS_effect", "8", "hs_shaman", "none", "3", "5"]],
	        "Young Priestess": ["年轻的女祭司", "rare", "在你的回合结束时，随机使另一个友方随从获得+1生命值。", ["HS_effect", "1", "", "none", "2", "1"],
	            ["结束:mine_buff>H1"]
	        ],
	        "Blood Imp": ["鲜血小鬼", "ordinary", "潜行，在你的回合结束时，随机使另一个友方随从获得+1生命值。", ["HS_effect", "1", "hs_warlock", "demon", "0", "1"],
	            ["结束:mine_buff>H1"]
	        ],
	        "Summoning Portal": ["召唤传送门", "ordinary", "你的随从牌的法力值消耗减少（2）点，但不能少于（1）点。", ["HS_effect", "4", "hs_warlock", "none", "0", "4"]],
	        "Void Terror": ["虚空恐魔", "rare", "战吼：消灭该随从两侧的随从，并获得他们的攻击力和生命值。", ["HS_effect", "3", "hs_warlock", "demon", "3", "3"]],
	        "Hogger": ["霍格", "legend", "在你的回合结束时，召唤一个2/2并具有嘲讽的豺狼人。", ["HS_effect", "6", "", "none", "4", "4"],
	            ["legend", "ending:豺狼人"]
	        ],
	        "Gnoll": ["豺狼人", "essential", "嘲讽", ["HS_effect", "2", "", "none", "2", "2"],
	            ["token"]
	        ],
	        "Bolf Ramshield": ["博尔夫·碎盾", "legend", "每当你的英雄受到伤害，便会由该随从来承担。", ["HS_effect", "6", "", "none", "3", "9"],
	            ["legend"]
	        ],
	        "Tunnel Trogg": ["坑道穴居人", "ordinary", "每当你过载时，每一个被锁的法力水晶会使其获得+1攻击力。", ["HS_effect", "1", "hs_shaman", "none", "1", "3"]],
	        "Argent Horserider": ["银色骑手", "ordinary", "冲锋，圣盾", ["HS_effect", "3", "", "none", "2", "1"]],
	        "Shattered Sun Cleric": ["破碎残阳祭司", "essential", "战吼：使一个友方随从获得+1/+1。", ["HS_effect", "3", "", "none", "3", "2"],
	            ["battleRoal:mebuff>11"]
	        ],
	        "Tinkmaster Overspark": ["工匠大师欧沃斯巴克", "legend", "战吼： 随机使另一个随从变形成为一个5/5的魔暴龙或一个1/1的松鼠。", ["HS_effect", "3", "", "none", "3", "3"],
	            ["legend"]
	        ],
	        "Devilsaur": ["魔暴龙", "essential", "", ["HS_normal", "5", "", "wildbeast", "5", "5"],
	            ["token"]
	        ],
	        "Squirrel": ["松鼠", "essential", "", ["HS_normal", "1", "", "wildbeast", "1", "1"],
	            ["token"]
	        ],
	        "Clockwork Knight": ["发条骑士", "ordinary", "战吼：使一个友方机械获得+1/+1。", ["HS_effect", "5", "", "machine", "5", "5"],
	            ["battleRoal:fltbuff>mine,machine：11"]
	        ],
	        "Nexus-Champion Saraad": ["虚灵勇士萨兰德", "legend", "激励：随机将一张法术牌置入你的手牌。", ["HS_effect", "5", "", "none", "4", "5"],
	            ["legend", "jili:rangain>法术"]
	        ],
	        "Shady Dealer": ["走私商贩", "rare", "战吼：如果你控制任何海盗，便获得+1/+1。", ["HS_effect", "3", "hs_rogue", "none", "4", "3"]],
	        "Dust Devil": ["尘魔", "ordinary", "风怒，过载：（2）", ["HS_effect", "1", "hs_shaman", "none", "3", "1"]],
	        "Neptulon": ["耐普图隆", "legend", "战吼：随机将四张鱼人牌置入你的手牌，过载：（3）", ["HS_effect", "7", "hs_shaman", "none", "7", "7"],
	            ["legend", "battleRoal:rangain>4鱼人"]
	        ],
	        "Totem Golem": ["图腾魔像", "ordinary", "过载：（1）", ["HS_effect", "2", "hs_shaman", "totem", "3", "4"]],
	        "Earth Elemental": ["土元素", "epic", "嘲讽，过载：（3）", ["HS_effect", "5", "hs_shaman", "none", "7", "8"]],
	        "Master of Disguise": ["伪装大师", "rare", "战吼：使一个友方随从获得潜行。", ["HS_effect", "4", "hs_rogue", "none", "4", "4"],
	            ["battleRoal:mebuff>qianxing"]
	        ],
	        "Spirit Wolf": ["幽灵狼", "essential", "嘲讽", ["HS_effect", "2", "hs_shaman", "none", "2", "3"],
	            ["token"]
	        ],
	        "Mana Tide Totem": ["法力之潮图腾", "rare", "在你的回合结束时，抽一张牌。", ["HS_effect", "3", "hs_shaman", "totem", "0", "3"]],
	        "Whirling Zap-o-matic": ["自动漩涡打击装置", "ordinary", "风怒", ["HS_effect", "2", "hs_shaman", "machine", "3", "2"]],
	        "Tomb Pillager": ["盗墓匪贼", "ordinary", "亡语：将一个幸运币置入你的手牌。", ["HS_effect", "4", "hs_rogue", "none", "5", "4"],
	            ["deathRattle:gain>'幸运币'"]
	        ],
	        "Cutpurse": ["窃贼", "rare", "每当该随从攻击一方英雄，会将幸运币置入你的手牌。", ["HS_effect", "2", "hs_rogue", "none", "2", "2"]],
	        "Sneeds Old Shredder": ["斯尼德的伐木机", "legend", "亡语：随机召唤一个传说随从。", ["HS_effect", "8", "", "machine", "5", "7"],
	            ["legend", "deathRattle:['range:传说']"]
	        ],
	        "Bloodsail Raider": ["血帆袭击者", "ordinary", "战吼：获得等同于你的武器攻击力的攻击力。", ["HS_effect", "2", "", "pirate", "2", "3"],
	            ["rareEff"]
	        ],
	        "Dread Corsair": ["恐怖海盗", "ordinary", "嘲讽，你的武器每有1点攻击力，该牌的法力值消耗便减少（1）点。", ["HS_effect", "4", "", "pirate", "3", "3"],
	            ["changecost:return p.data_weapon?p.data_weapon.ATK:0;"]
	        ],
	        "Southsea Deckhand": ["南海船工", "ordinary", "如果你装备一把武器，该随从具有冲锋。", ["HS_effect", "1", "", "pirate", "2", "1"]],
	        "Arcane Golem": ["奥术傀儡", "rare", "冲锋，战吼：使你的对手获得一个法力水晶。", ["HS_effect", "3", "", "none", "4", "2"]],
	        "Felguard": ["恶魔卫士", "rare", "嘲讽，战吼：摧毁你的一个法力水晶。", ["HS_effect", "3", "hs_warlock", "demon", "3", "5"]],
	        "Gadgetzan Auctioneer": ["加基森拍卖师", "rare", "每当你施放一个法术，便抽一张牌。", ["HS_effect", "6", "", "none", "4", "4"]],
	        "Murloc Tidecaller": ["鱼人招潮者", "rare", "每当有玩家召唤一个鱼人，便获得+1攻击力。", ["HS_effect", "1", "", "murloc", "1", "2"]],
	        "Cobalt Guardian": ["钴制卫士", "rare", "每当你召唤一个机械，便获得圣盾。", ["HS_effect", "5", "hs_paladin", "machine", "6", "3"]],
	        "Micro Machine": ["微型战斗机甲", "ordinary", "在每个回合开始时，获得+1攻击力。", ["HS_effect", "2", "", "machine", "1", "2"]],
	        "King Mukla": ["穆克拉", "legend", "战吼：使你的对手获得两根香蕉。", ["HS_effect", "3", "", "wildbeast", "5", "5"],
	            ["legend"]
	        ],
	        "Frog": ["青蛙", "essential", "嘲讽", ["HS_effect", "0", "", "wildbeast", "0", "1"],
	            ["token"]
	        ],
	        "Windspeaker": ["风语者", "essential", "战吼：使一个友方随从获得风怒。", ["HS_effect", "4", "hs_shaman", "none", "4", "3"],
	            ["battleRoal:mebuff>fengnu"]
	        ],
	        "Acidic Swamp Ooze": ["酸性沼泽软泥怪", "essential", "战吼： 摧毁对手的武器。", ["HS_effect", "2", "", "none", "3", "2"],
	            ["rareEff"]
	        ],
	        "Bloodsail Corsair": ["血帆海盗", "rare", "战吼：使对手的武器失去1点耐久度。", ["HS_effect", "1", "", "pirate", "1", "2"],
	            ["rareEff"]
	        ],
	        "Tiny Knight of Evil": ["小鬼骑士", "rare", "每当你弃掉一张牌时，便获得+1/+1。", ["HS_effect", "2", "hs_warlock", "demon", "3", "2"]],
	        "Harrison Jones": ["哈里森·琼斯", "legend", "战吼：摧毁对手的武器，并抽数量等同于其耐久度的牌。", ["HS_effect", "5", "", "none", "5", "4"],
	            ["rareEff"]
	        ],
	        "Bomb Lobber": ["榴弹投手", "rare", "战吼：随机对一个敌方随从造成4点伤害。", ["HS_effect", "5", "", "none", "3", "3"]],
	        "Ogre Brute": ["食人魔步兵", "ordinary", "50%几率攻击错误的敌人。", ["HS_effect", "3", "", "none", "4", "4"]],
	        "Spellslinger": ["嗜法者", "ordinary", "战吼：随机将一张法术牌置入每个玩家的手牌。", ["HS_effect", "3", "hs_mage", "none", "3", "4"]],
	        "Mogors Champion": ["穆戈尔的勇士", "rare", "50%几率攻击错误的敌人。", ["HS_effect", "6", "", "none", "8", "5"]],
	        "Ogre Ninja": ["食人魔忍者", "rare", "潜行，50%几率攻击错误的敌人。", ["HS_effect", "5", "hs_rogue", "none", "6", "6"]],
	        "Dunemaul Shaman": ["砂槌萨满祭司", "rare", "风怒，过载：（1），50%几率攻击错误的敌人。", ["HS_effect", "4", "hs_shaman", "none", "5", "4"]],
	        "Mogor the Ogre": ["食人魔勇士穆戈尔", "legend", "所有随从有50%几率攻击错误的敌人。", ["HS_effect", "6", "", "none", "7", "6"]],
	        "Mana Addict": ["魔瘾者", "rare", "在本回合中，每当你施放一个法术，便获得+2攻击力。", ["HS_effect", "2", "", "none", "1", "3"]],
	        "Stampeding Kodo": ["狂奔科多兽", "rare", "战吼：随机消灭一个攻击力小于或等于2的敌方随从。", ["HS_effect", "5", "", "wildbeast", "3", "5"],
	            ["rareEff"]
	        ],
	        "Fel Reaver": ["魔能机甲", "epic", "每当你的对手使用一张卡牌时，便移除你的牌库顶的三张牌。", ["HS_effect", "5", "", "machine", "8", "8"]],
	        "Axe Flinger": ["掷斧者", "ordinary", "每当该随从受到伤害，对敌方英雄造成2点伤害。", ["HS_effect", "4", "hs_warrior", "none", "2", "5"]],
	        "Alexstraszas Champion": ["阿莱克丝塔萨的勇士", "rare", "战吼：如果你的手牌中有龙牌，便获得+1攻击力和冲锋。", ["HS_effect", "2", "hs_warrior", "none", "2", "3"]],
	        "Sparring Partner": ["格斗陪练师", "rare", "嘲讽，战吼：使一个随从获得嘲讽。", ["HS_effect", "2", "hs_warrior", "none", "3", "2"],
	            ["battleRoal:buff>chaofeng"]
	        ],
	        "Spawn of Shadows": ["暗影子嗣", "rare", "激励：对每个英雄造成4点伤害。", ["HS_effect", "4", "hs_priest", "none", "5", "4"]],
	        "Shadowfiend": ["暗影魔", "epic", "每当你抽一张牌时，使其法力值消耗减少（1）点。", ["HS_effect", "3", "hs_priest", "none", "3", "3"]],
	        "Chromaggus": ["克洛玛古斯", "legend", "每当你抽一张牌时，将该牌的另一张复制置入你的手牌。", ["HS_effect", "8", "", "dragon", "6", "8"]],
	        "KelThuzad": ["克尔苏加德", "legend", "在每个回合结束时，召唤所有在本回合中死亡的友方随从。", ["HS_effect", "8", "", "none", "6", "8"]],
	        "Flame Leviathan": ["烈焰巨兽", "legend", "当你抽到该牌时，对所有角色造成2点伤害。", ["HS_effect", "7", "hs_mage", "machine", "7", "7"],
	            ["addhand:get.HSF('lavaeffect',['all',2,'lava',player]);"]
	        ],
	        "Sylvanas Windrunner": ["希尔瓦娜斯·风行者", "legend", "亡语：随机获得一个敌方随从的控制权。", ["HS_effect", "6", "", "none", "5", "5"]],
	        "Sea Reaver": ["破海者", "epic", "当你抽到该牌时，对你的随从造成1点伤害。", ["HS_effect", "6", "hs_warrior", "none", "6", "7"],
	            ["addhand:get.HSF('lavaeffect',['mine',1,'blade',player]);"]
	        ],
	        "Iron Juggernaut": ["钢铁战蝎", "legend", "战吼：将一张“地雷” 牌洗入你对手的牌库。当抽到“地雷”时，便会受到10点伤害。", ["HS_effect", "6", "hs_warrior", "machine", "6", "5"]],
	        "Mind Control Tech": ["精神控制技师", "rare", "战吼：如果你的对手拥有4个或者更多随从，随机获得其中一个的控制权。", ["HS_effect", "3", "", "none", "3", "3"],
	            ["rareEff"]
	        ],
	        "Cabal Shadow Priest": ["秘教暗影祭司", "epic", "战吼：获得一个攻击力小于或等于2的敌方随从的控制权。", ["HS_effect", "6", "hs_priest", "none", "4", "5"],
	            ["rareEff"]
	        ],
	        "Shrinkmeister": ["缩小射线工程师", "ordinary", "战吼：在本回合中，使一个随从获得-2攻击力。", ["HS_effect", "2", "hs_priest", "none", "3", "2"]],


	        //腐化者
	        "White Spotted Spider": ["白斑蜘蛛", "essential", "亡语：抽一张牌。", ["HS_effect", "0", "hs_corruptor", "wildbeast", "0", "1"],
	            ["diy", "token"]
	        ],
	        "Poisonous Spider": ["剧毒蜘蛛", "essential", "剧毒", ["HS_effect", "1", "hs_corruptor", "wildbeast", "1", "1"],
	            ["diy", "token"]
	        ],
	        "Snake-haired Girl": ["蛇发女妖", "ordinary", "冲锋，剧毒", ["HS_effect", "4", "hs_corruptor", "none", "1", "1"],
	            ["diy"]
	        ],
	        "Goblin Warlock": ["哥布林术士", "essential", "亡语：将一张白斑蜘蛛置入你的手牌。", ["HS_effect", "1", "hs_corruptor", "goblin", "1", "1"],
	            ["diy"]
	        ],
	        "Forbidden Master": ["禁术法师", "epic", "剧毒，嘲讽", ["HS_effect", "4", "hs_corruptor", "none", "2", "4"],
	            ["diy"]
	        ],
	        "Daughter of Medusa": ["美杜莎之女", "legend", "剧毒", ["HS_effect", "3", "hs_corruptor", "none", "1", "4"],
	            ["legend", "diy"]
	        ],
	        "Goblin Warrior": ["哥布林战士", "rare", "剧毒，战吼：将一张萃毒置入你的手牌。", ["HS_effect", "3", "hs_corruptor", "goblin", "2", "2"],
	            ["diy"]
	        ],
	        "Goblin Miner": ["哥布林矿工", "ordinary", "战吼：对一个随机敌人造成一点伤害，你每有一个其他哥布林，多执行一次。", ["HS_effect", "2", "hs_corruptor", "goblin", "0", "3"],
	            ["diy"]
	        ],
	        "Goblin Engineer": ["哥布林工程师", "rare", "每当你施放一个法术，便随机对一个敌人造成1点伤害。", ["HS_effect", "1", "hs_corruptor", "goblin", "1", "1"],
	            ["diy"]
	        ],
	        "Spider Queen": ["蜘蛛人女王", "epic", "你的白斑蜘蛛和剧毒蜘蛛获得+2/+2，每当一个友方随从死亡，获得+1攻击力。", ["HS_effect", "5", "hs_corruptor", "none", "1", "6"],
	            ["diy"]
	        ],
	        "Goblin Bandit": ["哥布林悍匪", "epic", "战吼：消灭一个嘲讽随从，并对其拥有者造成3点伤害。", ["HS_effect", "5", "hs_corruptor", "goblin", "3", "3"],
	            ["diy", "rareEff"]
	        ],
	        "Denseforest Marsh Dragon": ["密林沼龙", "epic", "每当你的一个随从死亡后，依次获得如下效果之一：+2生命值，你的法术牌费用-1，剧毒，+2/+2。", ["HS_effect", "3", "hs_corruptor", "dragon", "1", "4"],
	            ["diy"]
	        ],
	        "Denseforest Mage": ["密林法师", "rare", "亡语：对你的英雄造成两点伤害，抽一张牌并使其费用-1。", ["HS_effect", "2", "hs_corruptor", "none", "3", "2"],
	            ["diy", "i"]
	        ],
	        "Eye of the Devil": ["恶魔之眼", "ordinary", "亡语：对手随机弃一张牌。", ["HS_effect", "4", "hs_corruptor", "none", "3", "2"],
	            ["diy"]
	        ],
	        "Denseforest Shooter": ["密林射手", "rare", "风怒，战吼：若你的手牌更多，+2/+2。", ["HS_effect", "4", "hs_corruptor", "none", "2", "3"],
	            ["diy"]
	        ],
	        "Robin Hood, the Dark Ranger": ["密林射手", "rare", "风怒，战吼：若你的手牌更多，+2/+2。", ["HS_effect", "4", "hs_corruptor", "none", "2", "3"],
	            ["diy"]
	        ],



	        //炉石普通
	        "Wolfrider PT": ["狼骑兵", "essential",
	            "冲锋", ["HS_effect", "1", "", "none", "1", "1"]],
	        "Frostwolf Grunt PT": ["霜狼步兵", "essential",
	            "嘲讽", ["HS_effect", "2", "", "none", "1", "2"]],
	        "Archmage Antonidas PT": ["大法师安东尼达斯", "legend", "每当你施放一个法术，便抽一张牌。", ["HS_effect", "3", "hs_mage", "none", "0", "3"],
	            ["legend"]
	        ],
	        "Socerer s Apprentice PT": ["巫师学徒", "rare", "你的法术的法力值消耗减少（1）点。", ["HS_effect", "1", "hs_mage", "none", "1", "1"]],
	        "Grommash Hellscream PT": ["格罗玛什·地狱咆哮", "legend", "冲锋，激怒：+2攻击力。", ["HS_effect", "3", "hs_warrior", "none", "1", "3"],
	            ["legend", "remove"]
	        ],
	        "Snake-haired Girl PT": ["蛇发女妖", "ordinary", "“蛇发女妖和美杜莎有什么亲缘关系吗？”答案是没有关系。", ["HS_normal", "1", "hs_corruptor", "none", "2", "1"],
	            ["diy"]
	        ],
	        "Forbidden Master PT": ["禁术法师", "rare", "剧毒，嘲讽", ["HS_effect", "2", "hs_corruptor", "none", "1", "1"],
	            ["diy"]
	        ],

	        //diy
	        //客串
	        "Saltfish Pigeon": ["咸鱼鸽鸽", "legend", "冲锋，战吼：场上每有一个其他随从，获得一点攻击力，亡语：将一张咸鱼鸽鸽置入你的手牌。", ["HS_effect", "4", "", "none", "0", "1"],
	            ["legend", "diy"]
	        ],
	        "Hide Sea": ["藏海", "legend", "战吼：造成2点伤害，亡语：为你的英雄恢复3点生命值。", ["HS_effect", "1", "", "none", "0", "1"],
	            ["legend", "diy"]
	        ],
	        "Zayuliming": ["无冕黎明", "legend", "战吼：对一名受伤的随从造成3点伤害并冻结。若其存活，获得“你的法术牌费用-1”。", ["HS_effect", "3", "hs_mage", "none", "0", "5"],
	            ["legend", "diy"]
	        ],
	        "Wuzhong Brother": ["无中咕咕", "legend", "每回合限一次，每当你使用法术牌或随从牌后，将一张同类型的牌置入你的手牌。", ["HS_effect", "2", "", "none", "0", "1"],
	            ["legend", "diy"]
	        ],
	        //其他
	        "New Year Firecracker": ["新年爆竹", "legend", "亡语：对手随机弃一张牌。", ["HS_effect", "1", "", "none", "1", "1"],
	            ["legend", "diy"]
	        ],
	        "Silver Recruiter": ["白银募兵者", "rare", "你的回合结束时，对该随从造成1点伤害并召唤一个1/1的白银之手新兵。", ["HS_effect", "4", "hs_paladin", "none", "3", "6"],
	            ["guimu:白银之手新兵", "diy"]
	        ],
	    },
	};
	///////////////////////////////////////////////////////
	hearthstone.use(function(lib, game, ui, get, ai, _status) {
	    var effects = {
	        "hs_RagingWorgen": {
	            jinu: {
	                ability: "fengnu",
	            },
	        },
	        "hs_InjuredBlademaster": {
	            battleRoal: function() {
	                event.fellow.hs_dmgrcv("damage", 4, "self");
	            },
	        },
	        "hs_SocererSApprentice": {
	            numgh: {
	                name: "hs_cost",
	                value: 1,
	                ghfilter: function(card, fellow, target) {
	                    return target == fellow.getLeader() && get.type(card) == "HS_spell";
	                },
	            },
	        },
	        "hs_Doomsayer": {
	            beginning: {
	                self: true,
	                effect: function() {
	                    get.HSF("lavaeffect", ["cuihui"]);
	                },
	            },
	        },
	        "hs_KnifeJuggler": {
	            summonAfter: {
	                self: true,
	                notlink: true,
	                randomRT: function(player) {
	                    return player.HSF("randmgfil");
	                },
	                effect: function() {
	                    target.hs_dmgrcv("damage", event.fellow);
	                },
	            },
	        },
	        "hs_BoomBot": {
	            deathRattle: {
	                randomRT: function(player) {
	                    return player.HSF("randmgfil");
	                },
	                effect: function() {
	                    target.hs_dmgrcv("damage", get.rand(1, 4), event.fellow);
	                },
	            },
	        },
	        "hs_Nefarian": {
	            battleRoal: function() {
	                var oppo = player.getOppo();
	                var job = lib.character[oppo.name][1];
	                event.fellow.HSFT(get.HS_trans(job));
	                var kachi = get.hskachi("HS_spell", (a, b) => b.rnature == job);
	                if (!kachi.length || kachi[0] == "hs_TheCoin") kachi = ["扫尾"];
	                var cs = [kachi.randomGet(), kachi.randomGet()];
	                player.hs_gain(cs, oppo);
	            },
	        },
	        "hs_DefenderOfArgus": {
	            battleRoal: function() {
	                var pls = event.fellow.sctp("neighbor");
	                pls.forEach(i => {
	                    i.addautovaluebuff([1, 1], get.hs_id(event.fellow));
	                    i.addgjzbuff("chaofeng");
	                });
	            },
	        },
	        "hs_GrimPatron": {
	            hsdmg: {
	                fl: true,
	                filter: "存活",
	                recheck: "filter",
	                effect: function() {
	                    event.fellow.SSfellow("恐怖的奴隶主");
	                },
	            },
	        },
	        "hs_WarsongCommander": {
	            summonSucc: {
	                self: true,
	                notlink: true,
	                filter: function(event, player, fellow) {
	                    return get.rATK(event.card) <= 3;
	                },
	                randomRT: function(player, evt) {
	                    return evt.link;
	                },
	                effect: function() {
	                    target.animate("chongfeng2");
	                    target.addgjzbuff("chongfeng");
	                },
	            },
	        },
	        "hs_Deathwing": {
	            battleRoal: function() {
	                "step 0"
	                get.HSF("lavaeffect", ["cuihui", "minors_", "lava", "fellow"]);
	                "step 1"
	                player.hs_discard("all");
	            },
	        },
	        "hs_Leokk": {
	            numgh: {
	                name: "value",
	                value: [1, 0],
	            },
	        },
	        "hs_DireWolfAlpha": {
	            numgh: {
	                name: "value",
	                value: [1, 0],
	                range: function(fellow, target) {
	                    return fellow.sctp("neighbor", target);
	                },
	            },
	        },
	        "hs_MalGanis": {
	            numgh: {
	                auras: [{
	                    name: "value",
	                    value: [2, 2],
	                    range: function(fellow, target) {
	                        return target.rkind == "demon" && fellow.sctp("mine_", target);
	                    },
	                }, {
	                    name: "ability",
	                    value: ["mianyi"],
	                    range: function(fellow, target) {
	                        return target == fellow.getLeader();
	                    },
	                }],
	            },
	        },
	        "hs_MurlocWarleader": {
	            numgh: {
	                name: "value",
	                value: [2, 1],
	                range: function(fellow, target) {
	                    return target.rkind == "murloc" && fellow.sctp("mns_", target);
	                },
	            },
	        },
	        "hs_GrimscaleOracle": {
	            numgh: {
	                name: "value",
	                value: [1, 0],
	                range: function(fellow, target) {
	                    return target.rkind == "murloc" && fellow.sctp("mns_", target);
	                },
	            },
	        },
	        "hs_OldMurkEye": {
	            numgh: {
	                name: "value",
	                value: function(fellow) {
	                    return [game.countPlayer(fl => fl != fellow && fl.rkind == "murloc"), 0];
	                },
	                range: function(fellow, target) {
	                    return target == fellow;
	                },
	            },
	        },
	        "hs_EnhanceOMechano": {
	            battleRoal: {
	                effect: function() {
	                    event.fellow.sctp("mine_", i => {
	                        i.addgjzbuff(["fengnu", "chaofeng", "shengdun"].randomGet());
	                    });
	                },
	            },
	        },
	        "hs_WeeSpellstopper": {
	            numgh: {
	                name: "ability",
	                value: ["momian"],
	                range: function(fellow, target) {
	                    return fellow.sctp("neighbor", target);
	                },
	            },
	        },
	        "hs_SunfuryProtector": {
	            battleRoal: function() {
	                var l = event.fellow.leftseat;
	                var r = event.fellow.rightseat;
	                var pls = [l, r].filter(i => null !== i);
	                pls.forEach(i => {
	                    i.addgjzbuff("chaofeng");
	                });
	            },
	        },
	        "hs_GormokTheImpaler": {
	            prompt: "战吼：如果你拥有至少四个其他随从，则造成4点伤害。",
	            battleRoal: {
	                aifamily: "damage",
	                filter: function(p) {
	                    return p.countFellow() >= 4;
	                },
	                filterTarget: lib.filter.all,
	                effect: function() {
	                    target.hs_dmgrcv('damage', event.fellow, 4);
	                },
	            },
	        },
	        "hs_Aviana": {
	            numgh: {
	                name: "hs_cost",
	                value: 1,
	                subtype: "final",
	                ghfilter: function(card, fellow, target) {
	                    return target == fellow.getLeader() && get.type(card) == "HS_minor";
	                },
	            },
	        },
	        "hs_VentureCoMercenary": {
	            numgh: {
	                name: "hs_cost",
	                value: -3,
	                ghfilter: function(card, fellow, target) {
	                    return target == fellow.getLeader() && get.type(card) == "HS_minor";
	                },
	            },
	        },
	        "hs_Gahzrilla": {
	            hsdmg: {
	                fl: true,
	                effect: function() {
	                    event.fellow.updateSelfBuff(event.fellow.ATK);
	                },
	            },
	        },
	        "hs_TimberWolf": {
	            numgh: {
	                name: "value",
	                value: [1, 0],
	                range: function(fellow, target) {
	                    return target.rkind == "wildbeast" && fellow.sctp("mine_", target);
	                },
	            },
	        },
	        "hs_TundraRhino": {
	            numgh: {
	                name: "ability",
	                value: ["chongfeng"],
	                range: function(fellow, target) {
	                    return target.rkind == "wildbeast" && fellow.sctp("mine", target);
	                },
	            },
	        },
	        "hs_NorthshireCleric": {
	            hsrcv: {
	                filter: function(evt) {
	                    return evt.player.isMin();
	                },
	                effect: function() {
	                    player.hs_drawDeck();
	                },
	            },
	        },
	        "hs_Treant1": {
	            ending: {
	                effect: function() {
	                    event.fellow.HSF("cuihui");
	                },
	            },
	        },
	        "hs_FlameWaker": {
	            useCardAfter: {
	                self: true,
	                filter: "法术",
	                effect: function() {
	                    event.fellow.hs_Missiles(2);
	                },
	            },
	        },
	        "hs_Jeeves": {
	            ending: {
	                effect: function() {
	                    var num = 3 - player.countCards("h");
	                    if (num > 0) player.hs_drawDeck(num);
	                },
	            },
	        },
	        "hs_TwilightWhelp": {
	            battleRoal: {
	                filter: "龙牌",
	                effect: function() {
	                    event.fellow.addautovaluebuff([0, 2], get.hs_id(event.fellow));
	                },
	            },
	        },
	        "hs_WyrmrestAgent": {
	            battleRoal: {
	                filter: "龙牌",
	                effect: function() {
	                    event.fellow.addautovaluebuff(1, get.hs_id(event.fellow));
	                    event.fellow.addgjzbuff("chaofeng");
	                },
	            },
	        },
	        "hs_TwilightGuardian": {
	            inherit: "hs_WyrmrestAgent",
	        },
	        "hs_BlackwingCorruptor": {
	            prompt: "战吼：造成3点伤害。",
	            battleRoal: {
	                filter: "龙牌",
	                aifamily: "damage",
	                filterTarget: lib.filter.all,
	                effect: function() {
	                    target.hs_dmgrcv('damage', event.fellow, 3);
	                },
	            },
	        },
	        "hs_BlackwingTechnician": {
	            battleRoal: {
	                filter: "龙牌",
	                effect: function() {
	                    event.fellow.addautovaluebuff([1, 1], get.hs_id(event.fellow));
	                },
	            },
	        },
	        "hs_DrakonidCrusher": {
	            battleRoal: {
	                filter: function(p) {
	                    return p.getOppo()
	                        .hp <= 15;
	                },
	                effect: function() {
	                    event.fellow.addautovaluebuff([3, 3], get.hs_id(event.fellow));
	                },
	            },
	        },
	        "hs_Alexstrasza": {
	            battleRoal: {
	                filterTarget: function(card, player, target) {
	                    return player.sctp("heros", target);
	                },
	                effect: function() {
	                    target.hs_dm = Math.max(0, target.maxHp - 15);
	                    if (target.maxHp < 15) target.addvaluebuff([0, 15 - target.maxHp]);
	                    target.update();
	                },
	            },
	        },
	        "hs_FrothingBerserker": {
	            hsdmg: {
	                filter: function(evt, p, t) {
	                    return evt.player.isMin();
	                },
	                effect: function() {
	                    event.fellow.updateSelfBuff(1);
	                },
	            },
	        },
	        "hs_ArmorSmith": {
	            hsdmg: {
	                filter: function(evt, p, t) {
	                    return p.sctp("mine", evt.player);
	                },
	                effect: function() {
	                    player.changeHujia();
	                },
	            },
	        },
	        "hs_EmperorThaurissan": {
	            ending: {
	                self: true,
	                effect: function() {
	                    var t = event.fellow;
	                    player.countCards("h", ca => {
	                        ca.addhsbuff({
	                            name: "hs_cost",
	                            type: "hs_cost",
	                            uniquename: get.hs_id(t),
	                            value: 1,
	                            creator: t,
	                            fellow: t,
	                        });
	                    });
	                },
	            },
	        },
	        "hs_Loatheb": {
	            battleRoal: function() {
	                var o = player.getOppo();
	                var t = event.fellow;
	                o.addaurasbuff({
	                    name: "hs_cost",
	                    type: "hs_cost",
	                    uniquename: get.hs_id(t),
	                    value: -5,
	                    ghfilter: function(card, fellow, target) {
	                        return target == fellow && get.type(card) == "HS_spell";
	                    },
	                    temp: 1,
	                    countphase: o,
	                    creator: t,
	                    fellow: t,
	                });
	            },
	        },
	        "hs_MillhouseManastorm": {
	            battleRoal: function() {
	                var o = player.getOppo();
	                var t = event.fellow;
	                o.addaurasbuff({
	                    name: "hs_cost",
	                    type: "hs_cost",
	                    value: 0,
	                    subtype: "final",
	                    ghfilter: function(card, fellow, target) {
	                        return target == fellow && get.type(card) == "HS_spell";
	                    },
	                    temp: 1,
	                    countphase: o,
	                    creator: t,
	                    fellow: t,
	                });
	            },
	        },
	        "hs_ScavengingHyena": {
	            deathFL: {
	                filter: function(event, player, fellow) {
	                    return event.link.getLeader() == player && event.link.rkind == "wildbeast";
	                },
	                effect: function() {
	                    event.fellow.updateSelfBuff([2, 1]);
	                },
	            },
	        },
	        "hs_CultMaster": {
	            deathFL: {
	                filter: function(event, player, fellow) {
	                    return event.link.getLeader() == player;
	                },
	                effect: function() {
	                    player.hs_drawDeck();
	                },
	            },
	        },
	        "hs_FlesheatingGhoul": {
	            deathFL: {
	                effect: function() {
	                    event.fellow.updateSelfBuff(1);
	                },
	            },
	        },
	        "hs_RenoJackson": {
	            battleRoal: {
	                filter: "宇宙",
	                effect: function() {
	                    player.hs_dmgrcv("recover", player.maxHp, event.fellow);
	                },
	            },
	        },
	        "hs_ColdlightOracle": {
	            battleRoal: function() {
	                get.HSF("crossDraw", [player, 2]);
	            },
	        },
	        "hs_LorewalkerCho": {
	            useCard: {
	                filter: "法术",
	                effect: function() {
	                    event.evt.player.getOppo()
	                        .hs_gain(event.evt.card.name);
	                },
	            },
	        },
	        "hs_StormwindChampion": {
	            numgh: {
	                name: "value",
	                value: [1, 1],
	            },
	        },
	        "hs_FacelessManipulator": {
	            battleRoal: {
	                filterTarget: function(card, player, target) {
	                    return target.isMin();
	                },
	                effect: function() {
	                    event.fellow.HSF("convert", [target.name + "_monster", true, target]);
	                },
	            },
	        },
	        "hs_TwilightDrake": {
	            battleRoal: function() {
	                var num = player.countCards("h");
	                if (num > 0) event.fellow.addvaluebuff([0, num]);
	            },
	        },
	        "hs_Mechwarper": {
	            numgh: {
	                name: "hs_cost",
	                value: 1,
	                ghfilter: function(card, fellow, target) {
	                    return target == fellow.getLeader() && get.rkind(card) == "machine";
	                },
	            },
	        },
	        "hs_Cogmaster": {
	            numgh: {
	                name: "value",
	                value: [2, 0],
	                range: function(fellow, target) {
	                    return target == fellow;
	                },
	                ghfilter: function(card, fellow, target) {
	                    return fellow.sctp("mine", fl => fl.rkind == "machine");
	                },
	            },
	        },
	        "hs_RaidLeader": {
	            inherit: "hs_Leokk",
	        },
	        "hs_NerubarWeblord": {
	            numgh: {
	                name: "hs_cost",
	                value: -2,
	                ghfilter: function(card, fellow, target) {
	                    return get.rGJZ(card, "battleRoal");
	                },
	            },
	        },
	        "hs_ManaWraith": {
	            numgh: {
	                name: "hs_cost",
	                value: -1,
	                ghfilter: function(card, fellow, target) {
	                    return get.type(card) == "HS_minor";
	                },
	            },
	        },
	        "hs_SouthseaCaptain": {
	            numgh: {
	                name: "value",
	                value: [1, 1],
	                range: function(fellow, target) {
	                    return target.rkind == "pirate" && fellow.sctp("mine_", target);
	                },
	            },
	        },
	        "hs_TongueTotem": {
	            numgh: {
	                name: "value",
	                value: [2, 0],
	                range: function(fellow, target) {
	                    return fellow.sctp("neighbor", target);
	                },
	            },
	        },
	        "hs_Junkbot": {
	            deathFL: {
	                filter: function(event, player, fellow) {
	                    return event.link.getLeader() == player && event.link.rkind == "machine";
	                },
	                effect: function() {
	                    event.fellow.updateSelfBuff([2, 2]);
	                },
	            },
	        },
	        "hs_RamWrangler": {
	            battleRoal: {
	                filter: function(p) {
	                    return p.hasFellow(t => t.rkind == "wildbeast");
	                },
	                effect: function() {
	                    event.fellow.SSfellow("range:野兽");
	                },
	            },
	        },
	        "hs_Shieldmaiden": {
	            battleRoal: function() {
	                player.hs_atkhj([0, 5]);
	            },
	        },
	        "hs_JungleMoonkin": {
	            numgh: {
	                name: "hs_power",
	                value: 2,
	            },
	        },
	        "hs_SavageCombatant": {
	            jili: function() {
	                player.addvaluebuff(2, 1);
	            },
	        },
	        "hs_DarnassusAspirant": {
	            battleRoal: function() {
	                player.HSF("gainmana", [1, true]);
	            },
	            deathRattle: function() {
	                player.HSF("removemana", [1]);
	            },
	        },
	        "hs_JusticarTrueheart": {
	            battleRoal: function() {
	                var sk = player.heroskill.skill;
	                var oo = get.HSA("exhrsk")[sk.slice(-4)];
	                if (oo) {
	                    var nsk = sk.replace("_legend", "") + "ex";
	                    lib.hearthstone.eval_heroskill(nsk, oo);
	                    player.HSF("changeHeroskill", [nsk]);
	                }
	            },
	        },
	        "hs_MimironsHead": {
	            beginning: {
	                self: true,
	                filter: function(evt, player) {
	                    return player.countFellow(fl => fl.rkind == "machine") >= 3;
	                },
	                effect: function() {
	                    "step 0"
	                    get.HSF("cuihui", [player.filterFellow(fl => fl.rkind == "machine"), true]);
	                    "step 1"
	                    event.fellow.SSfellow("飞机");
	                },
	            },
	        },
	        "hs_Undertaker": {
	            summonSucc: {
	                self: true,
	                notlink: true,
	                filter: function(evt, player, fellow) {
	                    return get.rGJZ(evt.card, "deathRattle");
	                },
	                effect: function() {
	                    event.fellow.updateSelfBuff(1);
	                },
	            },
	        },
	        "hs_ArathiWeaponsmith": {
	            battleRoal: function() {
	                player.hs_weapon("战斧");
	            },
	        },
	        "hs_Buccaneer": {
	            equipAfter: {
	                self: true,
	                effect: function() {
	                    player.addwpbuff(event.evt.div, 1);
	                },
	            },
	        },
	        "hs_SummoningPortal": {
	            numgh: {
	                early: 1,
	                name: "hs_cost",
	                value: function(card, cost) {
	                    return Math.min(2, cost - 1);
	                },
	                ghfilter: function(card, fellow, target) {
	                    return get.type(card) == "HS_minor" && target == fellow.getLeader();
	                },
	            },
	        },
	        "hs_VoidTerror": {
	            battleRoal: function() {
	                var pls = event.fellow.sctp("neighbor");
	                if (pls.length) {
	                    pls.forEach(i => i.HSF("cuihui"));
	                    var arr = pls.reduce((x, y) => {
	                        x[0] += y.ATK;
	                        x[1] += y.hp;
	                        return x;
	                    }, [0, 0]);
	                    event.fellow.addvaluebuff(arr);
	                }
	            },
	        },
	        "hs_BolfRamshield": {
	            hsdmgBefore: {
	                self: true,
	                effect: function() {
	                    event.orievt.player = event.fellow;
	                },
	            },
	        },
	        "hs_TunnelTrogg": {
	            overload: {
	                self: true,
	                effect: function() {
	                    var num = player.countMark("hs_mana_locked") + player.countMark("hs_mana_owed");
	                    event.fellow.addvaluebuff(num);
	                },
	            },
	        },
	        "hs_TinkmasterOverspark": {
	            battleRoal: {
	                randomRT: function(p, evt) {
	                    return evt.fellow.sctp("mns_")
	                        .randomGet();
	                },
	                effect: function() {
	                    target.HSF("convert", [
	                        ["松鼠", "魔暴龙"].randomGet()]);
	                },
	            },
	        },
	        "hs_ShadyDealer": {
	            battleRoal: {
	                filter: function(player) {
	                    return player.sctp("mns", t => t.rkind == "pirate");
	                },
	                effect: function() {
	                    event.fellow.addvaluebuff([1, 1]);
	                },
	            },
	        },
	        "hs_Cutpurse": {
	            attackBegin: {
	                fl: true,
	                filter: function(evt, p, f) {
	                    return !evt.target.isMin();
	                },
	                effect: function() {
	                    player.hs_gain("幸运币");
	                },
	            },
	        },
	        "hs_BloodsailRaider": {
	            battleRoal: {
	                filter: function(player) {
	                    return player.data_weapon;
	                },
	                effect: function() {
	                    event.fellow.addvaluebuff(player.data_weapon.ATK);
	                },
	            },
	        },
	        "hs_SouthseaDeckhand": {
	            numgh: {
	                name: "ability",
	                value: ["chongfeng"],
	                range: function(fellow, target) {
	                    return target == fellow;
	                },
	                ghfilter: function(card, fellow, target) {
	                    return fellow.getLeader()
	                        .data_weapon != undefined;
	                },
	            },
	        },
	        "hs_MurlocTidecaller": {
	            summonBefore: {
	                notlink: true,
	                filter: function(evt) {
	                    return evt.link.rkind == "murloc";
	                },
	                effect: function() {
	                    event.fellow.updateSelfBuff(1);
	                },
	            },
	        },
	        "hs_CobaltGuardian": {
	            summonBefore: {
	                notlink: true,
	                self: true,
	                filter: function(evt) {
	                    return evt.link.rkind == "machine";
	                },
	                effect: function() {
	                    event.fellow.addgjzbuff("shengdun");
	                },
	            },
	        },
	        "hs_KingMukla": {
	            battleRoal: function() {
	                player.getOppo()
	                    .hs_gain(["香蕉", 2]);
	            },
	        },
	        "hs_AcidicSwampOoze": {
	            battleRoal: {
	                randomRT: function(p) {
	                    return p.getOppo()
	                        .data_weapon;
	                },
	                effect: function() {
	                    target.HSF("cuihui");
	                },
	            },
	        },
	        "hs_BloodsailCorsair": {
	            battleRoal: {
	                randomRT: function(p) {
	                    return p.getOppo()
	                        .data_weapon;
	                },
	                effect: function() {
	                    target.hs_dmgrcv(1);
	                },
	            },
	        },
	        "hs_TinyKnightOfEvil": {
	            discard: {
	                self: true,
	                effect: function() {
	                    event.fellow.updateSelfBuff([1, 1]);
	                },
	            },
	        },
	        "hs_HarrisonJones": {
	            battleRoal: {
	                randomRT: function(p) {
	                    return p.getOppo()
	                        .data_weapon;
	                },
	                effect: function() {
	                    "step 0"
	                    target.HSF("cuihui");
	                    "step 1"
	                    player.hs_drawDeck(target.hp);
	                },
	            },
	        },
	        "hs_Spellslinger": {
	            battleRoal: function() {
	                player.sctp("heros", t => t.hs_gain(get.hskachi("HS_spell")
	                    .randomGet()));
	            },
	        },
	        "hs_MogorTheOgre": {
	            attackBefore: {
	                half: true,
	                filter: function(evt, p, f) {
	                    return evt.player.isMin() && evt.target.sctp("myside_", t => t.HSF("alive"));
	                },
	                effect: function() {
	                    var ntg = event.evt.target.sctp("myside_")
	                        .filter(t => t.HSF("alive"))
	                        .randomGet();
	                    event.orievt.victim = ntg;
	                },
	            },
	        },
	        "hs_ManaAddict": {
	            useCard: {
	                self: true,
	                filter: "法术",
	                effect: function() {
	                    event.fellow.updateSelfBuff(2, 1)
	                },
	            },
	        },
	        "hs_StampedingKodo": {
	            battleRoal: {
	                randomRT: function(p) {
	                    return p.HSF("ranxmfil", [null, t => t.ATK <= 2]);
	                },
	                effect: function() {
	                    target.HSF("cuihui");
	                },
	            },
	        },
	        "hs_FelReaver": {
	            useCard: {
	                filter: function(evt, p) {
	                    return evt.player == p.getOppo();
	                },
	                effect: function() {
	                    player.hs_shaohui(3);
	                },
	            },
	        },
	        "hs_AlexstraszasChampion": {
	            battleRoal: {
	                filter: "龙牌",
	                effect: function() {
	                    event.fellow.addvaluebuff([1, 1]);
	                    event.fellow.addgjzbuff("chongfeng");
	                },
	            },
	        },
	        "hs_SpawnOfShadows": {
	            jili: function() {
	                player.sctp("main", t => {
	                    event.fellow.HSline(t, "green");
	                    t.hs_dmgrcv(4, event.fellow);
	                });
	            },
	        },
	        "hs_Shadowfiend": {
	            drawAfter: {
	                self: true,
	                effect: function() {
	                    event.evt.card.addhsbuff({
	                        name: "hs_cost",
	                        type: "hs_cost",
	                        value: 1,
	                        creator: event.fellow,
	                        fellow: event.fellow,
	                    });
	                },
	            },
	        },
	        "hs_Chromaggus": {
	            drawAfter: {
	                self: true,
	                effect: function() {
	                    player.hs_gain(event.evt.card.name);
	                },
	            },
	        },
	        "hs_KelThuzad": {
	            ending: {
	                effect: function() {
	                    player.hs_revive(function(p, a, b) {
	                        var list = b.slice(0)
	                            .sort(lib.sort.attendseq)
	                            .map(i => i.name);
	                        return list;
	                    });
	                },
	            },
	        },
	        "hs_SylvanasWindrunner": {
	            deathRattle: {
	                randomRT: function(p) {
	                    return p.HSF("ranxmfil");
	                },
	                effect: function() {
	                    target.toNTRed(player);
	                },
	            },
	        },
	        "hs_IronJuggernaut": {
	            battleRoal: function() {
	                player.getOppo()
	                    .HSF("addtodeck", ["地雷"]);
	            },
	        },
	        "hs_MindControlTech": {
	            battleRoal: {
	                filter: function(p) {
	                    return p.getOppo()
	                        .countFellow() >= 4;
	                },
	                recheck: "filter",
	                randomRT: function(p) {
	                    return p.HSF("ranxmfil");
	                },
	                effect: function() {
	                    target.toNTRed(player);
	                },
	            },
	        },
	        "hs_CabalShadowPriest": {
	            battleRoal: {
	                filterTarget: function(card, player, target) {
	                    return player.sctp("notmine", target) && target.ATK <= 2;
	                },
	                effect: function() {
	                    target.toNTRed(player);
	                },
	            },
	        },
	        "hs_Shrinkmeister": {
	            battleRoal: {
	                filterTarget: function(card, player, target) {
	                    return player.sctp("mns", target);
	                },
	                effect: function() {
	                    target.addvaluebuff(-2, 1);
	                },
	            },
	            spelldamage: 2,
	        },




	        //随从新卡定位




	        //腐化者
	        "hs_GoblinMiner": {
	            battleRoal: {
	                randomRT: function(player) {
	                    return player.HSF("randmgfil", ["opposide"]);
	                },
	                bonus: function(p, f) {
	                    return p.countFellow(fl => fl != f && fl.rkind == "goblin");
	                },
	                effect: function() {
	                    target.hs_dmgrcv("damage", 1, event.fellow);
	                },
	            },
	        },
	        "hs_SpiderQueen": {
	            numgh: {
	                name: "value",
	                value: [1, 1],
	                range: function(fellow, target) {
	                    var name = get.translation(target.name);
	                    return fellow.sctp("mine", target) && (
	                    name.slice(-2) == "蜘蛛" || ["迈克斯纳"].contains(name));
	                },
	            },
	            deathFL: {
	                filter: function(event, player, fellow) {
	                    return event.link.getLeader() == player;
	                },
	                effect: function() {
	                    event.fellow.updateSelfBuff(1);
	                },
	            },
	        },
	        "hs_GoblinBandit": {
	            battleRoal: {
	                filterTarget: function(card, player, target) {
	                    return target.isMin() && target.hasgjz("chaofeng");
	                },
	                aifamily: "damage",
	                effect: function() {
	                    "step 0"
	                    target.HSF("cuihui");
	                    "step 1"
	                    target.getLeader()
	                        .hs_dmgrcv("damage", 3, event.fellow);
	                },
	            },
	        },
	        "hs_DenseforestMarshDragon": {
	            deathFL: {
	                count: 0, //发动计数
	                filter: function(event, player, fellow, obj) {
	                    return obj.count < 4 && event.link.getLeader() == player;
	                },
	                effect: function() {
	                    var num = event.obj.count;
	                    if (num == 0) event.fellow.addvaluebuff([0, 2]);
	                    else if (num == 1) event.fellow.addaurasbuff({
	                        name: "hs_cost",
	                        value: 1,
	                        ghfilter: function(card, fellow, target) {
	                            return target == fellow.getLeader() && get.type(card) == "HS_spell";
	                        }
	                    });
	                    else if (num == 2) event.fellow.addgjzbuff("jvdu");
	                    else if (num == 3) event.fellow.addvaluebuff([2, 2]);
	                    event.obj.count++;
	                },
	            },
	        },
	        "hs_DenseforestMage": {
	            deathRattle: {
	                randomRT: function(player) {
	                    return player;
	                },
	                effect: function() {
	                    "step 0"
	                    target.hs_dmgrcv("damage", 2, event.fellow);
	                    "step 1"
	                    target.hs_drawDeck()
	                        .onbuff = function(cs) {
	                        cs[0].addhsbuff({
	                            name: "hs_cost",
	                            type: "hs_cost",
	                            value: 1,
	                            creator: event.fellow,
	                            fellow: event.fellow,
	                        });
	                    };
	                },
	            },
	        },
	        "hs_EyeOfTheDevil": {
	            inherit: "hs_NewYearFirecracker",
	        },
	        "hs_DenseforestShooter": {
	            battleRoal: function() {
	                if (player.countCards("h") > player.getOppo()
	                    .countCards("h")) event.fellow.addvaluebuff([2, 2]);
	            },
	        },




	        //炉石普通的随从
	        "hs_SocererSApprenticePT": {
	            inherit: "hs_SocererSApprentice",
	        },

	        //diy
	        "hs_SaltfishPigeon": {
	            battleRoal: function() {
	                event.fellow.addautovaluebuff(get.HSF("minors")
	                    .length - 1, get.hs_id(event.fellow));
	            },
	        },
	        "hs_Zayuliming": {
	            battleRoal: {
	                filterTarget: function(card, player, target) {
	                    return player.sctp("mns", target) && target.isDamaged();
	                },
	                effect: function() {
	                    "step 0"
	                    target.hs_dmgrcv("damage", 3, "ice", event.fellow);
	                    "step 1"
	                    target.addgjzbuff('dongjied');
	                    "step 2"
	                    if (target.HSF("alive")) event.fellow.addaurasbuff({
	                        name: "hs_cost",
	                        value: 1,
	                        ghfilter: function(card, fellow, target) {
	                            return target == fellow.getLeader() && get.type(card) == "HS_spell";
	                        }
	                    });
	                },
	            },
	        },
	        "hs_WuzhongBrother": {
	            useCardAfter: {
	                self: true,
	                notlink: true,
	                filter: function(evt, p, f) {
	                    if (f.getStat()
	                        .hs_WuzhongBrother) return false;
	                    return ["HS_minor", "HS_spell"].contains(get.type(evt.card));
	                },
	                effect: function() {
	                    var type = get.type(event.evt.card);
	                    var m = get.hskachi(type);
	                    player.hs_gain(m.randomGet());
	                    event.fellow.getStat()
	                        .hs_WuzhongBrother = 1;
	                },
	            },
	        },
	        "hs_NewYearFirecracker": {
	            deathRattle: {
	                randomRT: function(player) {
	                    return player.getOppo();
	                },
	                effect: function() {
	                    "step 0"
	                    game.delay();
	                    "step 1"
	                    target.hs_discard();
	                },
	            },
	        },
	    };
	    for (var i in effects) {
	        lib.skill[i] = effects[i];
	    }
	    hearthstone.loadTrans = {
	        "HS_minor": "随从",
	        "HS_normal": "白板",
	        "HS_effect": "效果",
	        "HS_spell": "法术",
	        "HS_normalS": "普通法术",
	        "HS_secret": "奥秘",
	        "HS_weapon": "武器",
	    };

	    //代码定位
	    var cons, cons2;
	    var f = window.hearthstone.ys;
	    var ys = function(str) {
	        var st = cons[str][1].replace(/\@|\$|\#\π/g, "undefined");
	        return f([cons[str][0], st]);
	    };
	    var ysf = function(str, args) {
	        var st = cons[str][1];
	        var def = ["@", "$", "#", "π"];
	        for (var i = 0; i < def.length; i++) {
	            var d = def[i];
	            st = st.replace(new RegExp("\\" + d, "g"), args[i]);
	        }
	        return f([cons[str][0], st]);
	    };
	    cons = { //常量
	        //魔法卡相关
	        canchenmo: ["jinu", "chenmo", "chaofeng", "shengdun", "fengnu", "superfengnu", "chongfeng", "mianyi", "dongjie", "dongjied", "qianxing", "jvdu", "xixie", "momian"],
	        hz: ["draw1", "frost", "discard1"],
	        yineng: {冻结: "dongjie",
	            魔免: "momian",
	            健忘: "jianwang",
	            潜行: "qianxing",
	            免疫: "mianyi",
	            冲锋: "chongfeng",
	            风怒: "fengnu",
	            圣盾: "shengdun",
	            嘲讽: "chaofeng",
	            剧毒: "jvdu",
	            吸血: "xixie",
	            超怒: "superfengnu",
	        },
	        //隐藏关键字
	        yincang: {
	            "冻结任何受到该随从伤害的角色": "冻结",
	            "无法成为法术或英雄技能的目标": "魔免",
	            "50%几率攻击错误的敌人": "健忘",
	            "超级风怒": "超怒",
	            "冲冲冲冲锋": "冲锋",
	        },
	    };
	    hearthstone.get.hsbuff = function(arr, type) { //添加多种buff
	        if (Array.isArray(arr) && !type) { //默认用法，生成效果代码
	            var res = [];
	            var reg = new RegExp("^[A-Za-z][1-9]$");
	            var reg2 = new RegExp("^[0-9]{2}$");
	            res.hsai = "recover";
	            var hsa = this && this.HSA || (k => cons[k]);
	            arr.forEach(i => {
	                var nl = false;
	                var str = "";
	                if (reg.test(i)) {
	                    var key = i[0],
	                        val = parseInt(i[1]);
	                    if (key == "A") i = val + "0";
	                    else if (key == "H") i = "0" + val;
	                    else if (key == "q") {
	                        str = "target.addFqbuff('hs_power'," + val + ");";
	                    } else if (key == "d") {
	                        nl = true;
	                        str = "target.hs_dmgrcv('damage'," + val + ",event.fellow);";
	                        res.hsai = "damage";
	                    } else if ("ah".contains(key)) {
	                        if (key == "a") str = "target.addvaluefinal(" + val + ");";
	                        else if (key == "h") str = "target.addvaluefinal([0," + val + "]);";
	                        res.hsai = "damage";
	                    }
	                } else if (i == "cm") {
	                    nl = true;
	                    str = "target.hs_silence();";
	                    res.hsai = "damage";
	                } else if (hsa("canchenmo")
	                    .contains(i)) {
	                    str = "target.addgjzbuff('" + i + "');";
	                    if (i == "dongjied" && arr.length == 1) res.hsai = "damage";
	                } else if (hsa("canchenmo")
	                    .contains(i.slice(0, -2))) {
	                    str = "target.addgjzbuff('" + i.slice(0, -2) + "'," + i.slice(-1) + ");";
	                }
	                if (reg2.test(i)) {
	                    str = "target.addvaluebuff([" + i[0] + "," + i[1] + "]);";
	                }
	                if (!res.length) res.push(str);
	                else {
	                    if (nl) res.push(str);
	                    else res[res.length - 1] = res[res.length - 1] + str;
	                }
	            });
	            return res;
	        }
	    };
	    var strfunc = hearthstone.get.strfunc;
	    var hsrfunc = hearthstone.get.hsrfunc;
	    var hsbuff = hearthstone.get.hsbuff;
	    var minispell = {
	        //伤害
	        hs_ArcaneMissiles: ["奥术飞弹", "essential", "飞弹:3", 1, "hs_mage"],
	        hs_Fireball: ["火球术", "essential", "damage:6", 4, "hs_mage", ["fire"]],
	        hs_Frostbolt: ["寒冰箭", "essential", ["damage:3", "对一个角色造成3点伤害，并使其冻结。"], 2, "hs_mage", ["ice", "frost"]],
	        hs_Soulfire: ["灵魂之火", "essential", ["damage:4", "造成4点伤害，随机弃一张牌。"], 1, "hs_warlock", ["fire", "discard1"]],
	        hs_MortalCoil: ["死亡缠绕", "essential", ["damage:1", "对一个随从造成1点伤害。如果“死亡缠绕”消灭该随从，抽一张牌。"], 1, "hs_warlock", ["only:fellow", "des:draw1"]],
	        hs_TailSwipe: ["扫尾", "essential", "damage:4", 4, "hs_neutral", ["token"]],
	        hs_KillCommand: ["杀戮命令", "essential", ["damage:3", "造成3点伤害。如果你控制一个野兽，则改为造成5点伤害。"], 3, "hs_hunter", ["activecon:ys", "activenum:5"]],
	        hs_Whirlwind: ["旋风斩", "essential", ["damage:1", "对所有随从造成1点伤害。"], 1, "hs_warrior", ["blade"]],
	        hs_Moonfire: ["月火术", "essential", "damage:1", 0, "hs_druid"],
	        hs_Darkbomb: ["暗色炸弹", "ordinary", "damage:3", 2, "hs_warlock"],
	        hs_HolySmite: ["神圣惩击", "essential", "damage:2", 1, "hs_priest"],
	        hs_ArcaneShot: ["奥术射击", "essential", "damage:2", 1, "hs_hunter"],
	        hs_ShadowBolt: ["暗影箭", "essential", ["damage:4", "对一个随从造成4点伤害。"], 3, "hs_warlock", ["only:fellow"]],
	        hs_Hellfire: ["地狱烈焰", "essential", ["damage:3", "对所有角色造成3点伤害。"], 4, "hs_warlock", ["fire", "lava:all"]],
	        hs_Flamestrike: ["烈焰风暴", "essential", ["damage:4", "对所有敌方随从造成4点伤害。"], 7, "hs_mage", ["fire", "aoe:notmine"]],
	        hs_AvengingWrath: ["复仇之怒", "epic", "飞弹:8", 6, "hs_paladin"],
	        hs_HolyFire: ["神圣之火", "rare", ["damage:5", "造成5点伤害。为你的英雄恢复5点生命值。"], 6, "hs_priest", ["xxx"]],
	        hs_DrainLife: ["吸取生命", "essential", ["damage:2", "造成2点伤害。为你的英雄恢复2点生命值。"], 3, "hs_warlock", ["xxx"]],
	        hs_Starfire: ["星火术", "essential", ["damage:5", "造成5点伤害。抽一张牌。"], 6, "hs_druid", ["draw1"]],
	        hs_Pyroblast: ["炎爆术", "epic", "damage:10", 10, "hs_mage", ["fire"]],
	        hs_Vine: ["蔓生", "rare", ["damage:2", "对一名随从造成2点伤害，如果其依然存活，其-2攻击力。"], 2, "hs_corruptor", ["only:fellow", "nodes:shrink2"]],
	        hs_HolyNova: ["神圣新星", "essential", ["damage:2", "对所有敌人造成2点伤害，为所有友方角色恢复2点生命值。"], 5, "hs_priest", ["aoe:opposide", "rcvmyside:2"]],
	        hs_MindBlast: ["心灵震爆", "ordinary", "damage:5", 2, "hs_priest", ["only:enemy"]],
	        hs_Flamecannon: ["烈焰轰击", "ordinary", ["damage:4", "随机对一个敌方随从造成4点伤害。"], 2, "hs_mage", ["fire", "only:randmgfl"]],
	        hs_Consecration: ["奉献", "essential", ["damage:2", "对所有敌人造成2点伤害。"], 4, "hs_paladin", ["aoe:opposide"]],
	        hs_HammerOfWrath: ["愤怒之锤", "essential", ["damage:3", "造成3点伤害。抽一张牌。"], 4, "hs_paladin", ["draw1"]],
	        hs_QuickShot: ["快速射击", "ordinary", ["damage:3", "造成3点伤害。如果你没有其他手牌，则抽一张牌。"], 2, "hs_hunter", ["activecon:yh", "activeeff:draw1"]],
	        hs_Slam: ["猛击", "ordinary", ["damage:2", "对一个随从造成2点伤害，如果它依然存活，则抽一张牌。"], 2, "hs_warrior", ["only:fellow", "nodes:draw1"]],
	        hs_SinisterStrike: ["影袭", "essential", ["damage:3", "对敌方英雄造成 3点伤害。"], 1, "hs_rogue", ["only:enemy"]],
	        hs_FrostShock: ["冰霜震击", "essential", ["damage:1", "对一个敌方角色造成1点伤害，并使其冻结。"], 1, "hs_shaman", ["ice", "only:opposide", "frost"]],
	        hs_LightningBolt: ["闪电箭", "ordinary", ["damage:3", "造成3点伤害，过载：（1）"], 1, "hs_shaman", ["thunder"]],
	        hs_LavaBurst: ["熔岩爆裂", "rare", ["damage:5", "造成5点伤害，过载：（2）"], 3, "hs_shaman", ["fire"]],
	        hs_Backstab: ["背刺", "essential", ["damage:2", "对一个未受伤的随从造成2点伤害。"], 0, "hs_rogue", ["only:fellow,healthy"]],
	        hs_Shiv: ["毒刃", "essential", ["damage:1", "造成1点伤害。抽一张牌。"], 2, "hs_rogue", ["draw1"]],
	        hs_FanOfKnives: ["刀扇", "essential", "damage:1", 3, "hs_rogue", ["aoe:notmine", "draw1"]],
	        hs_Crackle: ["连环爆裂", "ordinary", ["damage:(get.rand(0,3)+3)", "造成3到6点伤害，过载：（1）"], 2, "hs_shaman", ["thunder"]],
	        hs_Blizzard: ["暴风雪", "rare", ["damage:2", "对所有敌方随从造成2点伤害，并使其冻结。"], 6, "hs_mage", ["ice", "aoe:notmine", "bh"]],
	        hs_MortalStrike: ["致死打击", "rare", ["damage:4", "造成4点伤害；如果你的生命值小于或等于12点，则改为造成6点伤害。"], 4, "hs_warrior", ["activecon:dmg", "activenum:6"]],
	        hs_Bash: ["怒袭", "ordinary", ["damage:3", "造成3点伤害。获得3点护甲值。"], 3, "hs_warrior", ["atkhj:[0,3]"]],
	        hs_ShieldSlam: ["盾牌猛击", "epic", ["damage:(player.hujia)", "你每有1点护甲值，便对一个随从造成1点伤害。"], 1, "hs_warrior", ["only:fellow"]],
	        hs_Revenge: ["复仇打击", "rare", ["damage:1", "对所有随从造成1点伤害。如果你的生命值小于或等于12点，则改为造成3点伤害。"], 2, "hs_warrior", ["activecon:dmg", "activenum:3", "blade"]],
	        hs_Cleave: ["顺劈斩", "essential", ["damage:2", "随机对两个敌方随从造成2点伤害。"], 2, "hs_warrior", ["only:randmgfl2"]],
	        hs_MultiShot: ["多重射击", "essential", ["damage:3", "随机对两个敌方随从造成3点伤害。"], 4, "hs_hunter", ["only:randmgfl2"]],
	        hs_ForkedLightning: ["叉状闪电", "ordinary", ["damage:2", "随机对两个敌方随从造成2点伤害，过载：（2）"], 1, "hs_shaman", ["thunder", "only:randmgfl2"]],
	        hs_LavaShock: ["熔岩震击", "rare", ["damage:2", "造成2点伤害。将你所有过载的法力水晶解锁。"], 2, "hs_shaman", ["fire", "other:player.removeMark('hs_mana_locked',player.countMark('hs_mana_locked'),false);player.removeMark('hs_mana_owed',player.countMark('hs_mana_owed'),false);player.HSF('updatemana');"]],


	        //炉石普通
	        hs_FireballPT: ["火球术", "essential", "damage:2", 2, "hs_mage", ["fire"]],
	        hs_WhirlwindPT: ["旋风斩", "essential", ["damage:1", "对所有随从造成1点伤害，抽一张牌。"], 1, "hs_warrior", ["blade", "draw1"]],

	        //治疗
	        hs_LayOnHands: ["圣疗术", "epic", ["recover:8", "恢复8点生命值，抽三张牌。"], 8, "hs_paladin", ["draw3"]],
	        hs_HolyLight: ["圣光术", "essential", "recover:6", 2, "hs_paladin"],
	        hs_HealingTouch: ["治疗之触", "essential", "recover:8", 3, "hs_druid"],
	        hs_FlashHeal: ["快速治疗", "ordinary", "recover:5", 1, "hs_priest"],
	        hs_SealOfLight: ["光明圣印", "ordinary", ["recover:4", "为你的英雄恢复4点生命值，并在本回合中获得+2攻击力。"], 2, "hs_paladin", ["only:me", "atkhj:[2,0]"]],
	        hs_AncestralHealing: ["先祖治疗", "essential", "recover:target.maxHp", 0, "hs_shaman", ["only:fellow", "buff:chaofeng"]],


	        //消灭
	        hs_SiphonSoul: ["灵魂虹吸", "rare", ["kill:1", "消灭一个随从，为你的英雄恢复3点生命值。"], 6, "hs_warlock", ["xx:3"]],
	        hs_SacrificialPact: ["牺牲契约", "essential", ["kill:1", "消灭一个恶魔，为你的英雄恢复5点生命值。"], 0, "hs_warlock", ["xx:5", "only:demon"]],
	        hs_Naturalize: ["自然平衡", "ordinary", ["kill:1", "消灭一个随从，你的对手抽两张牌。"], 1, "hs_druid", ["gift:2"]],
	        hs_Mulch: ["腐根", "epic", ["kill:1", "消灭一个随从。随机将一张随从牌置入对手的手牌。"], 3, "hs_druid", ["gift2"]],
	        hs_EvilEnergyRelease: ["能量释放", "ordinary", ["kill:1", "消灭一个你的随从，对所有敌方造成2点伤害。"], 3, "hs_corruptor", ["only:self", "fx"]],
	        hs_ShadowWordDeath: ["暗言术：灭", "essential", ["kill:1", "消灭一个攻击力大于或等于5的随从。"], 3, "hs_priest", ["only:灭"]],
	        hs_ShadowWordPain: ["暗言术：痛", "essential", ["kill:1", "消灭一个攻击力小于或等于3的随从。"], 2, "hs_priest", ["only:痛"]],
	        hs_Execute: ["斩杀", "essential", ["kill:1", "消灭一个受伤的敌方随从。"], 1, "hs_warrior", ["only:enm,伤"]],
	        hs_Crush: ["重碾", "epic", ["kill:1", "消灭一个随从。如果你控制任何受伤的随从，该法术的法力值消耗减少（4）点。"], 7, "hs_warrior", ["cgct:return p.sctp('mine',t=>t.isDamaged())?4:0;"]],
	        hs_TwistingNether: ["扭曲虚空", "epic", ["kill:all", "消灭所有随从。"], 8, "hs_warlock"],
	        hs_Assassinate: ["刺杀", "essential", ["kill:1", "消灭一个敌方随从。"], 5, "hs_rogue", ["only:enm"]],
	        hs_DeadlyShot: ["致命射击", "ordinary", ["kill:1", "随机消灭一个敌方随从。"], 3, "hs_hunter", ["only:ranxmfl"]],

	        //召唤
	        hs_AnimalCompanion: ["动物伙伴", "essential", ["summon:['cdset:动物伙伴']", "随机召唤一个野兽伙伴。"], 3, "hs_hunter"],
	        hs_ForceOfNature: ["自然之力", "epic", ["summon:['hs_Treant1_monster',3]", "召唤三个2/2并具有冲锋的树人，在回合结束时，消灭这些树人。"], 6, "hs_druid"],
	        hs_MirrorImage: ["镜像", "essential", ["summon:['hs_MirrorImage_monster',2]", "召唤两个0/2，并具有嘲讽的随从。"], 1, "hs_mage"],
	        hs_SpiderTerritory: ["魔蛛之域", "epic", ["summon:['白斑蜘蛛',3]", "召唤3只白斑蜘蛛。"], 4, "hs_corruptor"],
	        hs_UnleashTheHounds: ["关门放狗", "ordinary", ["summon:['猎犬',player.sctp('notmine').length]", "战场上每有一个敌方随从，便召唤一个1/1并具有冲锋的猎犬。"], 3, "hs_hunter", ["fg"]],
	        hs_MusterForBattle: ["作战动员", "rare", ["summon:['白银之手新兵',3]", "召唤三个1/1的白银之手新兵，装备一把1/4的武器。"], 3, "hs_paladin", ["weapon:'圣光的正义'"]],
	        hs_FeralSpirit: ["野性狼魂", "rare", ["summon:['幽灵狼',2]", "召唤两只2/3并具有嘲讽的幽灵狼。过载：（2）"], 3, "hs_shaman"],

	        //抽牌
	        hs_ExcessMana: ["法力过剩", "rare", ["draw:1", "抽一张牌。（你最多可以拥有十个法力水晶。）"], 0, "hs_druid", ["token"]],
	        hs_ArcaneIntellect: ["奥术智慧", "essential", "draw:2", 3, "hs_mage"],
	        hs_DivineFavor: ["神恩术", "rare", ["draw:p=>Math.max(0,p.getOppo().countCards('h')-p.countCards('h'))", "抽若干数量的牌，直到你的手牌数量等同于你对手的手牌数量。"], 3, "hs_paladin"],
	        hs_BattleRage: ["战斗怒火", "ordinary", ["draw:p=>p.sctp('myside').filter(t=>t.isDamaged()).length", "每有一个受伤的友方角色，便抽一张牌。"], 2, "hs_warrior"],
	        hs_Sprint: ["疾跑", "essential", "draw:4", 7, "hs_rogue"],
	        hs_AncestralKnowledge: ["先祖知识", "ordinary", ["draw:2", "抽两张牌。过载：（2）"], 2, "hs_shaman"],


	        //buff
	        hs_VelenSChosen: ["维伦的恩泽", "ordinary", ["buff:24,q1", "使一个随从获得+2/+4和法术伤害+1。"], 3, "hs_priest"],
	        hs_FrostwoodFalls: ["霜林瀑布", "ordinary", ["buff:dongjied,H4,chaofeng", "冻结目标随从，其获得+4生命值和嘲讽。"], 2, "hs_mage"],
	        hs_HuntersMark: ["猎人印记", "essential", ["buff:h1", "使一个随从的生命值变为1。"], 0, "hs_hunter", ["damage"]],
	        hs_PowerWordShield: ["真言术：盾", "essential", ["buff:H2", "使一个随从获得+2生命值。 抽一张牌。"], 1, "hs_priest", ["draw1"]],
	        hs_PowerWordShieldPT: ["真言术：盾", "essential", ["buff:H1", "抽一张牌，叠加（随从）：+1生命值。"], 1, "hs_priest", ["draw1"]],
	        hs_InnerRage: ["怒火中烧", "ordinary", ["buff:A2,d1", "对一个随从造成1点伤害，该随从获得+2攻击力。"], 0, "hs_warrior"],
	        hs_Charge: ["冲锋", "essential", ["buff:A2,chongfeng", "使一个友方随从获得+2攻击力和冲锋。"], 3, "hs_warrior", ["sctp:mine"]],
	        hs_MarkOfWild: ["野性印记", "essential", ["buff:chaofeng,22", "使一个随从获得嘲讽和+2/+2。（+2攻击力/+2生命值）"], 2, "hs_druid"],
	        hs_BlessingOfMight: ["力量祝福", "essential", ["buff:A3", "使一个随从获得+3攻击力。"], 1, "hs_paladin"],
	        hs_Humility: ["谦逊", "essential", ["buff:a1", "使一个随从的攻击力变为1。"], 1, "hs_paladin"],
	        hs_HandOfProtection: ["保护之手", "essential", ["buff:shengdun", "使一个随从获得圣盾。"], 1, "hs_paladin"],
	        hs_BlessingOfKings: ["王者祝福", "essential", ["buff:44", "使一个随从获得+4/+4。（+4攻击力/+4生命值）"], 4, "hs_paladin"],
	        hs_SealOfChampions: ["英勇圣印", "ordinary", ["buff:A3,shengdun", "使一个随从获得+3攻击力和圣盾。"], 3, "hs_paladin"],
	        hs_EarthShock: ["大地震击", "ordinary", ["buff:cm,d1", "沉默一个随从，然后对其造成1点伤害。"], 1, "hs_shaman"],
	        hs_Bananas: ["香蕉", "ordinary", ["buff:11", "使一个随从获得+1/+1。"], 1, "hs_neutral", ["token"]],
	        hs_Windfury: ["风怒", "essential", ["buff:fengnu", "使一个随从获得风怒。"], 2, "hs_shaman"],
	        hs_Rampage: ["狂暴", "ordinary", ["buff:33", "使一个受伤的随从获得+3/+3。"], 2, "hs_warrior", ["only:伤"]],


	        //咆哮
	        hs_EveryfinIsAwesome: ["鱼人恩典", "rare", ["咆哮:2", "使你的所有随从获得+2/+2。你每控制一个鱼人，该牌的法力值消耗便减少（1）点。"], 7, "hs_shaman", ["cgct:return p.countFellow(t=>t.rkind=='murloc');"]],
	        hs_Bloodlust: ["嗜血", "essential", ["咆哮:3", "在本回合中，使你的所有随从获得+3攻击力。"], 5, "hs_shaman", ["temp"]],

	        //变形
	        hs_Polymorph: ["变形术", "essential", ["bxs:绵羊", "使一个随从变形成为1/1的绵羊。"], 4, "hs_mage"],
	        hs_PolymorphBoar: ["变形术：野猪", "rare", ["bxs:hs_Boar1_monster", "使一个随从变形成为一个4/2并具有冲锋的野猪。"], 3, "hs_mage"],
	        hs_Hex: ["妖术", "essential", ["bxs:hs_Frog_monster", "使一个随从变形成为一只0/1并具有嘲讽的青蛙。"], 3, "hs_shaman"],




	        //其他简化
	        //叠甲
	        hs_ShieldBlock: ["盾牌格挡", "essential", "获得5点护甲值。抽一张牌。", 3, "hs_warrior", ["atkhj:[0,5]", "draw1"]],
	        hs_Claw: ["爪击", "essential", "使你的英雄获得2点护甲值，并在本回合中获得+2攻击力。", 1, "hs_druid", ["atkhj:[2,2]"]],
	        hs_Bite: ["撕咬", "rare", "使你的英雄获得4点护甲值，并在本回合中获得+4攻击力。", 4, "hs_druid", ["atkhj:[4,4]"]],
	        hs_HeroicStrike: ["英勇打击", "", "在本回合中，使你的英雄获得+4攻击力。", 2, "hs_warrior", ["atkhj:[4,0]"]],
	        hs_FrostNova: ["冰霜新星", "essential", "冻结所有敌方随从。", 3, "hs_mage", ["bh"]],

	        //其他
	        hs_UnstablePortal: ["不稳定的传送门", "rare", "随机将一张随从牌置入你的手牌。该牌的法力值消耗减少（3）点。", 2, "hs_mage"],
	        hs_CircleOfHealing: ["治疗之环", "ordinary", "为所有随从恢复4点生命值。", 0, "hs_priest"],
	        hs_EchoOfMedivh: ["麦迪文的残影", "epic", "复制你的所有随从，并将其置入你的手牌。", 4, "hs_mage"],
	        hs_SavageRoar: ["野蛮咆哮", "essential", "在本回合中，使你的所有角色获得+2攻击力。", 3, "hs_druid"],
	        hs_InnerFire: ["心灵之火", "ordinary", "使一个随从的攻击力等同于其生命值。", 1, "hs_priest"],
	        hs_DivineSpirit: ["神圣之灵", "ordinary", "使一个随从的生命值翻倍。", 2, "hs_priest"],
	        hs_MassDispel: ["群体驱散", "rare", "沉默所有敌方随从，抽一张牌。", 4, "hs_priest"],
	        hs_Equality: ["生而平等", "rare", "将所有随从的生命值变为1", 2, "hs_paladin"],
	        hs_Flare: ["照明弹", "rare", "所有随从失去潜行，摧毁所有敌方奥秘，抽一张牌。", 2, "hs_hunter"],
	        hs_ExplorersHat: ["探险帽", "rare", "使一个随从获得+1/+1，以及“亡语：将一张“探险帽”置入你的手牌。”", 2, "hs_hunter"],
	        hs_CallPet: ["召唤宠物", "rare", "抽一张牌。如果该牌是野兽牌，则其法力值消耗减少（4）点。", 2, "hs_hunter"],
	        hs_WildGrowth: ["野性成长", "essential", "获得一个空的法力水晶。", 2, "hs_druid"],
	        hs_AstralCommunion: ["星界沟通", "epic", "获得十个法力水晶。弃掉你的手牌。", 4, "hs_druid"],
	        hs_DeadlyPoison: ["致命药膏", "essential", "使你的武器获得+2攻击力。", 1, "hs_rogue"],
	        hs_BladeFlurry: ["剑刃乱舞", "rare", "摧毁你的武器，对所有敌人造成等同于其攻击力的伤害。", 2, "hs_rogue"],
	        hs_BlessingOfWisdom: ["智慧祝福", "ordinary", "选择一个随从，每当其进行攻击，便抽一张牌。", 1, "hs_paladin"],
	        hs_BlessedChampion: ["受祝福的勇士", "rare", "使一个随从的攻击力翻倍。", 5, "hs_paladin"],
	        hs_CommandingShout: ["命令怒吼", "rare", "在本回合中，你的随从的生命值无法被降到1点以下。抽一张牌。", 2, "hs_warrior"],
	        hs_BouncingBlade: ["弹射之刃", "epic", "随机对一个随从造成1点伤害。重复此效果，直到某个随从死亡。", 3, "hs_warrior"],
	        hs_RockbiterWeapon: ["石化武器", "essential", "在本回合中，使一个友方角色获得+3攻击力。", 1, "hs_shaman"],
	        hs_GangUp: ["夜幕奇袭", "ordinary", "选择一个随从。将该随从的三张复制洗入你的牌库。", 2, "hs_rogue"],
	        hs_IceLance: ["冰枪术", "ordinary", "冻结一个角色，如果该角色已被冻结，则改为对其造成4点伤害。", 1, "hs_mage", ["bq:damage"]],
	        hs_Silence: ["沉默", "ordinary", "沉默一个随从。", 0, "hs_priest"],
	        hs_PowerOverwhelming: ["力量的代价", "ordinary", "使一个友方随从获得+4/+4，该随从会在回合结束时死亡。", 1, "hs_warlock"],
	        hs_Implosion: ["小鬼爆破", "rare", "对一个随从造成 2- 4点伤害。每造成1点伤害，便召唤一个1/1的小鬼。", 4, "hs_warlock"],
	        hs_TheCoin: ["幸运币", "essential", "在本回合中，获得一个法力水晶。", 0, "hs_neutral"],
	        hs_Innervate: ["激活", "essential", "在本回合中，获得两个法力水晶。", 4, "hs_warlock"],
	        hs_MindVision: ["心灵视界", "essential", "随机复制对手手牌中的一张牌，将其置入你的手牌。", 1, "hs_priest"],
	        hs_FistOfJaraxxus: ["加拉克苏斯之拳", "rare", "当你使用或弃掉这张牌时，随机对一个敌人造成4点伤害。", 4, "hs_warlock"],
	        hs_Swipe: ["横扫", "essential", ["damage:4", "对一个敌人造成4点伤害，并对所有其他敌人造成1点伤害。"], 4, "hs_druid"],
	        hs_ConeOfCold: ["冰锥术", "ordinary", "冻结一个随从和其相邻的随从，并对它们造成1点伤害。", 4, "hs_mage"],
	        hs_Powershot: ["强风射击", "rare", "对一个随从及其相邻的随从造成2点伤害。", 3, "hs_hunter"],
	        hs_ExplosiveShot: ["爆炸射击", "rare", "对一个随从造成5点伤害，并对其相邻的随从造成2点伤害。", 5, "hs_hunter"],
	        hs_Upgrade: ["升级", "rare", "如果你装备一把武器，使它获得+1/+1。否则，装备一把1/3的武器。", 1, "hs_warrior"],
	        hs_FarSight: ["视界术", "epic", "抽一张牌，该牌的法力值消耗减少（3）点。", 3, "hs_shaman"],
	        hs_HealingWave: ["治疗波", "rare", "恢复7点生命值。揭示双方牌库里的一张随从牌。如果你的牌法力值消耗较大，改为恢复14点生命值。", 3, "hs_shaman"],
	        hs_Resurrect: ["复活术", "rare", "随机召唤一个在本局对战中死亡的友方随从。", 2, "hs_priest"],
	        hs_MindControl: ["精神控制", "essential", "获得一个敌方随从的控制权。", 10, "hs_priest"],
	        hs_BurrowingMine: ["地雷", "essential", "抽到时施放你受到10点伤害。", 6, "hs_warrior", ["token", "hsdraw:player.hs_dmgrcv('damage', 10, 'fire');"]],
	        hs_ShadowMadness: ["暗影狂乱", "rare", "直到回合结束，获得一个攻击力小于或等于3的敌方随从的控制权。", 4, "hs_priest"],
	        hs_Thoughtsteal: ["思维窃取", "ordinary", "复制你对手的牌库中的两张牌，并将其置入你的手牌。", 3, "hs_priest", ["gain:player.getOppo().cardPile.getCards('h').map(i=>i.name).randomGets(2)"]],
	        hs_Burgle: ["剽窃", "rare", "随机将两张（你对手职业的）卡牌置入你的手牌。", 3, "hs_rogue", ["gain:get.hskachi('all',(c,info)=>info.rnature==player.getOppo().group).randomGets(2)"]],


	        //腐化者
	        hs_QuenchingPoison: ["萃毒", "rare", "消灭你的一个随从，召唤一个剧毒蜘蛛。如果目标随从有剧毒，该随从每有一点生命值额外召唤一个剧毒蜘蛛。", 0, "hs_corruptor"],
	        hs_TeaParty: ["茶话会", "epic", "你所有随从本回合+2攻击力并永久+2生命值。", 4, "hs_corruptor"],
	        hs_DeadLandSummon: ["死域召唤", "epic", "召唤若干个随从直到你满场，它们的法力值消耗之和为5。", 4, "hs_corruptor"],
	        hs_CauseAndEffect: ["殊途同归", "legend", "消灭一个你的随从，召唤3个1/1的复制。", 4, "hs_corruptor"],
	        hs_QuenchingPoisonPT: ["萃毒", "ordinary", "消灭一只你的白斑蜘蛛，召唤一只剧毒蜘蛛。", 1, "hs_corruptor"],
	        hs_TreasureHunt: ["寻宝", "epic", "消灭一个你的随从，为你的英雄恢复1点生命值，抽一张牌。", 1, "hs_corruptor"],
	        hs_GuardingHeart: ["守护之心", "ordinary", "目标随从+1生命并获得嘲讽。", 1, "hs_corruptor"],
	        hs_PoisonousFog: ["毒雾", "epic", "你每控制一个剧毒随从，便对随机一名敌方角色造成1点伤害。", 1, "hs_corruptor"],

	    };
	    var keys = { //简化常见分类
	        公共: {
	            con: {
	                //限定条件
	                fg: function(obj) { //对面有随从
	                    obj.sfilter = function(card, player) {
	                        return player.sctp("notmine")
	                            .length
	                    };
	                },
	                //固定效果
	                bh: "player.sctp('notmine',t=>t.addgjzbuff('dongjied'));",
	                draw1: "player.hs_drawDeck();",
	                draw3: "player.hs_drawDeck(3);",
	                frost: "target.addgjzbuff('dongjied');",
	                discard1: "player.hs_discard();",
	                shrink2: "target.addvaluebuff(-2);",
	                gift2: "player.getOppo().hs_gain(get.hskachi('HS_minor').randomGet());",
	                fx: "player.hs_dmgrcvaoe(2,player,card,player.sctp('opposide'));", //奉献
	                //可调节条件
	                bq: function(rg) { //标签
	                    obj["spell" + rg] = true;
	                },
	                only: function(rg) { //目标限定
	                    if (rg == "fellow") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("mns", t);
	                        };
	                    } else if (rg == "fellow,healthy") {
	                        obj.filterTarget = function(c, p, t) {
	                            return t.isHealthy() && p.sctp("mns", t);
	                        };
	                    } else if (rg == "notmine,healthy") {
	                        obj.filterTarget = function(c, p, t) {
	                            return t.isHealthy() && p.sctp("notmine", t);
	                        };
	                    } else if (rg == "enemy") {
	                        delete obj.filterTarget;
	                        obj.randomRT = function(p) {
	                            return p.getOppo();
	                        };
	                    } else if (rg == "me") {
	                        delete obj.filterTarget;
	                        obj.randomRT = function(p) {
	                            return p;
	                        };
	                    } else if (rg == "opposide") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("opposide", t);
	                        };
	                    } else if (rg == "randmgfl") {
	                        delete obj.filterTarget;
	                        obj.randomRT = function(p) {
	                            return p.HSF("randmgfil", ["notmine"]);
	                        };
	                    } else if (rg == "randmgfl2") {
	                        delete obj.filterTarget;
	                        obj.randomRT = function(p) {
	                            var fls = p.sctp("notmine")
	                                .filter(t => t.canhsdmg());
	                            if (fls.length == 0) return false;
	                            return fls.randomGets(2);
	                        };
	                        obj.tgs = true;
	                    } else if (rg == "ranxmfl") {
	                        delete obj.filterTarget;
	                        obj.randomRT = function(p) {
	                            return p.HSF("ranxmfil");
	                        };
	                    } else if (rg == "self") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("mine", t);
	                        };
	                    } else if (rg == "demon") {
	                        obj.filterTarget = function(c, p, t) {
	                            return t.rkind == "demon";
	                        };
	                    } else if (rg == "灭") {
	                        obj.filterTarget = function(c, p, t) {
	                            return t.isMin() && t.ATK >= 5;
	                        };
	                    } else if (rg == "痛") {
	                        obj.filterTarget = function(c, p, t) {
	                            return t.isMin() && t.ATK <= 3;
	                        };
	                    } else if (rg == "enm") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("notmine", t);
	                        };
	                    } else if (rg == "伤") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("mns", t) && t.isDamaged();
	                        };
	                    } else if (rg == "enm,伤") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("notmine", t) && t.isDamaged();
	                        };
	                    } else if (rg == "enm,未伤") {
	                        obj.filterTarget = function(c, p, t) {
	                            return p.sctp("notmine", t) && t.isHealthy();
	                        };
	                    }
	                },
	                activecon: function(ac, obj) { //金框条件
	                    if (ac == "ys") {
	                        obj.active = function(player) {
	                            return player.hasFellow(fl => fl.rkind == "wildbeast");
	                        };
	                    } else if (ac == "dmg") {
	                        obj.active = function(player) {
	                            return player.hp <= 12;
	                        };
	                    } else if (ac == "yh") obj.active = function(player) {
	                        return player.countCards("h") == 1;
	                    };
	                },
	                activeeff: function(ac) { //金框效果
	                    var con = "if(event.active)";
	                    if (keys.公共.con[ac]) arr.push(con + keys.公共.con[ac]);
	                },
	                //可调节效果
	                gain: function(v1, obj) { //置于手牌
	                    return "player.hs_gain(" + v1 + ");";
	                },
	                weapon: function(v1, obj) { //装备武器
	                    return "player.hs_weapon(" + v1 + ");";
	                },
	                gift: function(v1, obj) { //疲劳
	                    return "player.getOppo().hs_drawDeck(" + v1 + ");";
	                },
	                damage: function(v1, obj) { //伤害
	                    return "target.hs_dmgrcv('damage'," + v1 + ");";
	                },
	                recover: function(v1, obj) { //回复
	                    return "target.hs_dmgrcv('recover'," + v1 + ");";
	                },
	                xx: function(v1, obj) { //吸血
	                    return "player.hs_dmgrcv('recover'," + v1 + ");";
	                },
	                summon: function(v1, obj) { //召怪
	                    return "player.SSfellow(" + v1 + ");";
	                },
	                buff: function(v1, obj) { //buff
	                    var ar = hsbuff(v1.split(","));
	                    arr.addArray(ar);
	                },
	                atkhj: function(v1, obj) { //攻击力和护甲
	                    return "player.hs_atkhj(" + v1 + ");";
	                },
	                other: function(v1, obj) { //没活了，自己写
	                    return v1;
	                },
	                //条件调节效果
	                des: function(v1) { //目标死亡
	                    var com = "if(!target.HSF('alive'))";
	                    return com + keys.公共.con[v1];
	                },
	                nodes: function(v1) { //目标存活
	                    var com = "if(target.HSF('alive'))";
	                    return com + keys.公共.con[v1];
	                },
	            },
	        },
	        飞弹: {
	            init: function() { //获取初始化数据
	                var num = parseInt(ms.slice(3));
	                obj.spelldamage = num;
	                obj.content = strfunc("", "player.hs_Missiles(" + num + ", true);");
	                return {
	                    base: num
	                };
	            },
	            dftrans: "造成#点伤害，随机分配到所有敌方角色身上。",
	            norecon: true,
	        },
	        damage: {
	            init: function() { //获取初始化数据
	                var num = ms.slice(7);
	                var num2 = parseInt(num) || 1;
	                obj.spelldamage = num2;
	                obj.filterTarget = true;
	                return {
	                    base: num
	                };
	            },
	            dftcode: function(items, obj) {
	                if (obj.tgs) return "player.hs_dmgrcvaoe('damage',player,card,targets," + items.base + (obj.energy ? ",'" + obj.energy + "'" : "") + ");";
	                else return "target.hs_dmgrcv('damage'," + items.base + (obj.energy ? ",'" + obj.energy + "'" : "") + ");";
	            },
	            dftrans: "造成#点伤害。",
	            solve: function(s, obj, arr, items, k1, v1) {
	                var num = items.base;
	                if (s == "lavaeff") {
	                    arr.new0 = "get.HSF('lavaeffect',['damage'," + num + ",'lava',player]);";
	                    delete obj.filterTarget;
	                } else if (s == "xxx") {
	                    arr.add("player.hs_dmgrcv('recover'," + num + ");");
	                } else if (k1 == "lava") {
	                    arr.new0 = "get.HSF('lavaeffect',['" + v1 + "'," + num + ",'lava',player]);";
	                    delete obj.filterTarget;
	                } else if (k1 == "aoe") {
	                    arr.new0 = "player.hs_dmgrcvaoe(" + num + ",player,card,player.sctp('" + v1 + "')" + (obj.energy ? ",'" + obj.energy + "'" : "") + ");";
	                    delete obj.filterTarget;
	                } else if (s == "blade") {
	                    arr.new0 = "get.HSF('bladeeffect',['damage'," + num + ",player]);";
	                    delete obj.filterTarget;
	                } else if (k1 == "rcvmyside") {
	                    arr.add("player.hs_dmgrcvaoe(" + v1 + ",'recover',player,card,player.sctp('myside'));");
	                } else if (k1 == "activenum") {
	                    items.base = "(event.active?" + v1 + ":" + num + ")";
	                }
	            },
	        },
	        recover: {
	            init: function() {
	                var num = ms.slice(8);
	                var num2 = parseInt(num) || 1;
	                obj.filterTarget = true;
	                obj.spellrecover = num2;
	                return {
	                    base: num
	                };
	            },
	            dftcode: function(items, obj) {
	                return "target.hs_dmgrcv('recover'," + items.base + ");";
	            },
	            dftrans: "恢复#点生命值。",
	        },
	        summon: {
	            init: function() {
	                var tg = ms.slice(7);
	                obj.summoneff = true;
	                return {
	                    base: tg
	                };
	            },
	            dftcode: function(items, obj) {
	                return "player.SSfellow(" + items.base + ");";
	            },
	            dftrans: "",
	        },
	        咆哮: {
	            init: function() {
	                var num = parseInt(ms.slice(3));
	                return {
	                    rg: "mine",
	                    base: num
	                };
	            },
	            dftcode: function(items, obj) {
	                if (items.temp) return "player.sctp('" + items.rg + "',t=>t.addvaluebuff(" + items.base + ",1));";
	                return "player.sctp('" + items.rg + "',t=>t.addvaluebuff([" + items.base + "," + items.base + "]));";
	            },
	            dftrans: "使你的所有随从获得+#/+#。",
	            solve: function(s, obj, arr, items, k1, v1) {
	                if (s == "temp") items.temp = true;
	            },
	        },
	        bxs: {
	            init: function() {
	                var tg = ms.slice(4);
	                obj.filterTarget = function(c, p, t) {
	                    return t.isMin();
	                };
	                obj.spelldestroy = true;
	                return {
	                    base: tg
	                };
	            },
	            dftcode: function(items, obj) {
	                return "target.HSF('convert',['" + items.base + "']);";
	            },
	            dftrans: "",
	        },
	        draw: {
	            init: function() {
	                var num = ms.slice(5);
	                var n = parseInt(num);
	                obj.spelldraw = n || true;
	                if (num.indexOf("p=>") >= 0) num = "(" + num + ")(player)";
	                return {
	                    base: n || num,
	                };
	            },
	            dftcode: function(items, obj) {
	                return "player.hs_drawDeck(" + items.base + ");";
	            },
	            dftrans: "抽$张牌。",
	        },
	        kill: {
	            init: function(arr) {
	                var num = ms.slice(5);
	                if (num != "1") {
	                    var sj = num == "all" ? "mns" : num;
	                    arr.new0 = "get.HSF('lavaeffect', ['cuihui',player.sctp('" + sj + "'), 'lava']);";
	                } else obj.filterTarget = function(c, p, t) {
	                    return t.isMin();
	                };
	                obj.spelldestroy = true;
	                return {
	                    base: num
	                };
	            },
	            dftcode: function(items, obj) {
	                return "target.HSF('cuihui');";
	            },
	            dftrans: "消灭一个随从。",
	        },
	        buff: {
	            init: function(arr) {
	                var ar = hsbuff(ms.slice(5)
	                    .split(","));
	                if (ar.hsai == "damage") obj.spelldamage = true;
	                else obj.spellbuff = true;
	                obj.filterTarget = strfunc("c,p,t", "return p.sctp('mns',t)");
	                return {
	                    ar: ar,
	                    rg: "mns",
	                    random: false
	                };
	            },
	            dftrans: "",
	            solve: function(s, obj, arr, items, k1, v1) {
	                if (s == "random") items.random = true;
	                else if (s == "neg") {
	                    obj.spelldamage = true;
	                    delete obj.spellbuff;
	                } else if (k1 == "sctp") items.rg = v1;
	                if (items.random) {
	                    delete obj.filterTarget;
	                    obj.randomRT = strfunc("p", "return p.sctp('" + items.rg + "').randomGet()");
	                } else obj.filterTarget = strfunc("c,p,t", "return p.sctp('" + items.rg + "',t)");
	            },
	        },
	    };
	    for (var i in minispell) {
	        lib.translate[i] = minispell[i][0];
	        var ms = minispell[i][2];
	        var tms = ms;
	        if (!lib.translate[i + "_info"]) {
	            if (ms.length == 2) {
	                tms = ms[1];
	                lib.translate[i + "_info"] = tms;
	                ms = ms[0];
	            }
	        }
	        var coff = ms.indexOf(":") > 0; //常见简化效果
	        if (!lib.translate[i + "_info"] && !coff) lib.translate[i + "_info"] = ms;
	        var obj = {
	            rarity: minispell[i][1],
	            cost: minispell[i][3],
	            rnature: minispell[i][4],
	        };
	        var gz = new RegExp("过载：（[1-9]）");
	        if (gz.test(tms)) {
	            var num = parseInt(tms.match(new RegExp("(?<=(过载：（)).")));
	            obj.hs_gz = num;
	        }
	        if (ms.indexOf("@") == 0) {
	            //还没想好
	        } else {
	            var xsf = minispell[i][5] || []; //修饰符
	            var tool = null,
	                items = null,
	                arr = [];
	            if (coff) {
	                xsf.push("coff");
	                if (["ice", "fire", "thunder"].contains(xsf[0])) obj.energy = xsf[0];
	                var key = ms.slice(0, ms.indexOf(":"));
	                tool = keys[key];
	                if (tool) {
	                    items = tool.init(arr) || {};
	                    if (items.ar) arr = items.ar;
	                }
	            }
	            xsf.forEach(s => {
	                //公共部分
	                var aa = s.split(":");
	                var k1 = aa[0],
	                    v1 = aa[1];
	                if (s.indexOf("cgct:") == 0) {
	                    eval("obj.changecost=function(p){" + s.slice(5) + "}");
	                } else if (s.indexOf("hsdraw:") == 0) {
	                    eval("obj.onhsdraw=function(p){" + s.slice(7) + "}");
	                } else if (s == "token") {
	                    obj.hs_token = true;
	                } else if (keys.公共.con[s]) {
	                    if (typeof keys.公共.con[s] == "function") keys.公共.con[s](obj);
	                    else arr.push(keys.公共.con[s]);
	                } else if (v1 && keys.公共.con[k1]) { //如果是带冒号的标签
	                    var str = keys.公共.con[k1](v1, obj);
	                    if (typeof str == "string") arr.push(str);
	                }
	                //特色
	                else if (s != "coff" && xsf.contains("coff")) {
	                    if (tool && tool.solve) {
	                        var str = tool.solve(s, obj, arr, items, k1, v1);
	                        if (typeof str == "string") arr.push(str);
	                    }
	                }
	            });
	            if (tool) {
	                if (tool.dftcode) {
	                    if (arr.new0) arr.unshift(arr.new0);
	                    else {
	                        arr.unshift(tool.dftcode(items, obj));
	                    }
	                }
	                if (!lib.translate[i + "_info"]) lib.translate[i + "_info"] = tool.dftrans.replace("#", items.base)
	                    .replace("$", get.cnNumber(items.base));
	            }
	            if (arr.length && !(tool && tool.norecon)) obj.content = hsrfunc(arr);
	        }
	        minispell[i] = obj;
	    }

	    var full = {
	        //法术卡  定位
	        hs_IceLance: {
	            filterTarget: true,
	            content: function() {
	                if (!target.hasgjz("dongjied")) target.addgjzbuff("dongjied");
	                else target.hs_dmgrcv("damage", 4, "ice");
	            },
	        },
	        hs_Silence: {
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.hs_silence();
	            },
	            ai: {
	                result: {
	                    target: function(player, target) {
	                        if (target.triggers.deathRattle || target.classList.contains("guanghuan") || target.buff.length > 3) return -1;
	                        else return 0;
	                    },
	                },
	            },
	        },
	        hs_PowerOverwhelming: {
	            filterTarget: function(card, player, target) {
	                return target.isMin() && target.getLeader() == player;
	            },
	            content: function() {
	                target.addvaluebuff([4, 4]);
	                target.addtriggerbuff(card);
	            },
	            spellbuff: true,
	            delayeffect: {
	                ending: {
	                    self: true,
	                    effect: function() {
	                        event.fellow.HSF("cuihui");
	                    },
	                },
	            },
	        },
	        hs_Implosion: {
	            cost: 4,
	            rnature: "hs_warlock",
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                "step 0"
	                event.a = target.hs_dmgrcv("damage", [2, 3, 4].randomGet());
	                "step 1"
	                if (event.a && event.a.num > 0) player.SSfellow(["小鬼", event.a.num]);
	            },
	            spelldamage: true,
	        },
	        hs_TheCoin: {
	            hs_token: true,
	            cost: 0,
	            rnature: "hs_neutral",
	            content: function() {
	                player.HSF("gaintempmana");
	            },
	            ai: {
	                result: {
	                    player: function(player) {
	                        if (player.HSF("manamax") < 3) return 0;
	                        var cs = player.getCards("h", ca => ((player.HSF("mana") + 1) == ca.cost()));
	                        return cs.length;
	                    },
	                },
	            },
	        },
	        hs_UnstablePortal: {
	            content: function() {
	                "step 0"
	                player.hs_gain(get.hskachi("HS_minor")
	                    .randomGet());
	                "step 1"
	                result.cards[0].addhsbuff({
	                    name: "hs_cost",
	                    type: "hs_cost",
	                    value: 3,
	                    creator: cards[0],
	                    fellow: player,
	                });
	            },
	        },
	        hs_Innervate: {
	            cost: 0,
	            rnature: "hs_druid",
	            content: function() {
	                player.HSF("gaintempmana", [2]);
	            },
	            ai: {
	                result: {
	                    player: function(player) {
	                        if (player.HSF("manamax") < 3) return 0;
	                        var cs = player.getCards("h", ca => ((player.HSF("mana") + 2) == ca.cost()));
	                        return cs.length;
	                    },
	                },
	            },
	        },
	        hs_CircleOfHealing: {
	            content: function() {
	                player.hs_dmgrcvaoe(4, player, card, "recover", player.sctp("mns"));
	            },
	        },
	        hs_EchoOfMedivh: {
	            buffeff: true,
	            content: function() {
	                var arr = player.getFellow()
	                    .sort(lib.sort.attendseq)
	                    .map(i => i.linkCard[0].name);
	                player.hs_gain(arr);
	            },
	        },
	        hs_SavageRoar: {
	            content: function() {
	                player.getFellowN(fl => {
	                    fl.addvaluebuff(2, 1);
	                });
	            },
	        },
	        hs_InnerFire: {
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.addvaluefinal(target.hp);
	            },
	        },
	        hs_DivineSpirit: {
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.addvaluebuff([0, target.hp]);
	            },
	            spellbuff: true,
	        },
	        hs_MassDispel: {
	            content: function() {
	                "step 0"
	                player.sctp("notmine", t => t.hs_silence());
	                "step 1"
	                player.hs_drawDeck();
	            },
	        },
	        hs_Equality: {
	            content: function() {
	                player.sctp("mns")
	                    .forEach(i => {
	                    i.addvaluefinal([0, 1]);
	                });
	            },
	        },
	        hs_Flare: {
	            content: function() {
	                player.sctp("mns", t => t.removegjz("qianxing"));
	                player.hs_drawDeck();
	            },
	        },
	        hs_ExplorersHat: {
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.addvaluebuff([1, 1]);
	                target.addtriggerbuff(card);
	            },
	            delayeffect: {
	                deathRattle: function() {
	                    player.hs_gain("探险帽");
	                },
	            },
	        },
	        hs_CallPet: {
	            content: function() {
	                player.hs_drawDeck()
	                    .onbuff = function(cs) {
	                    if (get.rkind(cs[0]) == "wildbeast") cs[0].addhsbuff({
	                        name: "hs_cost",
	                        type: "hs_cost",
	                        value: 4,
	                        creator: cards[0],
	                        fellow: player,
	                    });
	                };
	            },
	        },
	        hs_WildGrowth: {
	            content: function() {
	                player.HSF("gainmana", [1, true]);
	            },
	        },
	        hs_AstralCommunion: {
	            content: function() {
	                "step 0"
	                player.HSF("gainmana", [10]);
	                "step 1"
	                player.hs_discard("all");
	            },
	        },
	        hs_DeadlyPoison: {
	            sfilter: function(card, player) {
	                return player.data_weapon;
	            },
	            content: function() {
	                player.addwpbuff(2);
	            },
	        },
	        hs_BladeFlurry: {
	            sfilter: function(card, player) {
	                return player.data_weapon;
	            },
	            content: function() {
	                "step 0"
	                event.atk = player.data_weapon.ATK;
	                player.data_weapon.HSF("cuihui");
	                "step 1"
	                get.HSF("bladeeffect", ['opposide', event.atk, player]);
	            },
	        },
	        hs_BlessingOfWisdom: {
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.addtriggerbuff(card);
	            },
	            delayeffect: {
	                attackBegin: {
	                    fl: true,
	                    effect: function() {
	                        event.obj.relabuff.player.hs_drawDeck();
	                    },
	                },
	            },
	        },
	        hs_BlessedChampion: {
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.addvaluebuff(target.ATK);
	            },
	            spellbuff: true,
	        },
	        hs_CommandingShout: {
	            content: function() {
	                "step 0"
	                player.hs_drawDeck();
	                "step 1"
	                player.addaurasbuff("hs_mlnh", null, 1);
	            },
	        },
	        hs_BouncingBlade: {
	            sfilter: function(card, player) {
	                return player.sctp("mns", t => t.canhsdmg("hp"));
	            },
	            content: function() {
	                "step 0"
	                event.i = 0;
	                event.qd = player;
	                "step 1"
	                var t = player.HSF("randmgfil", ["mns", null, "hp"]);
	                t.hs_dmgrcv('damage', 1, player, card);
	                event.qd.HSline(t, "green");
	                event.qd = t;
	                "step 2"
	                event.i++;
	                if (player.HSF("randmgfil", ["mns", null, "hp"]) && event.i < 80) event.goto(1);
	            },
	        },
	        hs_RockbiterWeapon: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("myside", target);
	            },
	            content: function() {
	                target.addvaluebuff(3, 1);
	            },
	        },
	        hs_GangUp: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("mns", target);
	            },
	            content: function() {
	                player.HSF("addtodeck", [
	                    [target.linkCard[0].name, 3]
	                ]);
	            },
	        },
	        hs_MindVision: {
	            sfilter: function(card, player) {
	                return player.getOppo()
	                    .countCards("h");
	            },
	            content: function() {
	                player.hs_gain(player.getOppo()
	                    .getCards("h")
	                    .map(i => i.name)
	                    .randomGet());
	            },
	        },
	        hs_FistOfJaraxxus: {
	            randomRT: function(player) {
	                return player.HSF("randmgfil");
	            },
	            content: function() {
	                target.hs_dmgrcv("damage", 4);
	            },
	            sameeffect: "discarded",
	        },
	        hs_Swipe: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("opposide", target);
	            },
	            content: function() {
	                player.hs_dmgrcvaoe(1, card, player, "damage", [target].concat(target.sctp("myside_")
	                    .sort(lib.sort.attendseq)), [target, 4])
	                    .nosort = true;
	            },
	            spelldamage: 4,
	        },
	        hs_ConeOfCold: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("mns", target);
	            },
	            content: function() {
	                "step 0"
	                event.tgs = [target.leftseat, target.rightseat, target].filter(i => i);
	                player.hs_dmgrcvaoe(1, "ice", card, player, "damage", event.tgs)
	                    .nosort = true;
	                "step 1"
	                event.tgs.filter(i => i.HSF("alive", [true]))
	                    .forEach(i => i.addgjzbuff("dongjied"));
	            },
	            spelldamage: 1,
	        },
	        hs_Powershot: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("mns", target);
	            },
	            content: function() {
	                event.tgs = [target, target.leftseat, target.rightseat].filter(i => i);
	                player.hs_dmgrcvaoe(2, card, player, "damage", event.tgs)
	                    .nosort = true;
	            },
	            spelldamage: 2,
	        },
	        hs_ExplosiveShot: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("mns", target);
	            },
	            content: function() {
	                event.tgs = [target, target.leftseat, target.rightseat].filter(i => i);
	                player.hs_dmgrcvaoe(2, "fire", card, player, "damage", event.tgs, [target, 5])
	                    .nosort = true;
	            },
	            spelldamage: 5,
	        },
	        hs_Upgrade: {
	            content: function() {
	                if (player.data_weapon) player.data_weapon.addvaluebuff([1, 1]);
	                else player.hs_weapon("重斧");
	            },
	        },
	        hs_FarSight: {
	            content: function() {
	                player.hs_drawDeck()
	                    .onbuff = function(cs) {
	                    cs[0].addhsbuff({
	                        name: "hs_cost",
	                        type: "hs_cost",
	                        value: 3,
	                        creator: cards[0],
	                        fellow: player,
	                    });
	                };
	            },
	        },
	        hs_HealingWave: {
	            filterTarget: true,
	            content: function() {
	                "step 0"
	                player.hs_compare();
	                "step 1"
	                var num = result.bool ? 14 : 7;
	                target.hs_dmgrcv("recover", num);
	            },
	            spellrecover: 7,
	        },
	        hs_Resurrect: {
	            content: function() {
	                player.hs_revive();
	            },
	        },
	        hs_MindControl: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("notmine", target);
	            },
	            content: function() {
	                target.toNTRed(player);
	            },
	        },
	        hs_ShadowMadness: {
	            filterTarget: function(card, player, target) {
	                return player.sctp("notmine", target) && target.ATK <= 3;
	            },
	            content: function() {
	                target.toNTRed(player, true);
	            },
	        },


	        //法术新卡定位




	        //腐化者
	        hs_TreasureHunt: {
	            cost: 1,
	            rnature: "hs_corruptor",
	            filterTarget: function(card, player, target) {
	                return target.isMin() && target.getLeader() == player;
	            },
	            content: function() {
	                "step 0"
	                target.HSF("cuihui");
	                "step 1"
	                player.hs_dmgrcv("recover");
	                "step 2"
	                player.hs_drawDeck();
	            },
	            ai: {
	                order: 9.9,
	                result: {
	                    target: function(player, target) {
	                        if (target.name == "hs_WhiteSpottedSpider") return 6;
	                        var val = (target.triggers.deathRattle ? 3 : 0) - target.ATK + 1;
	                        if (player.hp >= 4) return val;
	                        else return val + 1.5;
	                    },
	                },
	            },
	        },
	        hs_GuardingHeart: {
	            cost: 1,
	            rnature: "hs_corruptor",
	            filterTarget: function(card, player, target) {
	                return target.isMin();
	            },
	            content: function() {
	                target.addvaluebuff([0, 1]);
	                target.addgjzbuff("chaofeng");
	            },
	            ai: {
	                order: 8.9,
	                result: {
	                    target: function(player, target) {
	                        var val = target.HSF("hasCFeff") ? 0 : 1;
	                        var val2 = !val && target.hp == 0 ? 2 : target.ATK;
	                        var val3 = target.triggers.deathRattle ? 3 : 0;
	                        return 1 + val + val2 + val3;
	                    },
	                },
	            },
	        },
	        hs_PoisonousFog: {
	            cost: 1,
	            rnature: "hs_corruptor",
	            sfilter: function(card, player) {
	                return player.countFellow(fl => fl.hasgjz("jvdu")) + player.countFq() > 0;
	            },
	            content: function() {
	                var num = player.countFellow(fl => fl.hasgjz("jvdu")) + player.countFq();
	                player.hs_Missiles(num);
	            },
	            ai: {
	                order: 9,
	                result: {
	                    player: function(player) {
	                        return player.countFellow(fl => fl.hasgjz("jvdu")) - 1.9;
	                    },
	                },
	            },
	            spelldamage: true,
	        },
	        hs_QuenchingPoison: {
	            filterTarget: function(card, player, target) {
	                return target.isMin() && target.getLeader() == player;
	            },
	            content: function() {
	                "step 0"
	                target.HSF("cuihui", [true]);
	                event.num = 1 + (target.hasgjz("jvdu") ? target.hp : 0);
	                "step 1"
	                player.SSfellow(["剧毒蜘蛛", event.num]);
	            },
	            ai: {
	                order: 9.1,
	                result: {
	                    player: 1,
	                },
	            },
	        },
	        hs_TeaParty: {
	            buffeff: true,
	            content: function() {
	                player.countFellow(fl => {
	                    fl.addvaluebuff(2, 1);
	                    fl.addvaluebuff([0, 2]);
	                })
	            },
	        },
	        hs_DeadLandSummon: {
	            summoneff: true,
	            content: function() {
	                "step 0"
	                event.num = 5;
	                "step 1"
	                if (player.countFellow() == 6) {
	                    var c = get.hskachi("HS_minor", (ca, info) => info.cost == event.num)
	                        .randomGet();
	                } else {
	                    var c = get.hskachi("HS_minor", (ca, info) => info.cost <= event.num)
	                        .randomGet();
	                }
	                player.SSfellow(c);
	                event.num -= lib.card[c].cost;
	                "step 2"
	                if (player.countFellow() < 7 && event.num > 0) event.goto(1);
	            },
	        },
	        hs_CauseAndEffect: {
	            hs_legend: true,
	            filterTarget: function(card, player, target) {
	                return target.isMin() && target.getLeader() == player;
	            },
	            content: function() {
	                "step 0"
	                target.HSF("cuihui", [true]);
	                event.n = target.linkCard[0].name;
	                "step 1"
	                player.SSfellow([event.n, 3], undefined, undefined, ["复制"]);
	            },
	            ai: {
	                order: 9.1,
	                result: {
	                    player: 1,
	                },
	            },
	        },



	        //diy


	        //炉石普通
	        //腐化者
	        hs_QuenchingPoisonPT: {
	            filterTarget: function(c, p, t) {
	                return t.name == "hs_WhiteSpottedSpider" && t.getLeader() == p;
	            },
	            content: function() {
	                "step 0"
	                target.HSF("cuihui", [true]);
	                "step 1"
	                player.SSfellow("剧毒蜘蛛");
	            },
	            ai: {
	                order: 9.1,
	                result: {
	                    player: 1,
	                },
	            },
	        },
	    };

	    for (var i in full) {
	        if (minispell[i]) {
	            full[i] = Object.assign({}, minispell[i], full[i]);
	        }
	    }

	    var weaponfull = { //完整武器代码
	        hs_KingsDefender: {
	            weaponeffect: {
	                battleRoal: {
	                    filter: function(p) {
	                        return p.hasFellow(fl => fl.hasgjz("chaofeng"));
	                    },
	                    effect: function() {
	                        event.fellow.addvaluebuff([0, 1]);
	                    },
	                },
	            },
	        },
	        hs_CogmastersWrench: {
	            weaponeffect: {
	                numgh: {
	                    name: "value",
	                    value: [2, 0],
	                    wpal: true,
	                    ghfilter: function(card, fellow, target) {
	                        return fellow.sctp("mine", fl => fl.rkind == "machine");
	                    },
	                },
	            },
	        },
	        hs_TruesilverChampion: {
	            weaponeffect: {
	                attackBegin: {
	                    filter: function(evt, p) {
	                        return evt.player == p;
	                    },
	                    effect: function() {
	                        player.hs_dmgrcv("recover", 2);
	                    },
	                },
	            },
	        },
	        hs_SwordOfJustice: {
	            weaponeffect: {
	                summonAfter: {
	                    self: true,
	                    randomRT: function(p, evt) {
	                        return evt.link;
	                    },
	                    effect: function() {
	                        "step 0"
	                        target.addvaluebuff([1, 1]);
	                        "step 1"
	                        event.fellow.hs_dmgrcv(1);
	                    },
	                },
	            },
	        },
	        hs_PoisonedBlade: {
	            weaponeffect: {
	                equipBefore: {
	                    charlotte: true,
	                    filter: function(evt, p) {
	                        return evt.player == p && evt.heroskill;
	                    },
	                    effect: function() {
	                        event.orievt.cancel();
	                    },
	                },
	                heroskillAfter: function() {
	                    event.fellow.updateSelfBuff(1);
	                },
	            },
	        },
	        hs_ArgentLance: {
	            weaponeffect: {
	                battleRoal: function() {
	                    player.hs_compare(function(p, evt) {
	                        event.fellow.addvaluebuff([0, 1]);
	                    });
	                },
	            },
	        },


	        //冒险模式
	        hs_Hook: {
	            weaponeffect: {
	                deathRattle: {
	                    effect: function() {
	                        player.hs_gain("铁钩");
	                    },
	                },
	            },
	        },
	    };

	    var miniweapon = { //武器牌
	        hs_WickedKnife: ["邪恶短刀", "essential", "", 1, "hs_rogue", 1, 2, ["token"]],
	        hs_BattleAxe: ["战斧", "essential", "", 1, "hs_warrior", 2, 2, ["token"]],
	        hs_LightsJustice: ["圣光的正义", "essential", "", 1, "hs_paladin", 1, 4],
	        hs_PoisonedDagger: ["浸毒匕首", "essential", "", 1, "hs_rogue", 2, 2, ["token"]],
	        hs_Ashbringer: ["灰烬使者", "essential", "", 5, "hs_paladin", 5, 3, ["token", "legend"]],
	        hs_Doomhammer: ["毁灭之锤", "epic", "风怒，过载：（2）", 5, "hs_shaman", 2, 8],
	        hs_StormforgedAxe: ["雷铸战斧", "ordinary", "过载：（1）", 2, "hs_shaman", 2, 3],
	        hs_FieryWarAxe: ["炽炎战斧", "essential", "", 2, "hs_warrior", 3, 2],
	        hs_DeathsBite: ["死亡之咬", "ordinary", "亡语：对所有随从造成1点伤害。", 4, "hs_warrior", 4, 2],
	        hs_KingSlayer: ["弑君者", "legend", "亡语：将一张死域召唤置入你的手牌。", 4, "hs_corruptor", 4, 2, ["legend"]],
	        hs_ChargedHammer: ["灌魔之锤", "epic", "亡语：你的英雄技能改为“造成 2点伤害”。", 4, "hs_shaman", 2, 4, ["deathRattle:cghrsk>雷霆震击"]],
	        hs_Powermace: ["动力战锤", "rare", "亡语：随机使一个友方机械获得+2/+2。", 3, "hs_shaman", 3, 2, ["deathRattle:fltbuff>mine,machine：22"]],
	        hs_AssassinsBlade: ["刺客之刃", "essential", "", 5, "hs_rogue", 3, 4],
	        hs_ArcaniteReaper: ["奥金斧", "essential", "", 5, "hs_warrior", 5, 2],
	        hs_EaglehornBow: ["鹰角弓", "rare", "每当一个友方奥秘被揭示时，便获得+1耐久度。", 3, "hs_hunter", 3, 2],
	        hs_Glaivezooka: ["重型刃弩", "ordinary", "战吼：随机使一个友方随从获得+1攻击力。", 2, "hs_hunter", 2, 2, ["battleRoal:ranbuff>mine：A1"]],
	        hs_Coghammer: ["齿轮光锤", "epic", "战吼：随机使一个友方随从获得圣盾和嘲讽。", 3, "hs_paladin", 2, 3, ["battleRoal:ranbuff>mine：shengdun,chaofeng"]],
	        hs_KingsDefender: ["国王护卫者", "rare", "战吼：如果你控制任何具有嘲讽的随从，便获得+1耐久度。", 3, "hs_warrior", 3, 2, ["rareEff"]],
	        hs_CogmastersWrench: ["齿轮大师的扳手", "epic", "如果你控制任何机械，便获得+2攻击力。", 3, "hs_rogue", 1, 3],
	        hs_TruesilverChampion: ["真银圣剑", "essential", "每当你的英雄进攻，便为其恢复2点生命值。", 4, "hs_paladin", 4, 2],
	        hs_SwordOfJustice: ["公正之剑", "epic", "在你召唤一个随从后，使其获得+1/+1，这把武器失去1点耐久度。", 3, "hs_paladin", 1, 5],
	        hs_PoisonedBlade: ["淬毒利刃", "epic", "你的英雄技能不会取代该武器，改为+1攻击力。", 4, "hs_rogue", 1, 3],
	        hs_OgreWarmaul: ["食人魔战槌", "ordinary", "50%几率攻击错误的敌人。", 3, "hs_warrior", 4, 2],
	        hs_HeavyAxe: ["重斧", "essential", "", 1, "hs_warrior", 1, 3, ["token"]],
	        hs_ArgentLance: ["白银之枪", "rare", "战吼：揭示双方牌库里的一张随从牌。如果你的牌法力值消耗较大，+1耐久度。", 2, "hs_paladin", 2, 2],


	        //冒险模式
	        hs_Hook: ["铁钩", "essential", "风怒，亡语：将这把武器移回你的手牌。", 3, "hs_leader", 4, 8, ["hs_token"]],
	    }

	    for (var i in miniweapon) {
	        var wp = miniweapon[i];
	        lib.translate[i] = wp[0];
	        lib.translate[i + "_info"] = wp[2];
	        var obj = {
	            rarity: wp[1],
	            enable: true,
	            notarget: true,
	            fullimage: true,
	            type: "HS_weapon",
	            ai: {
	                order: 9,
	                result: {
	                    player: 1,
	                },
	            },
	        };
	        obj.weaponeffect = weaponfull[i] ? weaponfull[i].weaponeffect : {};
	        obj.cost = wp[3];
	        obj.rnature = wp[4];
	        obj.ATK = wp[5];
	        obj.HP = wp[6];
	        if (wp[2].length > 0) {
	            var arr = wp[2].split(new RegExp("，|。")); //描述根据逗号分割
	            var gjz = true;
	            for (var p of arr) {
	                var yc = cons.yincang[p];
	                var gz = new RegExp("^过载：（[1-9]）");
	                if (gjz && p.length == 2) { //关键字效果
	                    var fy = cons.yineng[p];
	                    if (fy && !obj.weaponeffect[fy]) obj.weaponeffect[fy] = true;
	                } else if (yc) { //隐藏关键字
	                    gjz = false;
	                    yc = cons.yineng[yc];
	                    obj.weaponeffect[yc] = true;
	                } else if (gz.test(p)) {
	                    var num = parseInt(p.match(new RegExp("(?<=(过载：（)).")));
	                    obj.hs_gz = num;
	                } else if (p.indexOf("：") == 2) {
	                    var pr = p.split("：");
	                    var sj = pr[0],
	                        xg = pr[1];
	                    var sjs = {战吼: "battleRoal",
	                        亡语: "deathRattle",
	                    };
	                    if (sjs[sj] && !obj.weaponeffect[sjs[sj]]) {
	                        var tri = {};
	                        var regs = {
	                            blade: "对所有随从造成[1-9]点伤害",
	                            gain: "将一张.{1,9}置入你的手牌",
	                        };
	                        var reg = function(b) {
	                            return new RegExp(b);
	                        };
	                        var mth = function(a, b) {
	                            return a.match(reg(b));
	                        }
	                        if (mth(xg, regs.blade)) {
	                            var num = parseInt(mth(xg, "(?<=造成).(?=点)"));
	                            tri.effect = strfunc("", "get.HSF('bladeeffect', ['damage', " + num + ", player]);");
	                        } else if (mth(xg, regs.gain)) {
	                            var str = mth(xg, "(?<=一张).+(?=置入)");
	                            tri.effect = strfunc("", "player.hs_gain('" + str + "');");
	                        }
	                        obj.weaponeffect[sjs[sj]] = tri;
	                    }
	                }
	            }
	        }
	        if (wp[7]) wp[7].forEach(s => {
	            if (s == "token") obj.hs_token = true;
	            else if (s == "legend") obj.hs_legend = true;
	            else if (s == "rareEff") {
	                obj.weaponeffect.active = function(p, c) {
	                    var that = this;
	                    if (that.battleRoal) {
	                        if (that.battleRoal.BRfilter && !that.battleRoal.BRfilter(null, p)) return false;
	                        if (that.battleRoal.filter) {
	                            var nf = get.HSF("strfil", [that.battleRoal.filter]);
	                            that.battleRoal.filter = nf;
	                            if (!nf(p, c)) return false;
	                        }
	                        if (that.battleRoal.filterTarget && !p.sctp("all", t => that.battleRoal.filterTarget(null, p, t))) return false;
	                        if (that.battleRoal.randomRT && !that.battleRoal.randomRT(p)) return false;
	                        return true;
	                    } else return false;
	                };
	            } else if (s.indexOf(":") > 0) {
	                var sr = s.split(":");
	                var sj = sr[0],
	                    xg = sr[1];
	                var tri = {};
	                if (xg.contains("fltbuff>")) {
	                    var arr = xg.slice(8)
	                        .split("：");
	                    var rg = arr[0].split(",");
	                    arr = arr[1].split(",");
	                    arr = hsbuff(arr);
	                    if (sj == "battleRoal") tri.filterTarget = strfunc("c,p,t", "return p.sctp('" + rg[0] + "',t)&&t.rkind=='" + rg[1] + "';");
	                    else tri.randomRT = strfunc("p", "return p.sctp('" + rg[0] + "').filter(t=>t.rkind=='" + rg[1] + "').randomGet()");
	                    tri.aifamily = arr.hsai;
	                    tri.effect = hsrfunc(arr);
	                } else if (xg.contains("ranbuff>")) {
	                    var arr = xg.slice(8)
	                        .split("：");
	                    var rg = arr[0];
	                    arr = arr[1].split(",");
	                    arr = hsbuff(arr);
	                    tri.randomRT = strfunc("p", "return p.sctp('" + rg + "').randomGet()");
	                    tri.effect = hsrfunc(arr);
	                } else if (xg.contains("cghrsk>")) {
	                    var c = xg.slice(7);
	                    tri.effect = strfunc("", "player.HSF('changeHeroskill',['" + c + "']);");
	                }

	                obj.weaponeffect[sj] = tri;
	            }
	        });

	        miniweapon[i] = obj;
	    }

	    for (var i in weaponfull) {
	        if (miniweapon[i]) {
	            weaponfull[i] = Object.assign({}, weaponfull[i], miniweapon[i]);
	        }
	    }

	    hearthstone.rdrd_card = {
	        spell: Object.assign({}, minispell, full),
	        trap: {},
	        weapon: Object.assign({}, miniweapon, weaponfull),
	    };


	    for (var i in hearthstone.loadTrans) {
	        if ((new RegExp("^hs"))
	            .test(i)) {
	            if (i.indexOf("_info") < 0) {
	                if (!hearthstone.rdrd_card.spell[i] && !hearthstone.rdrd_card.trap[i]) {
	                    hearthstone.rdrd_card.spell[i] = {
	                        able: function() {
	                            return false
	                        },
	                    };
	                }
	            } else hearthstone.loadTrans[i] = hearthstone.loadTrans[i];
	        }
	    }
	    var objt = Object.assign({}, hearthstone.rdrd_card.spell, hearthstone.rdrd_card.trap, hearthstone.rdrd_card.weapon);
	    for (var i in objt) {
	        if (!objt[i].fullimage) objt[i].fullimage = true;
	        if (hearthstone.rdrd_card.spell[i]) {
	            var ob = hearthstone.rdrd_card.spell[i];
	            if (!ob.cost) ob.cost = 0;
	            if (!ob.type) ob.type = "HS_spell";
	            if (!ob.subtype) ob.subtype = "HS_normalS";
	        } else if (hearthstone.rdrd_card.trap[i]) {
	            var ob = hearthstone.rdrd_card.trap[i];
	            if (!ob.cost) ob.cost = 0;
	            if (!ob.subtype) ob.subtype = "HS_secret";
	        }
	    }
	    game.import("card", function(lib, game, ui, get, ai, _status) {
	        return {
	            name: "hearthstone",
	            translate: {},
	            list: [],
	            card: objt,
	        }
	    });
	    var heroskill = { //基础英雄技能
	        //炉石普通
	        diej: ["全副武装", "获得auto点护甲", "hs_warrior", "auto", "player.changeHujia(auto);"],
	        huoc: ["火焰冲击", "造成1点伤害", "hs_mage", "auto", "target.hs_dmgrcv('damage',player,'fire').hs_heroskill=true;", ["F:all", "return get.dmgEffect(target, player, player,1) + 0.1;"], {
	            order: 6,
	            result: {
	                player: function(player) {
	                    if (game.hasPlayer(function(target) {
	                        return get.dmgEffect(target, player, player, 1) + 0.1 > 0;
	                    })) return 1;
	                    else return 0;
	                },
	            },
	        }],
	        shej: ["稳固射击", "对敌方英雄造成2点伤害", "hs_hunter", 2, "target.hs_dmgrcv('damage',2, player).hs_heroskill=true;", "R:function(player){return player.getOppo();}"],
	        zhil: ["次级治疗术", "恢复auto点生命值", "hs_priest", "auto", "target.hs_dmgrcv('recover',auto,player).hs_heroskill=true;", ["F:all", "return get.rcvEffect(target, player, player,1) + 0.1;"], {
	            order: 1,
	            result: {
	                player: function(player) {
	                    var val = Math.max.apply(Math, player.sctp()
	                        .map(i => get.rcvEffect(i, player, player) + 1));
	                    return val;
	                },
	            },
	        }],
	        fenl: ["生命分流", "抽一张牌并受到2点伤害", "hs_warlock", 2, ["player.hs_dmgrcv('damage',2, player).hs_heroskill=true;", "player.hs_drawDeck();"], "", {
	            order: 6,
	            result: {
	                player: function(player) {
	                    if (player.hp > 2 && player.cardPile.countCards("h")) return 1;
	                    else return 0;
	                },
	            },
	        }],
	        biax: ["变形", "本回合+1攻击力。+1护甲值。", "hs_druid", 2, "player.hs_atkhj([1,1],1);"],
	        yuaj: ["援军", "召唤一个1/1的白银之手新兵。", "hs_paladin", 2, "player.SSfellow('白银之手新兵');"],
	        ttzh: ["图腾召唤", "随机召唤一个图腾。", "hs_shaman", 2, "player.SSfellow('cdset:图腾');"],
	        shad: ["匕首精通", "", "hs_rogue", 2, "player.hs_weapon('邪恶短刀').hs_heroskill=true;", "", {
	            order: 6,
	            result: {
	                player: function(player) {
	                    if (player.data_weapon) return 0;
	                    else return 1;
	                },
	            },
	        }],
	        qins: ["侵蚀", "召唤一只白斑蜘蛛", "hs_corruptor", 1, "player.SSfellow('白斑蜘蛛');"],
	    };
	    var mb = { //英雄技能模板
	        enable: "phaseUse",
	        direct: true,
	        nobracket: true,
	        content: function() {
	            player.hs_use_heroskill();
	        },
	        ai: {
	            order: 1,
	            result: {
	                player: 1,
	            },
	        },
	    };
	    var evhrsk = function(name, obj, p) { //生成英雄技能
	        if (!obj) {
	            get.hs_alt(name + "没有详细内容！");
	            return;
	        }
	        lib.skill[name] = get.copy(mb);
	        delete lib.skill[name].eff;
	        var num = name.indexOf("legend") > 0 ? "2" : "1";
	        lib.translate[name] = obj[0];
	        lib.translate[name + "_info"] = obj[1].replace("auto", num);
	        if (obj[1].indexOf("召唤") >= 0) lib.skill[name].summoneff = true;
	        lib.skill[name].rnature = obj[2];
	        if (get.HSA("diy")
	            .contains(obj[2])) lib.skill[name].diy = true;
	        lib.skill[name].cost = obj[3];
	        var effect = obj[4];
	        if (typeof effect == "string") effect = [effect];
	        effect = effect.map(i => i.replace("auto", num));
	        lib.skill[name].effect = get.hsrfunc(effect);
	        if (obj[5]) {
	            var f = function(str, pp) {
	                if (str == "all") lib.skill[name].filterT = lib.filter.all;
	                else if (str.indexOf("function") == 0) eval("lib.skill[name].filterT=str");
	                else lib.skill[name].filterT = get.strfunc("card,player,target", "return player.sctp('" + str + "',target);");
	            };
	            var g = function(a) {
	                var mm = a.split(":")[1];
	                if (a.indexOf("F:") == 0) f(mm, (p || game.me));
	                else if (a.indexOf("R:") == 0) {
	                    if (mm.indexOf("function") == 0) eval("lib.skill[name].randomHT=" + mm + ";");
	                    else lib.skill[name].randomHT = get.strfunc("player", "return player.sctp('" + mm + "').randomGet();");
	                }
	            };
	            if (typeof obj[5] == "string") g(obj[5]);
	            else {
	                g(obj[5][0]);
	                var mk = obj[5][1];
	                if (mk.indexOf("function") == 0) eval("lib.skill[name].hrskai=str");
	                else lib.skill[name].hrskai = get.strfunc("target", "var player=get.player();" + mk);
	            }
	        }
	        if (obj[6]) lib.skill[name].ai = obj[6];
	        lib.skill[name].filter = function(event, player) {
	            if (event.isMine() && !player.presshrskbt) {
	                //console.log("情况1");
	                return false;
	            }
	            var skill = player.heroskill;
	            if (skill.classList.contains("used") || skill.used >= skill.usable) {
	                //console.log("使用过");
	                return false;
	            }
	            if (player.HSF("mana") < player.HSF("hs_num", [skill.skill])) {
	                //console.log("法力不足");
	                return false;
	            }
	            if (lib.skill[skill.skill].summoneff && player.hs_full()) {
	                //console.log("没空召怪");
	                return false;
	            }
	            if (skill.filterTarget && !game.hasPlayer(target => {
	                return player.HSF("canbetarget", [null, target, "heroskill"]) && skill.filterTarget(null, player, target);
	            })) {
	                //console.log("无目标");
	                return false;
	            } else if (skill.randomHT && !skill.randomHT(player)) return false;
	            else return true;
	        };
	    };
	    hearthstone.heroskill = heroskill;
	    hearthstone.eval_heroskill = evhrsk;
	});