game.import("extension", function(lib, game, ui, get, ai, _status) {
    _status.hsextra = ["经典卡背", "萨尔", "炎魔之王", "万圣节", "炫丽彩虹", "守望先锋", "虚空之遗", "源生法杖", "电竞之星", "冠军试炼", "麦迪文", "麦格尼", "奥蕾莉亚", "风暴英雄", "奈法利安", "黄金挑战", "潘达利亚", "新年吉祥", "舞狮", "染柒推荐", "甜蜜胜利", "神秘图纸", "冬幕花冠", "我是传说", "熔火之心", "雷霆崖", "炉边好友", "爱如空气", "NAXX", "暴雪2014", "暴雪2015"].reduce((x, y) => {
        x[y] = y;
        return x;
    }, {});

    return {
        name: "炉石普通",
        editable: false,
        onremove: function() {
            delete lib.storage.scene["炉石普通"];
        },
        content: function() {
            //以下是调试模块，技能出错会弹窗报错代码
            if (!(lib.config.extensions.contains("特效测试") && lib.config.extension_特效测试_enable)) {
                var inte = setInterval(function() { //更改十周年的tryContent方法
                    if (window.decadeUI && decadeUI.game && typeof decadeUI.game.tryContent == "function") {
                        var CAFst = decadeUI.game.tryContent.toString();
                        if (CAFst.indexOf("我修改的") < 0) {
                            var ins = function(str) {
                                return str.replaceAll2("event.content(", "var t=event.content;txcsanm.canbug=t.toString();event['content'](");
                            };
                            eval("decadeUI.game.tryContent=function(event, step, source, player, target, targets, card, cards, skill, forced, num, trigger, result, _status, lib, game, ui, get, ai){/*我修改的*/" + CAFst.newFedit(ins) + "}");
                        } else clearInterval(inte);
                    } else {
                        var CAFst = game.loop.toString();
                        if (CAFst.indexOf("我修改的") < 0) {
                            var ins = function(str) {
                                return str.replaceAll2("event.content(", "var t=event.content;txcsanm.canbug=t.toString();event['content'](");
                            };
                            eval("game.loop=function(){/*我修改的*/" + CAFst.newFedit(ins) + "}");
                        } else clearInterval(inte);
                    }
                }, 400);
                var _alert = window.alert;
                window.alert = function(str) { //更改弹窗函数，匿名函数报错时弹窗该匿名函数
                    var fi, res;
                    if (window.txcsanm) fi = txcsanm.canbug;
                    if (typeof str == "string" && fi && typeof fi == "string") {
                        res = str.slice(0);
                        res = res.split('<anonymous>:')[1];
                        if (res && res.length) {
                            var j = res.indexOf(')');
                            if (j >= 0) {
                                res = res.split(')')[0];
                                res = res.split(':')
                                    .map(function(l) {
                                    return parseInt(l)
                                }); //此时res为数组，分别代表出错行数和列数
                                fi = fi.replace("anonymous", "错误content");
                                var arr = fi.split('\n');
                                fi = "";
                                var h = res[0] - 1;
                                if (arr.length >= res[0] && arr[h].length >= res[1]) {
                                    arr[h] = " [烫烫烫]# " + arr[h].slice(0, res[1] - 1) + " [锟斤拷]# " + arr[h].slice(res[1] - 1);
                                    fi = arr[h];
                                    txcsanm.cwcontent = arr.join("\n");
                                }
                                fi = str.slice(0, 1200) + (str.length > 1200 ? " [后略...]" : "") + "\n====分割线====\n" + fi;
                                console.log(fi);
                                _alert(fi);
                                return;
                            }
                        }
                    }
                    if (typeof str == "string") {
                        if (str.indexOf('nvalid line') >= 0) {
                            _alert('骨骼素材无法读取，请更换骨骼素材\n' + str);
                            return;
                        } else if (str.indexOf('Animation not found') >= 0) {
                            _alert('该骨骼素材没有此骨骼标签，请确认骨骼标签是否填对\n' + str);
                            return;
                        } else if (str.indexOf('egion not found') >= 0) {
                            _alert('该骨骼素材的atlas缺区域，请补全\n' + str);
                            return;
                        }
                    }
                    _alert(str);
                };
            }
            if (lib.config.mode == "brawl") {
                if (!lib.storage.scene) lib.storage.scene = {};
                if (true) {
                    var mod = lib.config.extension_炉石普通_HS_duelMode;
                    var base = {
                        intro: {
                            normal: "欢迎来到我的酒馆，快找个位置随便坐",
                            legend: "今晚累得够呛，但只要有客人来玩，我都欢迎。",
                            single: "小伙子们，看看谁来了。",
                            brawl: "屋里可比外面亮堂多了",
                        }[mod],
                    };
                    lib.storage.scene["炉石普通"] = {
                        name: "炉石普通",
                        intro: base.intro,
                        players: [{
                            "name": "hs_player",
                            "name2": "none",
                            "identity": "zhu",
                            "position": 1,
                            "hp": 10,
                            "maxHp": 10,
                            "linked": false,
                            "turnedover": false,
                            "playercontrol": false,
                            "handcards": [],
                            "equips": [],
                            "judges": []
                        }, {
                            "name": "hs_comp",
                            "name2": "none",
                            "identity": "fan",
                            "position": 2,
                            "hp": 10,
                            "maxHp": 10,
                            "linked": false,
                            "turnedover": false,
                            "playercontrol": false,
                            "handcards": [],
                            "equips": [],
                            "judges": []
                        }],
                        cardPileTop: [],
                        cardPileBottom: [],
                        discardPile: [],
                    };
                    _status.extensionscene = true;
                }
                if (!_status.extensionmade) _status.extensionmade = [];
                _status.extensionmade.push("炉石普通");
                //以上是创建乱斗关卡
            }
            //乱斗的代码结束
        },
        precontent: function(qs) {
            if (!window.txcsanm) window.txcsanm = {};
            //下面定义了原型的新方法
            if (!String.prototype.repeat) String.prototype.repeat = function(string, count) {
                return new Array(count + 1)
                    .join(string);
            };
            String.prototype.replaceAll2 = function(from, to) { //批量文本替换
                var str = this;
                var bo = function(b, s) { //b原串 s筛选条件
                    if (typeof s == "string") return b.indexOf(s) > -1;
                    else return s.test(b); //支持正则表达式了
                };
                while (bo(str, from)) {
                    str = str.replace(from, to);
                }
                return str;
            };
            String.prototype.newFedit = function(ins) { //函数手术刀
                var CAFst = this;
                var CAFstr = CAFst.slice(CAFst.indexOf("{") + 1)
                    .slice(0, -1);
                return ins(CAFstr);
            };
            String.prototype.contains = Array.prototype.contains;
            String.prototype.every = Array.prototype.every;
            String.prototype.forEach = Array.prototype.forEach;
            String.prototype.some = Array.prototype.some;
            String.prototype.like = function(str) {
                var mtc;
                if (typeof str == "string" && !".({[-]})".some(i => str.contains(i))) mtc = str;
                else {
                    var reg = new RegExp(str);
                    var ob = this.match(reg);
                    mtc = ob ? ob[0] : false;
                }
                return this.contains(mtc) && this.length - mtc.length < 2;
            };
            String.prototype.newFedit = function(ins) { //函数手术刀
                var CAFst = this;
                var CAFstr = CAFst.slice(CAFst.indexOf("{") + 1)
                    .slice(0, -1);
                return ins(CAFstr);
            };
            Array.prototype.findLast = function(cb) {
                var that = this;
                if (!that.length) return undefined;
                if (cb) return that.slice(0)
                    .reverse()
                    .filter(cb)[0];
                else return undefined;
            };
            Array.prototype.eachsome = function(func) {
                var arr = this.map(i => func(i));
                return arr.contains(true);
            };
            Array.prototype.bottom = function(item) {
                this.remove(item);
                this.push(item);
                return this;
            };
            window.hearthstone = { //将所有新东西，定义在一个JSON对象中
                monster: { //召唤怪兽的模板
                    enable: true,
                    notarget: true,
                    lose: false,
                },
                card: { //卡牌相关函数
                },
                player: { //随从相关函数
                    filterFellow: function(func, bool) { //筛选符合条件的怪兽
                        var list = [];
                        if (!func) func = () => true;
                        var fs = this.getFellow(bool);
                        for (var i = 0; i < fs.length; i++) {
                            if (func(fs[i])) list.push(fs[i]);
                        }
                        return list;
                    },
                    filterFellowX: function(func) { //兼容旧版filter
                        var list = [];
                        var that = this;
                        if (!func) func = () => true;
                        var fs = that.getFellow();
                        for (var i = 0; i < fs.length; i++) {
                            if (func(null, that, fs[i])) list.push(fs[i]);
                        }
                        return list;
                    },
                    hasFellow: function(fellow, bool) { //是否有符合条件的怪兽
                        if (!this.actcharacterlist) return false;
                        if (get.itemtype(fellow) == 'player') return this.countFellow(function(fl) {
                            return fl == fellow;
                        }, bool) > 0;
                        if (!fellow) fellow = () => true;
                        return this.countFellow(fellow, bool) > 0;
                    },
                    countFellow: function(func, bool) { //数符合条件的怪兽
                        if (!func) func = () => true;
                        var fs = this.getFellow(bool);
                        var count = 0;
                        for (var i = 0; i < fs.length; i++) {
                            if (func(fs[i])) count++;
                        }
                        return count;
                    },
                    getFellow: function() { //获取怪兽(没有筛选条件)
                        var fs = [];
                        if (!this.actcharacterlist) return fs;
                        for (var i = 0; i < this.actcharacterlist.length; i++) {
                            if (this.actcharacterlist[i]) {
                                var fl = this.actcharacterlist[i];
                                fs.push(fl);
                            }
                        }
                        return fs;
                    },
                    getFellowN: function(func) { //获取怪兽(包括自己)
                        if (!func) func = () => true;
                        var p = this.getLeader()
                        return p.getFellow()
                            .add(p)
                            .filter(func);
                    },
                    getLeader: function() { //怪兽的控制者
                        return this.side == game.me.side ? game.me : game.enemy;
                    },
                    getOppo: function() { //获取敌人
                        return this == game.me ? game.enemy : game.me;
                    },
                    HS_die: function() { //死亡
                    },
                },
                content: { //以下是自定义的事件内容
                },
                get: {
                    rGJZ: function(obj, key) { //获取随从牌关键字
                        if (!obj) return null;
                        var str;
                        if (get.itemtype(obj) == "card") str = obj.name;
                        else str = obj;
                        if (get.subtype(str) != "HS_effect") return null;
                        var sk = lib.skill[str.slice(0, -8)];
                        if (sk) return sk[key];
                        return null;
                    },
                    rHP: function(obj) { //获取随从牌生命值
                        if (!obj) return null;
                        var str;
                        if (get.itemtype(obj) == "card") str = obj.name;
                        else str = obj;
                        var info = get.info({
                            name: str
                        });
                        if (!info) return null;
                        return info.HP;
                    },
                    rATK: function(obj) { //获取随从牌攻击力
                        if (!obj) return null;
                        var str;
                        if (get.itemtype(obj) == "card") str = obj.name;
                        else str = obj;
                        var info = get.info({
                            name: str
                        });
                        if (!info) return null;
                        return info.ATK;
                    },
                    rkind: function(obj) { //获取随从牌种族
                        var str;
                        if (get.itemtype(obj) == "card") str = obj.name;
                        else str = obj;
                        var info = get.info({
                            name: str
                        });
                        return info.rkind;
                    },
                    rnature: function(obj) { //获取牌的职业
                        var str;
                        if (get.itemtype(obj) == "card") str = obj.name;
                        else str = obj;
                        var info = get.info({
                            name: str
                        });
                        return info.rnature;
                    },
                    hs_nm: function() { //获取随从上限
                        return lib.hearthstone.game_num;
                    },
                    strfunc: (args, str) => {
                        if (window.txcsanm) window.txcsanm.strbug = str;
                        return eval("var ff=function(" + args + "){" + str + "};ff;");
                    },
                    hsrfunc: function(str) { //生成步骤content
                        var that = window.hearthstone ? hearthstone.get : get;
                        var strfunc = that.strfunc;
                        var arr = Array.from(arguments);
                        var res = "";
                        if (arguments.length == 1) {
                            if (typeof str == "string") return strfunc("", str);
                            else return that.hsrfunc.apply(get, str);
                        } else {
                            arr.forEach((i, j) => {
                                res += "'step " + j + "'\n";
                                res += i + "\n";
                            });
                        }
                        return strfunc("", res);
                    },
                    arraycount: function() { //数组各成员数组的长度之和
                        var count = 0;
                        for (var i = 0; i < arguments.length; i++) {
                            if (Array.isArray(arguments[i])) count += arguments[i].length;
                        }
                        return count;
                    },
                    chscard: function(name, cn, multi) { //制作一张卡(和createCard类似)
                        var cname;
                        var isCN = function(temp) {
                            var re = /[\u4e00-\u9fa5]/;
                            return re.test(temp);
                        }
                        if (cn || isCN(name)) cname = get.HSE(name, multi);
                        if (multi) {
                            if (!cname.length) {
                                get.hs_alt(name + "→在卡池里不存在");
                                return [];
                            }
                        } else {
                            if (cname) name = cname;
                            if (!get.info({
                                name: name
                            })) {
                                get.hs_alt(name + "→在卡池里不存在");
                                return null;
                            }
                            var canname;
                            if (get.type({
                                name: name
                            }) == "HS_minor") canname = name.replace("_monster", "PT_monster");
                            else canname = name + "PT";
                            if (get.hs_nm() == 3 && lib.card[canname]) name = canname;
                        }
                        var card = get.chscard2(name);
                        return card;
                    },
                    HS_trans: function(str) { //翻译
                        var obj = Object.assign({},
                        get.HSA("easy"),
                        get.HSA("cdan"),
                        get.HSA("rkind"),
                        get.HSA("rarity"));
                        if (obj[str]) return obj[str];
                        if (lib.translate[str]) return lib.translate[str];
                        return "";
                    },
                    HSF: (n, a) => lib.hearthstone.funcs[n] ? lib.hearthstone.funcs[n].apply(get, a) : get.hs_alt(n + "不是一个funcs方法"), //调用自定义函数(自定义函数在funcs里面找)
                    HSA: n => get.copy(lib.hearthstone.const[n]), //访问自定义常量(在const里面找)
                    HSAT: n => { //反向
                        var obj = get.HSA(n);
                        if (!obj) {
                            get.hs_alt("HSAT:" + n + "不是一个常量列表");
                            return;
                        }
                        var res = {};
                        for (var i in obj) {
                            res[obj[i]] = i;
                        }
                        return res;
                    },
                    HSE: n => get.HSF("getEN", [n]),
                },
                funcs: {
                    //导入压缩
                    createrd: function() { //两个作用，1.当有参数时，将卡名(未处理的)变成处理过的，并返回 2.没有参数时，将所有怪兽添加描述、卡图
                        if (arguments && arguments.length == 1) {
                            var str = "";
                            var arr = arguments[0].split(" ");
                            for (var i = 0; i < arr.length; i++) {
                                str += arr[i][0].toUpperCase() + arr[i].slice(1);
                            }
                            return "hs_" + str + "_monster";
                        } else if (lib.hearthstone.cardPack.monsterRD) {
                            for (var i in lib.hearthstone.cardPack.monsterRD) {
                                if (!i) continue;
                                var list = lib.hearthstone.cardPack.monsterRD[i];
                                if (list && list.length >= 3 && !lib.translate[i + "_info"]) {
                                    var str = get.HSF("fff", [i]);
                                    var ori;
                                    if (i.indexOf("hs_") != 0) {
                                        ori = i;
                                        i = get.HSF("createrd", [i]);
                                    }
                                    lib.translate[i] = list[0];
                                    lib.translate[i + "_info"] = str;
                                    var ks = ["subtype", "cost", "rnature", "rkind", "ATK", "HP", "overload"];
                                    lib.card[i] = {};
                                    lib.card[i].fullimage = true;
                                    lib.card[i].rarity = list[1];
                                    if (list[1] == "legend") lib.card[i].hs_legend = true;
                                    if (ori) lib.card[i].oriname = ori;
                                    lib.card[i].type = "HS_minor";
                                    for (var j = 0; j < list[3].length; j++) {
                                        if (["cost", "ATK", "HP", "overload"].contains(ks[j])) lib.card[i][ks[j]] = parseInt(list[3][j]);
                                        else lib.card[i][ks[j]] = list[3][j];
                                    }
                                    var gz = new RegExp("过载：（[1-9]）");
                                    if (gz.test(str)) {
                                        var num = parseInt(str.match(new RegExp("(?<=(过载：（)).")));
                                        lib.card[i].hs_gz = num;
                                    }
                                    var tz = list[4];
                                    if (tz) {
                                        for (var m of tz) { //标签效果
                                            if (["legend", "remove", "token", "diy", "tokened", "quetu"].contains(m)) lib.card[i]["hs_" + m] = true;
                                            if (m == "nosearch") lib.card[i].nosearch = true;
                                            else if (m.indexOf("changecost:") == 0) {
                                                var str = m.slice(11);
                                                lib.card[i].changecost = get.strfunc("p", str);
                                            } else if (m.indexOf("addhand:") == 0) {
                                                var str = m.slice(8);
                                                lib.card[i].addhand = get.strfunc("", str);
                                            }
                                        }
                                    }
                                    lib.card[i].image = "ext:炉石普通/card/" + i + ".jpg";
                                }
                            }
                        }
                    },
                    iscpt: n => { //导入js
                        var url = lib.assetURL + "extension/炉石普通";
                        lib.init.js(url, n);
                    },
                    qwe: () => { //创建属性势力
                        var ns = get.HSA("ns");
                        for (var i = 0; i < ns.length; i++) {
                            lib.group.push(ns[i]);
                            lib.translate[ns[i]] = '<img src=' + lib.assetURL + "extension/炉石普通/image/nature/" + ns[i] + ".png" + ' width="40px" height="40px">';
                        }
                        lib.translate.hs_leader = "首领";
                    },
                    Aud: function(card, type, p) { //播放随从音效
                        if (lib.config.extension_炉石普通_HS_audioeffect) {
                            var n = get.translation(card.name);
                            var ts = false;
                            if (type == "play") {
                                var info = get.info(card);
                                if (info.hs_legend && !(info.hs_token || info.hs_tokened || info.hs_diy)) game.playAudio("..", "extension", "炉石普通", "audio", "full", n, "bgm.ogg");
                                if (p) {
                                    var tsc = get.HSA("specialAudio");
                                    var oppo = get.translation(p.getOppo()
                                        .name);
                                    if (tsc[n] && tsc[n].contains(oppo)) ts = true;
                                }
                            }
                            if (ts) game.playAudio("..", "extension", "炉石普通", "audio", "full", n, oppo + ".ogg");
                            else game.playAudio("..", "extension", "炉石普通", "audio", "full", n, type + ".ogg");
                        }
                    },
                    Aud2: function(n) { //播放特殊音效
                        if (lib.config.extension_炉石普通_HS_audioeffect) {
                            game.playAudio("..", "extension", "炉石普通", "audio", "effect", n + ".ogg");
                        }
                    },
                    Aud3: function(p, n) { //播放英雄音效
                        var cm = 2;
                        if (lib.config.extension_炉石普通_HS_audioeffect) {
                            var name2 = get.translation(p.name);
                            var name = p.name.replace("hero_", "")
                                .replace("_PT", "");
                            game.playAudio("..", "extension", "炉石普通", "audio", name, n + ".ogg");
                            var aa = get.HSA("audioDura");
                            if (aa[name2] && aa[name2][n]) cm = aa[name2][n];
                        }
                        return cm;
                    },
                    setAi: function(str) { //给怪兽卡加ai
                        lib.card[str].ai = {
                            useful: [5.5, 1],
                            result: {
                                player: function(player, target, card) {
                                    if (get.type(card.name) == "HS_minor") return 1;
                                },
                            },
                        };
                        lib.card[str].ai.order = get.subtype(str) == "HS_normal" ? 6 : 8.8;
                    },
                    setResult: function(str, t) { //给法术牌加ai
                        var tos = lib.card[str];
                        tos.type = "HS_spell";
                        tos.subtype = t ? "HS_secret" : "HS_normalS";
                        if (!tos.enable) {
                            tos.enable = true;
                            if (!tos.filterTarget) tos.notarget = true;
                            else {
                                if (typeof tos.filterTarget != "boolean") {
                                    tos.enable = get.strfunc("card,player", "return game.hasPlayer(function(target){return (" + tos.filterTarget.toString() + ")(card,player,target)})");
                                }
                            }
                        }
                        tos.image = "ext:炉石普通/card/" + str + ".jpg";
                        if (!tos.ai) tos.ai = {};
                        if (!tos.ai.order) {
                            if (tos.onhsdraw) tos.ai.order = 0;
                            else tos.ai.order = 8;
                        }
                        if (!tos.ai.result) {
                            if (tos.notarget) tos.ai.result = {
                                player: 1
                            };
                            else {
                                tos.ai.result = {};
                                if (tos.spelldamage) {
                                    if (typeof tos.spelldamage == "number") {
                                        var num = tos.spelldamage;
                                        tos.ai.result.target = get.strfunc("player,target", "return get.dmgEffect(target,player,target," + num + ");");
                                    } else tos.ai.result.target = function(player, target) {
                                        return get.damageEffect(target, player, target) + 0.1;
                                    };
                                } else if (tos.spellrecover) {
                                    if (typeof tos.spellrecover == "number") {
                                        var num = tos.spellrecover;
                                        tos.ai.result.target = get.strfunc("player,target", "return get.rcvEffect(target,player,target," + num + ");");
                                    } else tos.ai.result.target = function(player, target) {
                                        return get.rcvEffect(target, player, target) + 0.1;
                                    };
                                } else if (tos.spellbuff) tos.ai.result = {
                                    target: function(player, target) {
                                        return 1;
                                    },
                                };
                                else if (tos.spelldestroy) tos.ai.result = {
                                    target: function(player, target) {
                                        return -1;
                                    },
                                };
                            }
                        }
                    },
                },
            };
            //JSON到这里彻底结束
            var f = window.hearthstone.get.strfunc;
            window.hearthstone.ys = function(arr) {
                return f.apply(null, arr);
            };
            window.hearthstone.use = function(func) {
                func(lib, game, ui, get, ai, _status)
            };
            window.hearthstone.funcs.iscpt(["constant", "event", "card", "animation"]); //导入js
            if (qs.enable) {
                game.import('character', function() {
                    var hearthstone = {
                        name: 'hearthstone',
                        connect: true,
                        characterSort: {},
                        characterTitle: {},
                        character: {
                            hs_player: ['male', 'shu', 4, ["hs_start"],
                                ['des:神秘的家伙，能将异世界的东西召唤出来，进行不一样的对局。']
                            ],
                            hs_comp: ['male', 'shu', 4, ["hs_start"],
                                ['des:神秘的家伙，能将异世界的东西召唤出来，进行不一样的对局。']
                            ],
                            //这是乱斗的初始人物，工具人
                            hero_garrosh_PT: ["male", "hs_warrior", 10, [],
                                ["des:加尔鲁什·地狱咆哮是前任部落大酋长，他由萨尔指定在大灾变之后作为继任者，直到决战奥格瑞玛结束后为沃金所继任。作为部落的新任大酋长，加尔鲁什是一位高傲且凶狠的战士，用铁腕手段统治着部落。他对联盟的憎恨如同野火一般熊熊燃烧，为了摧毁联盟他可以不惜一切代价。在他的巨斧感召下，兽人们将夺回属于自己的荣耀。", "unseen"]
                            ],
                            hero_jaina_PT: ["female", "hs_mage", 10, [],
                                ["des:吉安娜是人类现存最强大的女巫，也曾是达拉然最受信任的女法师，受训成为时任肯瑞托领袖的大法师安东尼达斯的私人特使。第三次战争前夕，安东尼达斯将吉安娜派遣至洛丹伦王国北部。在挚友兼伴侣阿尔萨斯·米奈希尔王子的陪同下，两人前往调查蔓延的瘟疫是否源自魔法。之后吉安娜目睹了洛丹伦陷落，在神秘先知麦迪文的指引下带领所有幸存者跨洋逃向卡利姆多。", "unseen"]
                            ],
                            hero_rexxar_PT: ["male", "hs_hunter", 10, [],
                                ["des:雷克萨 ，部落的勇士，一位具有半兽人半食人魔血统的兽王，是莫克纳萨氏族现存不多的族人之一。他在燃烧军团覆灭之后大力协助部落，并曾从部落的故敌手中拯救过奥格瑞玛的城池。由于混血血统，他是一位特别高大威猛的战士，他的两柄战斧在他精湛的战挤驾驭下威名赫赫。通常，他总是会和他忠诚的战熊伙伴米莎一起共进同出。", "unseen"]
                            ],
                            hero_anduin_PT: ["male", "hs_priest", 10, [],
                                ["des:安度因·莱恩·乌瑞恩是暴风城国王。他的名字取自暴风城历史上两位最负盛名的人物：传奇般的安度因·洛萨与他的祖父莱恩·乌瑞恩。在其父亲瓦里安·乌瑞恩于破碎海滩战死之后，加冕成为暴风城国王。与其父亲果断的战士形象不同，安度因更善于思考与外交，同时也是圣光教会的信徒。", "unseen"]
                            ],
                            hero_guldan_PT: ["male", "hs_warlock", 10, [],
                                ["des:古尔丹曾是一位德拉诺大陆的兽人萨满，他是兽族的第一位术士，也是兽族部落实际上的建立者。古尔丹背弃了萨满之路与他的人民和导师，为了个人利益和力量而投向了恶魔领主基尔加丹，因而对兽族沦为恶魔的奴隶与部落入侵艾泽拉斯负全责。在燃烧军团领袖的教导之下，古尔丹建立了暗影议会并成为其实际操纵者。此外，他还创造了令人闻声色变的亡灵战士——死亡骑士。 古尔丹被认为是有史以来最强大的术士之一。", "unseen"]
                            ],
                            hero_malfurion_PT: ["male", "hs_druid", 10, [],
                                ["des:玛法里奥·怒风是艾泽拉斯最伟大的德鲁伊，并且是半神塞纳留斯的一名学生。通过与大自然以及在翡翠梦境中与塞纳留斯的交流，玛法里奥现在保护着大自然免受恶魔的摧残。", "unseen"]
                            ],
                            hero_uther_PT: ["male", "hs_paladin", 10, [],
                                ["des:“光明使者”乌瑟尔是白银之手骑士团的首位圣骑士，并率领教团在第二次战争中迎击部落。在第三次战争中，乌瑟尔在守护泰瑞纳斯国王的骨灰瓮时被自己的得意门生阿尔萨斯王子背叛并杀害。", "unseen"]
                            ],
                            hero_addiction_PT: ["male", "hs_corruptor", 10, [],
                                ["des:一个炉石痴迷玩家，但不精通，玩过多种桌游，是无名杀的忠实粉丝，也是炉石普通的粉丝。", "unseen"]
                            ],
                            //炉石传说
                            hero_garrosh: ["male", "hs_warrior", 30, [],
                                ["des:加尔鲁什·地狱咆哮是前任部落大酋长，他由萨尔指定在大灾变之后作为继任者，直到决战奥格瑞玛结束后为沃金所继任。作为部落的新任大酋长，加尔鲁什是一位高傲且凶狠的战士，用铁腕手段统治着部落。他对联盟的憎恨如同野火一般熊熊燃烧，为了摧毁联盟他可以不惜一切代价。在他的巨斧感召下，兽人们将夺回属于自己的荣耀。", "unseen"]
                            ],
                            hero_jaina: ["female", "hs_mage", 30, [],
                                ["des:吉安娜是人类现存最强大的女巫，也曾是达拉然最受信任的女法师，受训成为时任肯瑞托领袖的大法师安东尼达斯的私人特使。第三次战争前夕，安东尼达斯将吉安娜派遣至洛丹伦王国北部。在挚友兼伴侣阿尔萨斯·米奈希尔王子的陪同下，两人前往调查蔓延的瘟疫是否源自魔法。之后吉安娜目睹了洛丹伦陷落，在神秘先知麦迪文的指引下带领所有幸存者跨洋逃向卡利姆多。", "unseen"]
                            ],
                            hero_rexxar: ["male", "hs_hunter", 30, [],
                                ["des:雷克萨 ，部落的勇士，一位具有半兽人半食人魔血统的兽王，是莫克纳萨氏族现存不多的族人之一。他在燃烧军团覆灭之后大力协助部落，并曾从部落的故敌手中拯救过奥格瑞玛的城池。由于混血血统，他是一位特别高大威猛的战士，他的两柄战斧在他精湛的战挤驾驭下威名赫赫。通常，他总是会和他忠诚的战熊伙伴米莎一起共进同出。", "unseen"]
                            ],
                            hero_anduin: ["male", "hs_priest", 30, [],
                                ["des:安度因·莱恩·乌瑞恩是暴风城国王。他的名字取自暴风城历史上两位最负盛名的人物：传奇般的安度因·洛萨与他的祖父莱恩·乌瑞恩。在其父亲瓦里安·乌瑞恩于破碎海滩战死之后，加冕成为暴风城国王。与其父亲果断的战士形象不同，安度因更善于思考与外交，同时也是圣光教会的信徒。", "unseen"]
                            ],
                            hero_guldan: ["male", "hs_warlock", 30, [],
                                ["des:古尔丹曾是一位德拉诺大陆的兽人萨满，他是兽族的第一位术士，也是兽族部落实际上的建立者。古尔丹背弃了萨满之路与他的人民和导师，为了个人利益和力量而投向了恶魔领主基尔加丹，因而对兽族沦为恶魔的奴隶与部落入侵艾泽拉斯负全责。在燃烧军团领袖的教导之下，古尔丹建立了暗影议会并成为其实际操纵者。此外，他还创造了令人闻声色变的亡灵战士——死亡骑士。 古尔丹被认为是有史以来最强大的术士之一。", "unseen"]
                            ],
                            hero_malfurion: ["male", "hs_druid", 30, [],
                                ["des:玛法里奥·怒风是艾泽拉斯最伟大的德鲁伊，并且是半神塞纳留斯的一名学生。通过与大自然以及在翡翠梦境中与塞纳留斯的交流，玛法里奥现在保护着大自然免受恶魔的摧残。", "unseen"]
                            ],
                            hero_uther: ["male", "hs_paladin", 30, [],
                                ["des:“光明使者”乌瑟尔是白银之手骑士团的首位圣骑士，并率领教团在第二次战争中迎击部落。在第三次战争中，乌瑟尔在守护泰瑞纳斯国王的骨灰瓮时被自己的得意门生阿尔萨斯王子背叛并杀害。", "unseen"]
                            ],
                            hero_thrall: ["male", "hs_shaman", 30, [],
                                ["des:萨尔，将曾经的野蛮掠夺者转化为能工巧匠，并坚守着族人的未来。“萨尔”是兽人古伊尔年轻时候的绰号，那时他住在自己的第一个家，为了让第二次战争的兽人囚犯再也无法威胁艾泽拉斯而建的监狱；而萨尔，正是奴隶之意。古伊尔逃出监狱后并没有漫无目的地游荡，而是踏上寻根之旅，最后从先祖的萨满信仰中寻得了智慧。萨尔的萨满信仰指引着他的行动，他重整了部落，成为大酋长并领导他的人民在贫瘠之地上定居，那里正是以他的父亲杜隆坦的名字而命名的杜隆塔尔。", "unseen"]
                            ],
                            hero_valeera: ["female", "hs_rogue", 30, [],
                                ["des:", "unseen"]
                            ],
                            //皮肤
                            hero_medivh: ["male", "hs_mage", 30, [],
                                ["des:麦迪文是艾泽拉斯世界最强大的凡人法师之一，继承其母大部分守护者之力，其位于赤脊山脉以南的逆风小径的法师塔卡拉赞，藏有海量的魔法书，是足以碾压法师王国达拉然的魔法圣地。", "unseen"]
                            ],
                            hero_alleria: ["female", "hs_hunter", 30, [],
                                ["des:游侠三姐妹的大姐。奥蕾莉亚·风行者在巨魔战争中期，她击退了数之不尽的巨魔，最终高等精灵和人类的联盟在与巨魔的战争中获胜。", "unseen"]
                            ],
                            hero_liadrin: ["female", "hs_paladin", 30, [],
                                ["des:女伯爵莉亚德琳是银月城的血精灵圣骑士组织血骑士的女首领，曾是一位信仰圣光的高阶牧师，后对自己的信仰大失所望，并在接下来的数年中磨练自己的武艺。当穆鲁被带回银月城之后，莉亚德琳和罗曼斯利用他的圣光能量培养出身负圣光之力的战士，并成为了第一位血骑士并作为其领袖。她在组织中具有绝对的号召力与威信。将天灾军团驱逐后，她现在致力于将燃烧军团消灭殆尽。", "unseen"]
                            ],
                            hero_tyrande: ["female", "hs_priest", 30, [],
                                ["des:泰兰德出生于一万年前，与玛法里奥·怒风和伊利丹·怒风一同长大，成为一名新手女祭司。而怒风兄弟则走上了另一条道路。但当燃烧军团降临艾泽拉斯，他们的命运又再次发生了交集。泰兰德和玛法里奥走到了一起，并肩抵抗入侵的恶魔；而伊利丹则走上了一条黑暗的不归路，他假意与燃烧军团合作，并臣服于力量的诱惑。在击败燃烧军团，并发生大分裂之后，泰兰德和玛法里奥帮助重建的精灵国度；而伊利丹则被囚禁在海加尔山之下。", "unseen"]
                            ],
                            hero_magni: ["male", "hs_warrior", 30, [],
                                ["des:麦格尼·铜须国王是铁炉堡的统治者，是历史上最著名的矮人之一，作为一个统治者，他展现出了无比的勇气和慷慨无私的品质，总是将人民的需求置于自身所求之前。他曾执行了一个古老的仪式，试图与大地沟通以了解大地裂变事件的起源。但他还没找到答案，就被变成一具钻石雕像。但是这个仪式并没有杀死他，而是将他的灵魂与世界的内心连接到了一起。尽管麦格尼的肉身发生了的变化，但他高贵的品质却留了下来。", "unseen"]
                            ],
                            /*hero_elise: ["female", "hs_druid", 30, [],
                                ["des:伊莉斯·逐星是探险者协会四人小队中的领导者，种族为暗夜精灵，担任团队中的绘图师一职。她先是带领小队挫败了拉法姆偷取源生法杖的邪恶计划，之后自己率领了一支小队去安戈洛探险了。巨龙年伊始，拉法姆组建了怪盗军团想来一场惊天大阴谋，在他们夺走达拉然之后，伊莉斯也再次率领四人小队对抗老对手拉法姆，最终阻止了他。", "unseen"]
                            ],*/
                            hero_lunara: ["female", "hs_druid", 30, [],
                                ["des:露娜拉是半神塞纳留斯的长女。她的树妖妹妹们象征着自然的平和与宁静之美，而露娜拉也与她们相差不远。她是荒野的无情守护者，也是不朽的证明：利爪和荆棘之下的自然充满血色。", "unseen"]
                            ],
                            hero_nemsy: ["female", "hs_warlock", 30, [],
                                ["des:啃着卡利姆多暗夜精灵特产的天堂桃，表面上娇小玲珑的侏儒奈姆希·灵沼并不是看上去那么人畜无害，她是一名术士。与恶魔签订契约，以生命为代价，用灵魂进行交换，邪能和暗影在指尖流动。当她对你微笑的时候，千万不要被表象所迷惑，很有可能你已经成为了她下一个牺牲的目标。她身着腐蚀者套装，警告着每一个对她心存歹念的家伙，招惹术士就如同在刀尖上起舞。", "unseen"]
                            ],
                            hero_thunder: ["male", "hs_shaman", 30, [],
                                ["des:雷神在成年时他想要唤醒众神前往了魔古族的禁地雷霆山之心,在山中碰到了正在冥想的莱登。雷神质问这位曾经的主人,可莱登没有回答,然后雷神愤怒的夺走了莱登的守护者力量,成为了雷电之王。在获得风暴之力后雷神很快的开始了他的统一计划,征服了许许多多的种族。在与天神白虎神灵的战斗中获胜,还收获了许多仰慕者。", "unseen"]
                            ],
                            hero_maiev: ["female", "hs_rogue", 30, [],
                                ["des:", "unseen"]
                            ],
                            //染柒
                            hero_addiction: ["male", "hs_corruptor", 30, [],
                                ["des:一个炉石痴迷玩家，但不精通，玩过多种桌游，是无名杀的忠实粉丝，也是炉石普通的粉丝。", "unseen"]
                            ],
                        },
                        translate: {
                            //工具人
                            hs_player: "召唤师",
                            hs_comp: "召唤师",
                            //炉石普通
                            hero_garrosh_PT: "加尔鲁什",
                            hero_jaina_PT: "吉安娜",
                            hero_rexxar_PT: "雷克萨",
                            hero_anduin_PT: "安度因",
                            hero_guldan_PT: "古尔丹",
                            hero_malfurion_PT: "玛法里奥",
                            hero_uther_PT: "乌瑟尔",
                            hero_addiction_PT: "染柒",
                            //炉石传说
                            hero_garrosh: "加尔鲁什",
                            hero_jaina: "吉安娜",
                            hero_rexxar: "雷克萨",
                            hero_anduin: "安度因",
                            hero_guldan: "古尔丹",
                            hero_malfurion: "玛法里奥",
                            hero_uther: "乌瑟尔",
                            hero_thrall: "萨尔",
                            hero_valeera: "瓦莉拉",
                            //皮肤
                            hero_medivh: "麦迪文",
                            hero_alleria: "奥蕾莉亚",
                            hero_liadrin: "莉亚德琳",
                            hero_tyrande: "泰兰德",
                            //hero_elise: "伊莉斯",
                            hero_lunara: "露娜拉",
                            hero_magni: "麦格尼",
                            hero_nemsy: "奈姆希",
                            hero_thunder: "雷电之王",
                            hero_maiev: "玛维",
                            //染柒
                            hero_addiction: "染柒",

                            //技能
                            "hs_start": "重构",
                            "hs_start_info": "进入炉石普通的世界",
                        },
                        skill: {
                            "hs_start": { //开局之后重构万物的技能，包括设置样式，重新选人，组卡组，XJBG(瞎xx改)，然后僵硬联动整理手牌扩展
                                trigger: {
                                    global: ["gameDrawBefore", "phaseEnd"],
                                },
                                silent: true,
                                filter: function(event, player) {
                                    var bo = game.players.length == 2 && !_status.hs_entergame;
                                    if (game.players.length > 2) {
                                        player.say("你觉得炉石传说是" + get.cnNumber(game.players.length) + "个人玩的吗？");
                                    }
                                    return bo;
                                },
                                content: function() {
                                    "step 0"
                                    window.hearthstone.shijian.baseinit();
                                    "step 1"
                                    if (!lib.hearthstone) {
                                        game.me.say("加载失败");
                                        event.finish();
                                    }
                                    "step 2"
                                    lib.hearthstone.shijian.preinit(trigger);
                                    "step 3"
                                    lib.hearthstone.shijian.init();
                                    "step 4"
                                    lib.hearthstone.shijian.postinit();
                                    "step 5"
                                    lib.hearthstone.shijian.chooseCharacter();
                                    "step 6"
                                    if (!_status.connectMode && lib.config.extension_炉石普通_HS_duelMode == "brawl") lib.hearthstone.shijian.brawl();
                                    else lib.hearthstone.shijian.deckBuild();
                                    "step 7"
                                    lib.hearthstone.shijian.XJBG();
                                    "step 8" (function(e) {
                                        e.insert(lib.element.content.greeting);
                                    })(event);
                                    "step 9"
                                },
                            },
                            "hs_summonlimit": { //自己进行操作的技能
                                trigger: {
                                    global: ["phaseBefore", "phaseZhunbeiBegin", "chooseToUseBegin"],
                                },
                                filter: function(event, player) {
                                    if (event.name == "chooseToUse") {
                                        if (player == game.me) {
                                            game.me.HSF("hs_testfl");
                                        }
                                        get.HSF("checkall");
                                        event.prompt = "";
                                        return false;
                                    } else return event.player.isMin();
                                },
                                silent: true,
                                content: function() {
                                    trigger.cancel(null, null, "notrigger");
                                },

                                mod: {
                                    cardEnabled2: function(card, player) {
                                        var cost = player.HSF("mana");
                                        if (card.cost && cost < card.cost()) return false;
                                        if (get.type(card.name) == "HS_minor") {
                                            if (player.countFellow() == get.hs_nm()) return false;
                                        } else if (get.type(card.name) == "HS_spell") {
                                            var info = get.info(card);
                                            if (info.summoneff && player.hs_full()) return false;
                                            if (info.buffeff && !player.hasFellow()) return false;
                                            if (info.randomRT && !info.randomRT(player)) return false;
                                            if (info.sfilter && !info.sfilter(card, player)) return false;
                                        }
                                    },
                                    maxHandcardFinal: function(player, num) {
                                        return get.hs_nm() == 3 ? 5 : 10;
                                    },
                                },
                                global: "hs_summonlimit_a",
                                subSkill: {
                                    a: {
                                        mod: {
                                            targetEnabled: function(card, player, target) {
                                                if (!player.HSF("canbetarget", [card, target, "card"])) return false;
                                            },
                                        },
                                    },
                                },
                            },
                            "hs_battlephase": { //战斗阶段
                                charlotte: true,
                                enable: "phaseUse",
                                direct: true,
                                filter: function(event, player) {
                                    if (_status.event.isMine()) return false;
                                    return player.getFellowN(t => t.HSF("canatk"))
                                        .length > 0;
                                },
                                content: function() {
                                    "step 0"
                                    _status.hsbattling = true;
                                    var filter = (c, p, t) => t.HSF("canatk");
                                    player.chooseTarget("请选择攻击者", filter, t => {
                                        var base = 4;
                                        if (t.triggers.deathRattle && t.hp < 3) base += 3;
                                        if (t.triggers.hsdmg && t.triggers.hsdmg.fl) base += 3;
                                        if (t.hasgjz("shengdun")) base += 3;
                                        if (t.hasgjz("qianxing")) base -= 2;
                                        if (t.hasgjz("guanghuan")) base -= 3;
                                        if (t.hasgjz("jvdu")) base += 3;
                                        return base + t.ATK;
                                    });
                                    "step 1"
                                    if (result.bool) {
                                        var t = result.targets[0];
                                        t.classList.add("hs_atkprepare");
                                        if (t.isMin()) get.HSF("Aud", [t, "attack"]);
                                        else t.HSFT("攻击");
                                        event.attacker = t
                                    } else event.goto(9);
                                    "step 2"
                                    event.predate = new Date()
                                        .getTime();
                                    "step 3"
                                    var atk = event.attacker;
                                    var filter = function(card, player, target) {
                                        if (!player.HSF("canbetarget", [null, target, "attack"])) return false;
                                        return target.side != player.side;
                                    }
                                    player.chooseTarget("请选择攻击目标", filter, t => {
                                        if (player.ATK >= 4) return t.isMin() ? 0.1 : 1;
                                        var base = 40;
                                        if (!t.isMin()) base += atk.ATK;
                                        else {
                                            if (t.triggers.deathRattle) base -= 10;
                                            if (t.triggers.hsdmg && t.triggers.hsdmg.fl) base -= 6;
                                            if (t.hasgjz("guanghuan")) base += 3;
                                            if (atk.hasgjz("shengdun") || t.hasgjz("shengdun")) {
                                                if (atk.hasgjz("shengdun")) base += atk.ATK + t.ATK;
                                                if (t.hasgjz("shengdun")) base -= atk.ATK;
                                            } else if (atk.hasgjz("jvdu") || t.hasgjz("jvdu")) {
                                                if (atk.hasgjz("jvdu")) base += t.ATK + t.hp;
                                                if (t.hasgjz("jvdu")) base -= atk.ATK + atk.hp;
                                            } else {
                                                var val1 = atk.ATK + atk.hp;
                                                var val2 = t.ATK + t.hp;
                                                if (atk.ATK >= t.hp) base += val2;
                                                if (atk.hp <= t.ATK) base -= val1;
                                                else base += Math.min(t.hp, atk.ATK) - Math.min(atk.hp, t.ATK);
                                            }

                                        }
                                        return base > 0 ? base : 0.1;
                                    });
                                    "step 4"
                                    var jg = Math.round((new Date()
                                        .getTime() - event.predate) / 100) / 10;
                                    var atk = event.attacker;
                                    var dl = 0;
                                    if (event.isMine() && !event.hs_autoattack) {
                                        if (atk.isMin()) dl = 0.5;
                                        else dl = 1;
                                    } else {
                                        if (!atk.isMin()) dl = 1.5;
                                    }
                                    if (event.hs_autoattack && !atk.isMin()) {
                                        dl += 0.2;
                                    }
                                    if (dl - jg > 0) game.delay(dl - jg);
                                    "step 5"
                                    if (result.bool) {
                                        event.victim = result.targets[0];
                                    } else {
                                        event.attacker.classList.remove("hs_atkprepare");
                                        event.goto(9);
                                    }
                                    "step 6"
                                    event.attacker.hs_attack(event.victim);
                                    "step 7"
                                    get.HSF("checkwin", [event, true]);
                                    "step 8"
                                    if (player.getFellowN(t => t.HSF("canatk"))
                                        .length > 0) {
                                        event.reenter = true;
                                        event.goto(0);
                                    }
                                    if (!event.isMine() || event.hs_autoattack) get.HSF("think");
                                    "step 9"
                                    _status.hsbattling = false;
                                },
                                ai: {
                                    order: 0.1,
                                    result: {
                                        player: function(player) {
                                            return 1;
                                        },
                                    },
                                },
                            },
                            "_hs_damage": { //伤害计算步骤
                                silent: true,
                                charlotte: true,
                                priority: null,
                                firstDo: true,
                                trigger: {
                                    player: ["changeHp"],
                                },
                                filter: function(event, player, name) {
                                    return _status.hsgamestart;
                                },
                                content: function() {
                                    if (trigger.parent && !trigger.parent.hs_dmgrcv) {
                                        player.updatehsfl(trigger.num);
                                    }
                                },
                            },
                            "_hs_ADchange": { //回合开始和回合结束时清除状态
                                direct: true,
                                charlotte: true,
                                priority: 1,
                                trigger: {
                                    player: ["phaseBegin", "phaseZhunbeiBegin", "phaseJieshuBegin", "phaseEnd"],
                                },
                                filter: function(event, player, name) {
                                    return _status.hsgamestart && [game.me, game.enemy].contains(event.player);
                                },
                                content: function() {
                                    "step 0"
                                    "step 1"
                                    if (trigger.name != "phase") {
                                        _status.hdcsST = null;
                                        var bo = trigger.name == "phaseJieshu";
                                        if (bo) get.HSF("clickmana", [false]);
                                        get.HSF("xvlie", [(bo ? "ending" : "beginning") + "xl", {
                                            player: player,
                                        },
                                        true]);
                                    } else if (event.triggername == "phaseBegin") {
                                        player.hs_state.atks = 0;
                                        player.hs_state.useCard = 0;
                                        if (player == game.me) {
                                            ui.arena.hs_myturn.animate("active", 2000);
                                            get.HSF("Aud2", ["轮到你"]);
                                        }
                                        get.HSF("clickmana", [false]);
                                        get.HSF("checkcanatk");
                                        player.mana.locked.hide();
                                        player.storage.hs_mana_locked = player.storage.hs_mana_owed;
                                        player.storage.hs_mana_owed = 0;
                                        player.storage.hs_mana_used = player.storage.hs_mana_locked;
                                        if (player.storage.hs_mana_locked > 0) {
                                            player.mana.owed.show();
                                            player.mana.owed.classList.remove("owe");
                                            player.mana.owed.classList.add("lock");
                                            var tmp = player.mana.locked;
                                            player.mana.locked = player.mana.owed;
                                            player.mana.owed = tmp;
                                            setTimeout(function() {
                                                tmp.classList.remove("lock");
                                                tmp.classList.add("owe");
                                            }, 500);
                                        }
                                        var num = 1;
                                        if (get.hs_nm() == 3 && player == game.zhu.getOppo() && player.phaseNumber < 3) num = player.phaseNumber == 1 ? 2 : 0;
                                        player.HSF("gainmana", [num, true]);
                                        player.HSF("recovermana", ["all"]);
                                        player.HSF("updatemana");
                                        var skill = player.heroskill;
                                        skill.used = 0;
                                        get.HSF("checkheroskill");
                                        if (trigger.player == game.me) {
                                            ui.hs_endbtn.innerHTML = "回合结束";
                                            ui.hs_endbtn.classList.remove("hs_oppo");
                                        } else {
                                            ui.hs_endbtn.innerHTML = "对手回合";
                                            ui.hs_endbtn.classList.add("hs_oppo");
                                        }
                                        game.countPlayer(function(fl) {
                                            fl.hs_attacked = 0;
                                        });
                                    } else {
                                        ui.hs_endbtn.classList.remove("active");
                                        player.storage.hs_mana_temp = 0;
                                        if (player.HSF("mana") < 0) player.HSF("recovermana", [-player.HSF("mana"), false]);
                                        player.HSF("updatemana");
                                        game.countPlayer(function(fl) {
                                            if (fl.hasgjz("dongjied")) {
                                                if (player == fl.getLeader()) {
                                                    if (fl.willjiedong || fl.HSF("canatk", [null, true])) fl.removegjz("dongjied");
                                                    else fl.willjiedong = true;
                                                } else fl.willjiedong = true;
                                            }
                                            delete fl.summoned;
                                            var bin = [];
                                            for (var i of fl.buff) {
                                                if (typeof i.sleep == "number") {
                                                    i.sleep--;
                                                    if (i.sleep == 0) {
                                                        if (i.type == "auras") i.sleep = true;
                                                        else delete i.sleep;
                                                    }
                                                } else if (i.temp) {
                                                    if (!i.countphase || i.countphase == player) i.temp--;
                                                    if (i.temp == 0) bin.add(i);
                                                }
                                            }
                                            fl.removehsbuff(bin);
                                        });
                                        var id1 = game.me.playerid;
                                        var id2 = game.enemy.playerid;
                                        _status.hsAttendSeq.cl();
                                        _status.hs_dead = {};
                                        _status.hs_dead[id1] = [];
                                        _status.hs_dead[id2] = [];
                                        get.HSF("checkfellow");
                                    }
                                    "step 3"
                                },
                            },
                        },
                    };
                    if (lib.device || lib.node) {
                        for (var i in hearthstone.character) {
                            hearthstone.character[i][4].push('ext:炉石普通/' + i + '.jpg');
                        }
                    } else {
                        for (var i in hearthstone.character) {
                            hearthstone.character[i][4].push('db:extension-炉石普通:' + i + '.jpg');
                        }
                    }
                    return hearthstone;
                });
                lib.config.all.characters.push('hearthstone');
                if (!lib.config.characters.contains('hearthstone')) lib.config.characters.push('hearthstone');
                lib.translate['hearthstone_character_config'] = '炉石普通';

            }
        },
        config: {
            "HS_audioeffect": {
                "name": "音效",
                "init": true,
            },
            "hscardback": {
                "name": "卡背",
                "init": "经典卡背",
                "intro": "设置卡背",
                "item": _status.hsextra,
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_hscardback", item);
                },
                "visualMenu": function(node, link, name) { //link是冒号前面的，比如default:经典卡背，link就是default
                    node.style.height = node.offsetWidth * 1.3 + "px"; //高度设置成宽度的1.3倍
                    node.style.backgroundSize = '100% 100%'; //图片拉伸
                    if (link == "default") link = "经典卡背"; //如果选的default，那么图片是经典卡背.jpg
                    node.className = 'button character incardback'; //后面的incardback是我自定义的，不需要
                    node.setBackgroundImage('extension/炉石普通/cardback/' + link + '.jpg'); //设置图片
                },
            },
            "HS_enemycardback": {
                "name": "ai卡背",
                "init": "same",
                "item": {
                    "same": "和你相同",
                    "random": "随机",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_enemycardback", item);
                },
            },
            "HS_aichosen": {
                "name": "ai选人",
                "init": "random",
                "intro": "ai选决斗者的倾向",
                "item": {
                    "random": "随机",
                    "male": "男决斗者",
                    "female": "女决斗者",
                    "player": "你来选",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_aichosen", item);
                },
            },
            "HS_aideck": {
                "name": "ai卡组",
                "init": "default",
                "intro": "设置ai卡组内容",
                "item": {
                    "default": "默认卡组",
                    "yourdeck": "你组的卡组",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_aideck", item);
                },
            },
            "HS_first": {
                "name": "先后攻",
                "init": "random",
                "intro": "决定先后攻的方法",
                "item": {
                    "random": "随机",
                    "first": "先攻",
                    "second": "后攻",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_first", item);
                },
            },
            "HS_think": {
                "name": "思考时间",
                "init": "long",
                "item": {
                    "fastest": "0.1秒",
                    "fast": "0.5秒",
                    "medium": "1秒",
                    "long": "2秒",
                    "slow": "3秒",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_think", item);
                },
            },
            "HS_duelMode": {
                "name": "游戏模式",
                "init": "legend",
                "intro": "选择游戏模式",
                "item": {
                    "normal": "炉石普通",
                    "legend": "炉石传说",
                    "single": "左右互搏",
                    "brawl": "随机乱斗",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_duelMode", item);
                },
            },
            "HS_brawl_range": {
                "name": "乱斗范围",
                "init": "all",
                "intro": "选择游戏模式",
                "item": {
                    "all": "全部",
                    "specialdeck": "随机套牌",
                    "boss": "挑战首领",
                },
                "onclick": function(item) {
                    game.saveConfig("extension_炉石普通_HS_brawl_range", item);
                },
            },
            "hs_big_img": {
                "name": "大图样式",
                "init": false,
                "intro": "还是看不清？试试这个！",
            },
            "HS_debug": {
                "name": "debugger",
                "init": false,
                "intro": "新手勿开。开启后，左上会出现调试按钮，点击会开启/停止css样式的自动更新。减少开局动画的延迟时间，点击卡牌收藏显示卡牌代码。",
            },
            "HS_reset": {
                "name": "重置存档",
                "intro": "清空所有卡组数据",
                "clear": true,
                "onclick": function() {
                    if (confirm("此操作不可逆，是否要清空所有卡组数据？")) {
                        delete lib.storage.hs_deck;
                        delete lib.storage.hs_deckname;
                        game.save("hs_deck", undefined);
                        game.save("hs_deckname", undefined);
                    }
                },
            },
        },
        package: {
            character: {
                character: {},
                translate: {},
            },
            card: {
                card: {},
                translate: {},
                list: [],
            },
            skill: {
                skill: {},
                translate: {},
            },
            intro: "炉石普通，简化炉石规则的<br><span class=firetext>乱斗模式</span>扩展。",
            author: "永远的萌新",
            diskURL: "",
            forumURL: "",
            version: "",
        },
        files: {
            "character": [],
            "card": [],
            "skill": []
        }
    }
})