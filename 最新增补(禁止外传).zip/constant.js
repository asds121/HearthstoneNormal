	"use strict";
	hearthstone.use(function(lib, game, ui, get, ai, _status) {
	    hearthstone.const = { //RD常量
	        line: {
	            "time": 1000,
	            "position": "screen",
	            "width": "256px",
	            "height": "128px",
	            "backgroundSize": "100% 100%",
	            "opacity": 1,
	            "show": "none",
	            "fade": true,
	            "pause": false,
	            "rate_zhen": 18,
	            "jump_zhen": false,
	            "qianzhui": "",
	            "liang": false,
	            "isLine": true,
	            "cycle": true,
	            "style": {},
	            "skills": [],
	            "cards": [],
	            "forbid": false
	        },
	        clickatk: function() {
	            if (!_status.hsbattling) this.HSF("morefocus");
	            var tht = this;
	            if (game.me.HSF("phaseUse")) {
	                var atker = _status.hs_pressatker;
	                if (!atker) { //如果没选攻击者
	                    if (tht.getLeader() == game.me) {
	                        if (tht.HSF("canatk")) {
	                            _status.hsbattling = true;
	                            _status.hs_pressatker = tht;
	                            tht.classList.add("hs_atkprepare");
	                            if (tht.isMin()) get.HSF("Aud", [tht, "attack"]);
	                            else tht.HSFT("攻击");
	                        } else {
	                            if (tht == game.me && !tht.data_weapon) game.me.HSFT("需要武器");
	                            else if (tht.hs_atk_max + tht.hs_ex_atk <= tht.hs_attacked) {
	                                if (tht.isMin()) game.me.HSFT("随从已攻击");
	                                else game.me.HSFT("英雄已攻击");
	                            } else if (tht.summoned && !tht.hasgjz("chongfeng")) game.me.HSFT("随从需准备");
	                            else game.me.HSFT("普通错误");
	                        }
	                    }
	                } else { //否则选攻击目标
	                    var cancel = function() {
	                        _status.hsbattling = false;
	                        _status.hs_pressatker.classList.remove("hs_atkprepare");
	                        delete _status.hs_pressatker;
	                    };
	                    if (atker.sctp("opposide", tht)) { //如果选了对方的目标
	                        if (game.me.HSF("canbetarget", [null, tht, "attack"])) { //如果攻击成立
	                            _status.hs_pressdef = tht;
	                            tht.animate("target");
	                            lib.skill.hs_presstoatk = {
	                                direct: true,
	                                content: function() {
	                                    "step 0"
	                                    event.attacker = _status.hs_pressatker;
	                                    event.victim = _status.hs_pressdef;
	                                    event.attacker.hs_attack(event.victim)
	                                        .quick = true;
	                                    "step 1"
	                                    delete _status.hs_pressatker;
	                                    delete _status.hs_pressdef;
	                                    _status.hsbattling = false;
	                                },
	                            };
	                            ui.click.skill("hs_presstoatk");
	                        } else { //不是合理目标
	                            cancel();
	                            if (tht.hasgjz("qianxing")) game.me.HSFT("攻击潜行随从");
	                            else if (!tht.HSF("hasCFeff") && tht.sctp("myside_", t => t.HSF("hasCFeff"))) game.me.HSFT("场面有嘲讽");
	                            else game.me.HSFT("普通错误");
	                        }
	                    } else cancel();
	                }
	            }
	        },
	        animationpath: "extension/炉石普通/image/animation_image/",
	        brawlscene: [{
	            name: "转角撞见鬼",
	            type: "specialdeck",
	            intro: "使用随机套牌进行游戏。套牌中的所有牌全部随机，你永远猜不到下一张牌会给你带来惊喜还是惊吓！每次进入乱斗，你都会重新获得一副和之前不同的随机套牌。",
	            deck: {
	                random: 30,
	            },
	        }, {
	            name: "勇闯盘丝洞",
	            type: "specialdeck",
	            intro: "使用随机套牌进行游戏。玩家的套牌由23张结网蛛和7张所选英雄的随机法术构成。每次乱斗中，你得到的法术都不尽相同。同一法术可能有多张。",
	            deck: {
	                randomSpell: 7,
	                certain: ["结网蛛", 23],
	            },
	        }, {
	            name: "遍地传送门",
	            type: "specialdeck",
	            intro: "使用随机套牌进行游戏。玩家的套牌由23张不稳定的传送门和7张所选职业的随机法术构成。每次乱斗中，你得到的法术都不尽相同。在某次乱斗的套牌中，同一法术可能有多张。",
	            deck: {
	                randomSpell: 7,
	                certain: ["不稳定的传送门", 23],
	            },
	        }, {
	            name: "挑战帕奇维克",
	            type: "boss",
	            intro: "帕奇维克先手，装备一把4/8并带有风怒的铁钩，英雄技能为4费消灭一个随从。",
	            prepare: {
	                equip: "铁钩",
	                first: true,
	                deck: [],
	                nophasedraw: true,
	            },
	        },
	        /* {
	            name: "挑战大宝",
	            type: "boss",
	            intro: "大宝先手，装备一把5/3的灰烬使者，英雄技能为0费，对所有随从造成一点伤害，抽一张牌。卡组为30张藏海。",
	            diy: true,
	            prepare: {
	                cardback: "NAXX",
	                equip: "灰烬使者",
	                first: true,
	                deck: new Array(30)
	                    .fill("藏海"),
	            },
	        }, */
],
	        bossinfo: { //首领
	            帕奇维克: {
	                base: ["leader_pqwk", "male", 45, "chdj"],
	                chdj: ["仇恨打击", "消灭一个随从", "hs_leader", 4, "target.HSF('cuihui')", ["F:mns", "return get.dmgEffect(target, player, player,2)+ (target.HSF('hasCFeff')?100:0)+ target.hp*3;"], {
	                    order: function() {
	                        var p = get.player();
	                        if (p.sctp("notmine")
	                            .filter(i => i.HSF("hasCFeff"))
	                            .length > 1) return 6;
	                        else return 0.05;
	                    },
	                    result: {
	                        player: 1
	                    },
	                }],
	            },
	            大宝: {
	                base: ["leader_dabao", "male", 40, "chdj"],
	                chdj: ["旋风斩", "对所有随从造成一点伤害，抽一张牌。", "hs_leader", 0, "get.HSF('bladeeffect',['damage',1]);player.draw();"],
	            },
	        },
	        funcs: {
	            //battleRoal
	            龙牌: function(p, c) {
	                return p.countCards("h", ca => ca != c && get.rkind(ca) == "dragon") > 0;
	            },
	            宇宙: function(p, c) {
	                var cs = p.cardPile.getCards("h")
	                    .map(i => i.name);
	                return Array.from(new Set(cs))
	                    .length == cs.length;
	            },
	            //recheck
	            手多: function(evt, p, f) {
	                return p.countCards("h") > p.getOppo()
	                    .countCards("h");
	            },
	            满场: function(evt, p, f) {
	                return p.countFellow() < get.hs_nm();
	            },
	            存活: function(evt, p, f) {
	                return f.HSF("alive");
	            },
	            法术: function(evt, p) {
	                return get.type(evt.card) == "HS_spell";
	            },
	            法术目标: function(evt, p, f) {
	                return get.type(evt.card) == "HS_spell" && evt.target == f;
	            },
	            //range
	            leader: function(f, t) {
	                return t == f.getLeader();
	            },
	            mine_: function(f, t) {
	                return f.sctp("mine_", t);
	            },
	            //filterTarget
	            fl: function(c, p, t) {
	                return t.isMin();
	            },
	        },
	        //职业图标
	        ns: ["hs_mage", "hs_warrior", "hs_priest", "hs_hunter", "hs_warlock", "hs_druid", "hs_paladin", "hs_rogue", "hs_shaman", "hs_corruptor", "hs_neutral"],
	        //加粗关键字
	        jiacu: ["沉默", "冻结", "潜行", "免疫", "战吼", "亡语", "激怒", "冲锋", "风怒", "圣盾", "嘲讽", "剧毒", "吸血", "激励", "传说", "零件",
	            "抽到时施放", "每回合限一次"],
	        //异能关键字
	        yineng: {冻结: "dongjie",
	            魔免: "momian",
	            健忘: "jianwang",
	            潜行: "qianxing",
	            免疫: "mianyi",
	            冲锋: "chongfeng",
	            风怒: "fengnu",
	            圣盾: "shengdun",
	            嘲讽: "chaofeng",
	            剧毒: "jvdu",
	            吸血: "xixie",
	            超怒: "superfengnu",
	        },
	        //隐藏关键字
	        yincang: {
	            "冻结任何受到该随从伤害的角色": "冻结",
	            "无法成为法术或英雄技能的目标": "魔免",
	            "50%几率攻击错误的敌人": "健忘",
	            "超级风怒": "超怒",
	            "冲冲冲冲锋": "冲锋",
	        },
	        //扳机(如果不加上，该时机效果无法触发)
	        triggers: ["battleRoal", "deathRattle", "jili", "beginning", "ending", //关键时机
	        "useCard", "useCardAfter", "hsdmgBefore", "hsdmgBegin1", "hsdmgBegin2",
	            "hsdmg", "hsrcv", "summonBefore", "summonSucc", "summonAfter", "deathFL",
	            "equipBefore", "equipAfter", "attackBefore", "attackBegin",
	            "attackEnd", "overload", "discard", "discarded", "heroskillAfter",
	            "drawAfter"],
	        //扳机关键字英文
	        ywm: {战吼: "battleRoal",
	            亡语: "deathRattle",
	            激励: "jili",
	            开始: "beginning",
	            结束: "ending",
	        },
	        //复杂描述解析
	        fzms: {
	            "每开": ["在每个回合开始时", "beginning"],
	            "每束": ["在每个回合结束时", "ending"],
	            "开始": ["在你的回合开始时", "beginning", {
	                self: true,
	            }],
	            "结束": ["在你的回合结束时", "ending", {
	                self: true,
	            }],
	            "法前": ["每当你施放一个法术便", "useCard", {
	                self: true,
	                filter: "法术",
	            }],
	            "法后": ["在你施放一个法术后", "useCardAfter", {
	                self: true,
	                filter: "法术",
	            }],
	            "邪使": ["每当你以该随从为目标施放一个法术时便", "useCard", {
	                filter: "法术目标",
	                self: true
	            }],
	            "用时": ["每当你使用一张牌时便", "useCard", {
	                self: true,
	                notlink: true
	            }],
	            "受伤": ["每当该随从受到伤害", "hsdmg", {
	                fl: true
	            }],
	        },
	        fullname: {
	            jaina: "吉安娜·普罗德摩尔",
	            garrosh: "加尔鲁什·地狱咆哮",
	            anduin: "安度因·乌瑞恩",
	            malfurion: "玛法里奥·怒风",
	            uther: "乌瑟尔·光明使者",
	            valeera: "瓦莉拉·萨古纳尔",
	            tyrande: "泰兰德·语风",
	            liadrin: "女伯爵莉亚德琳",
	            magni: "麦格尼·铜须",
	            alleria: "奥蕾莉亚·风行者",
	            //elise: "伊莉斯·逐星",
	            lunara: "露娜拉",
	            nemsy: "奈姆希·灵沼",
	        },
	        //仅用于标记
	        bjcls: ["hs_legend", "hs_DIYfl", "guanghuan", "banji", "wangyu", "jili"],
	        //沉默去除的关键字
	        canchenmo: ["jinu", "chenmo", "chaofeng", "shengdun", "fengnu", "superfengnu", "chongfeng", "mianyi", "dongjie", "dongjied", "qianxing", "jvdu", "xixie", "momian"],
	        //沉默去除的状态
	        canchenmozt: ["noattack"],
	        //可选英雄
	        duelist: ["hero_jaina", "hero_garrosh", "hero_rexxar", "hero_anduin", "hero_guldan", "hero_malfurion", "hero_uther", "hero_thrall", "hero_valeera", "hero_addiction"],
	        //英雄皮肤
	        skin: ["hero_medivh", "hero_alleria", "hero_liadrin", "hero_tyrande", "hero_magni",
	        /*"hero_elise", */
	        "hero_lunara", "hero_nemsy", "hero_thunder", "hero_maiev"],
	        //diy职业
	        diy: ["hs_corruptor"],
	        //翻译
	        //稀有度
	        rarity: {
	            essential: "基础",
	            ordinary: "普通",
	            rare: "稀有",
	            epic: "史诗",
	            legend: "传说",
	        },
	        //职业
	        easy: {
	            "hs_mage": "法师",
	            "hs_warrior": "战士",
	            "hs_priest": "牧师",
	            "hs_hunter": "猎人",
	            "hs_warlock": "术士",
	            "hs_druid": "德鲁伊",
	            "hs_paladin": "圣骑士",
	            "hs_rogue": "潜行者",
	            "hs_shaman": "萨满祭司",
	            "hs_corruptor": "腐化者",
	            "hs_neutral": "中立",
	            "hs_dream": "梦境",
	            "hs_leader": "首领",
	        },
	        //种族
	        rkind: {
	            dragon: "龙",
	            totem: "图腾",
	            demon: "恶魔",
	            wildbeast: "野兽",
	            murloc: "鱼人",
	            machine: "机械",
	            none: "无",
	            pirate: "海盗",
	            goblin: "哥布林",
	        },
	        //随从缩写翻译
	        cdan: {大螺丝: "炎魔之王拉格纳罗斯",
	            铜须: "布莱恩·铜须",
	            吼爹: "格罗玛什·地狱咆哮",
	            血法: "血法师萨尔诺斯",
	            马云: "麻风侏儒",
	            叫嚣: "叫嚣的中士",
	            林志玲: "银色神官帕尔崔丝",
	            蛋总: "伊利丹·怒风",
	            安东尼: "大法师安东尼达斯",
	            二王: "玛尔加尼斯",
	            詹姆斯: "银背族长",
	            猪: "变形术：野猪",
	            哀绿: "巫师学徒",
	            穿刺: "穿刺者戈莫克",
	            火车王: "火车王里诺艾",
	            红龙: "阿莱克丝塔萨",
	            蓝龙: "玛里苟斯",
	            芬克: "芬克·恩霍尔",
	            风投: "风险投资公司雇佣兵",
	            奥金尼: "奥金尼灵魂祭司",
	            环: "治疗之环",
	            盾: "真言术：盾",
	            痛: "暗言术：痛",
	            灭: "暗言术：灭",
	            发财: "雷诺·杰克逊",
	            电线杆: "上古看守者",
	            二五仔: "疯狂投弹者",
	            无面: "无面操纵者",
	            AC: "精灵弓箭手",
	            飞刀: "飞刀杂耍者",
	            老司机: "老式治疗机器人",
	            爆牌鱼: "寒光智者",
	            影子: "纳克萨玛斯之影",
	            战利品: "战利品贮藏者",
	            城管: "奥尔多卫士",
	            男爵: "瑞文戴尔男爵",
	            生平: "生而平等",
	            烧烤: "狂野炎术师",
	            董大师: "淤泥喷射者",
	            王师傅: "齿轮大师",
	            王阿姨: "吵吵机器人",
	            老牛: "凯恩·血蹄",
	            钓鱼王: "纳特·帕格",
	            飞机头: "米米尔隆的头部",
	            飞机: "V-07-TR-0N",
	            老佛爷: "提里奥·弗丁",
	            奥垃圾: "风领主奥拉基尔",
	            电视: "召唤传送门",
	            力代: "力量的代价",
	            图哈特: "裁决者图哈特",
	            天师: "坑道穴居人",
	            纯净水: "耐普图隆",
	            马桶: "法力之潮图腾",
	            打蛋器: "自动漩涡打击装置",
	            花母鸡: "斯尼德的伐木机",
	            小软: "酸性沼泽软泥怪",
	            微软: "血帆海盗",
	            传送门: "不稳定的传送门",
	            工匠大师: "工匠大师欧沃斯巴克",
	            囚徒: "哈里森·琼斯",
	            萨兰德: "虚灵勇士萨兰德",
	            傻子王: "食人魔勇士穆戈尔",
	            冰环: "冰霜新星",
	            多彩狗: "克洛玛古斯",
	            克总: "克尔苏加德",
	            四驱车: "烈焰巨兽",
	            女王: "希尔瓦娜斯·风行者",
	            tc130: "精神控制技师",
	            白富美: "秘教暗影祭司",
	            缩小: "缩小射线工程师",
	        },
	        exhrsk: {
	            //图哈特
	            diej: ["坚壁", "获得4点护甲", "hs_warrior", 2, "player.changeHujia(4);"],
	            huoc: ["二级火焰冲击", "造成2点伤害", "hs_mage", 2, "target.hs_dmgrcv('damage',2,player,'fire').hs_heroskill=true;", ["F:all", "return get.dmgEffect(target, player, player,2) + 0.1;"], {
	                order: 6,
	                result: {
	                    player: function(player) {
	                        if (game.hasPlayer(function(target) {
	                            return get.dmgEffect(target, player, player, 2) + 0.1 > 0;
	                        })) return 1;
	                        else return 0;
	                    },
	                },
	            }],
	            shej: ["弩炮射击", "对敌方英雄造成3点伤害", "hs_hunter", 2, "target.hs_dmgrcv('damage',3, player).hs_heroskill=true;", "R:function(player){return player.getOppo();}"],
	            zhil: ["治疗术", "恢复4点生命值", "hs_priest", 2, "target.hs_dmgrcv('recover',4,player).hs_heroskill=true;", ["F:all", "return get.rcvEffect(target, player, player,1) + 0.1;"], {
	                order: 1,
	                result: {
	                    player: function(player) {
	                        var val = Math.max.apply(Math, player.sctp()
	                            .map(i => get.rcvEffect(i, player, player) + 1));
	                        return val;
	                    },
	                },
	            }],
	            fenl: ["灵魂分流", "抽一张牌", "hs_warlock", 2, "player.hs_drawDeck();", "", {
	                order: 6,
	                result: {
	                    player: function(player) {
	                        if (player.cardPile.countCards("h")) return 1;
	                        else return 0;
	                    },
	                },
	            }],
	            biax: ["恐怖变形", "本回合+2攻击力。+2护甲值。", "hs_druid", 2, "player.hs_atkhj([2,2]);"],
	            yuaj: ["白银之手", "召唤两个1/1的白银之手新兵。", "hs_paladin", 2, "player.SSfellow(['白银之手新兵',2]);"],
	            ttzh: ["图腾崇拜", "召唤一个你想要的图腾。", "hs_shaman", 2, "player.SSfellow(['白银之手新兵',2]);"],
	            shad: ["浸毒匕首", "装备一把2/2的匕首。", "hs_rogue", 2, "player.hs_weapon('浸毒匕首').hs_heroskill=true;", "", {
	                order: 6,
	                result: {
	                    player: function(player) {
	                        if (player.data_weapon) return 0;
	                        else return 1;
	                    },
	                },
	            }],
	            //其他
	            ltngjlt: ["雷霆震击", "造成2点伤害。", "hs_shaman", 2, "target.hs_dmgrcv('damage',2,player,'thunder').hs_heroskill=true;", ["F:all", "return get.dmgEffect(target, player, player,2) + 0.1;"], {
	                order: 6,
	                result: {
	                    player: function(player) {
	                        if (game.hasPlayer(function(target) {
	                            return get.dmgEffect(target, player, player, 2) + 0.1 > 0;
	                        })) return 1;
	                        else return 0;
	                    },
	                },
	            }],
	        },
	        anms: { //入场动画
	            飞入: ["雏龙"],
	            报告: ["白银之手新兵"],
	            火车王: ["火车王里诺艾"],
	        },
	        anmstm: { //入场动画延时多久播放音效
	            报告: 1200,
	            火车王: 500,
	        },
	        specialAudio: { //卡牌语音彩蛋
	            "伊利丹·怒风": ["玛法里奥"],
	            "凯恩·血蹄": ["加尔鲁什"],
	            "瓦里安·乌瑞恩": ["安度因"],
	        },
	        collect: { //卡牌小类
	            动物伙伴: ["雷欧克", "霍弗", "米莎"],
	            图腾: ["治疗图腾", "石爪图腾", "灼热图腾", "空气之怒图腾"],
	        },
	        audioDura: { //台词时长
	            吉安娜: {开局: 1,
	            },
	            泰兰德: {开局: 1,
	                玛法里奥: 2,
	            },
	            莉亚德琳: {开局: 3,
	            },
	            露娜拉: {开局: 1,
	            },
	            古尔丹: {开局: 3,
	            },
	            加尔鲁什: {开局: 3,
	            },
	            雷克萨: {开局: 1,
	            },
	            萨尔: {开局: 1,
	            },
	            雷电之王: {开局: 4,
	            },
	        },
	        台词: {
	            common: {牌库快空: "我的卡牌就快要用光了！",
	                牌库空: "我已经没有卡牌了！",
	                爆牌: "我的手牌已经满了",
	                错误1: "我没有足够的法力值！",
	                错误2: "我无法拥有更多随从了！",
	                错误3: "我不能使用这张牌！",
	                错误4: "我已经使用过英雄技能了！",
	                错误5: "我无法这么做！",
	            },
	            加尔鲁什: {开局: "不胜利，毋宁死",
	                镜像开局: "哈哈哈，有种来啊",
	                攻击: "Lok'tar ogar",
	                投降: "我选择死亡。"
	            },
	            吉安娜: {开局: "这可是你自找的",
	                镜像开局: "那就来吧",
	                攻击: "我准备好了",
	                投降: "你...赢了。",
	            },
	            雷克萨: {开局: "狩猎开始了",
	                镜像开局: "看谁笑到最后",
	                攻击: "我亲自出马",
	                投降: "打得好，我认输。",
	            },
	            安度因: {开局: "圣光将赐予我胜利",
	                镜像开局: "圣光也向我露出了微笑",
	                攻击: "以圣光之名",
	                投降: "你击败了我",
	            },
	            古尔丹: {开局: "我会夺取你的灵魂",
	                镜像开局: "我将成为你的梦魇",
	                攻击: "吃点苦头吧",
	                投降: "这次是你赢了",
	            },
	            玛法里奥: {开局: "我是大自然的守护者",
	                镜像开局: "谨遵大自然的教诲！",
	                攻击: "为了大自然",
	                投降: "我承认，你赢了",
	                //彩蛋
	                泰兰德: "泰兰德，我的挚爱",
	            },
	            乌瑟尔: {开局: "荣耀赐予我力量！",
	                镜像开局: "圣光就是我的利刃",
	                攻击: "为了正义！",
	                投降: "胜利属于你",
	            },
	            萨尔: {开局: "为了毁灭之锤！",
	                镜像开局: "为了部落！",
	                攻击: "元素之灵，指引我吧！",
	                投降: "这局你赢了，朋友！",
	            },
	            瓦莉拉: {开局: "当心你的背后",
	                镜像开局: "不用你提醒我，哼",
	                攻击: "我们上",
	                投降: "我输了",
	            },
	            //皮肤
	            麦迪文: {开局: "就让比赛开始吧",
	                镜像开局: "哦，比赛已经开始了",
	                攻击: "用武器攻击还真是滑稽",
	                投降: "这是步好棋，我认输",
	                需要武器: "我需要一把武器",
	                法力值不够: "我没有足够的法力值",
	                随从已攻击: "那个随从已经攻击过了",
	                英雄已攻击: "我已经攻击过了",
	                随从需准备: "给那个随从一个回合的准备时间",
	                手牌十张: "我的手牌满了！",
	                满场七随从: "我召唤了太多的随从！",
	                攻击潜行随从: "我不能以潜行的随从作为目标",
	                不能使用: "我不能使用这张牌",
	                非有效目标: "这不是一个合理的目标",
	                场面有嘲讽: "我必须攻击那个具有嘲讽的随从",
	                普通错误: "我不能这么做",
	            },
	            奥蕾莉亚: {开局: "在精灵的力量面前颤抖吧！",
	                镜像开局: "我从不颤抖！",
	                攻击: "你的死期将至！",
	                投降: "你技高一筹，我认输",
	            },
	            莉亚德琳: {开局: "神圣之火燃烧着我的战刃！",
	                镜像开局: "神圣之火正是我的名号",
	                攻击: "在神圣之火中燃烧！",
	                投降: "朋友，你赢了。我认输",
	            },
	            泰兰德: {开局: "艾露恩赐予我力量",
	                镜像开局: "月神庇护着我",
	                攻击: "为了艾露恩！",
	                投降: "结束吧，你赢了",
	                //彩蛋
	                玛法里奥: "我亲爱的玛法里奥",
	            },
	            麦格尼: {开局: "为了卡兹莫丹！",
	                镜像开局: "是的，为了卡兹莫丹！",
	                攻击: "吃我一锤！",
	                投降: "啊，你战胜了我",
	            },
	            /*伊莉斯: {开局: "开始上课了！",
	                镜像开局: "主修考古学怎么样？",
	                攻击: "Aluth neladar！",
	                投降: "胜利属于你",
	            },*/

	            露娜拉: {开局: "森林也是会反抗的！",
	                镜像开局: "为了大自然！",
	                攻击: "这很管用",
	                投降: "我输了",
	                玛法里奥: "Ishnu'alah，大德鲁伊",
	            },
	            奈姆希: {开局: "让我们来找点乐子吧！",
	                镜像开局: "耶！真是棒极了！",
	                攻击: "一起嗨起来！",
	                投降: "厉害！这次是你赢了",
	            },
	            雷电之王: {开局: "吾乃弑君之君，诛神之神",
	                镜像开局: "如此，才配与我一战",
	                攻击: "你犯了一个可悲的错误",
	                投降: "这一次，算你赢",
	            },
	            玛维: {开局: "没人能逃出我的手掌心！",
	                镜像开局: "我就是正义之手！",
	                攻击: "我代表正义消灭你！",
	                投降: "打得好，我认输",
	            },
	            //染柒
	            染柒: {开局: "不要靠近我的头发！",
	                镜像开局: "比比看，谁的小蜘蛛更厉害？",
	                攻击: "快停下来，根本打不死人啦！",
	                投降: "大佬666",
	            },
	            //特殊随从台词
	            奈法利安: {德鲁伊: "德鲁伊，大自然已经听命于我了！",
	                猎人: "现在，猎人成了猎物！",
	                法师: "法师，小心你的魔法把你毁了！",
	                圣骑士: "圣骑士！你是不是已经被圣光抛弃了？",
	                牧师: "牧师！现在圣光服从于我！",
	                潜行者: "潜行者，别躲躲藏藏了，面对我吧！",
	                萨满祭司: "萨满！现在元素听从我的号令！",
	                术士: "术士，你在玩弄你根本不了解的魔法！",
	                战士: "战士，你的力量将成为你的弱点！",
	                腐化者: "腐化者，见识下真正的用毒大师！",
	                中立: "你的魔法归我了！",
	            },
	            //首领
	            帕奇维克: {开局: "帕奇维克要跟你玩！",
	                死亡: "帕奇维克怎么了……啊……",
	            },
	            大宝: {开局: "不要犯大吴疆土哦",
	                攻击: ["若敢来犯，必叫你大败而归", "犯大吴疆土者，盛必击而破之"],
	                死亡: "盛只恨，不能再为主公，破敌致胜了……",
	            },
	        },
	        ski: { //专属技能描述
	            summon: ["召唤", "从手牌召唤一个随从"],
	            battle: ["进攻", "一名角色对另一名角色发起进攻"],
	            death: ["阵亡", "这些角色阵亡，并移出游戏"],
	        },
	        dftDeck: { //默认卡组
	            hero_garrosh_PT: [
	                "旋风斩*2",
	                "狼骑兵*2",
	                "英勇打击*1",
	                "严酷的监工*2",
	                "霜狼步兵*2",
	                "吼爹*1", ],
	            hero_jaina_PT: [
	                "巫师学徒*2",
	                "寒冰箭*1",
	                "火球术*2",
	                "冰枪术*2",
	                "奥术飞弹*1",
	                "血法师萨尔诺斯*1",
	                "大法师安东尼达斯*1"],
	            hero_rexxar_PT: [
	                "石牙野猪*2",
	                "狼骑兵*2",
	                "恐狼前锋*2",
	                "动物伙伴*2",
	                "杀戮命令*2", ],
	            hero_anduin_PT: [
	                "沉默*2",
	                "真言术：盾*2",
	                "闪金镇步兵*2",
	                "肉用僵尸*2",
	                "蹒跚的食尸鬼*2", ],
	            hero_addiction_PT: [
	                "寻宝*1",
	                "萃毒*2",
	                "守护之心*2",
	                "毒雾*1",
	                "蛇发女妖*1",
	                "哥布林术士*1",
	                "禁术法师*1",
	                "美杜莎之女*1", ],
	            //炉石传说
	            hero_garrosh: [
	                "怒火中烧*2",
	                "旋风斩*2",
	                "斩杀*2",
	                "战斗怒火*2",
	                "严酷的监工*2",
	                "铸甲师*2",
	                "蹒跚的食尸鬼*2",
	                "炽炎战斧*2",
	                "战歌指挥官*2",
	                "暴乱狂战士*2",
	                "盾牌格挡*1",
	                "苦痛侍僧*2",
	                "死亡之咬*2",
	                "侏儒发明家*1",
	                "恐怖的奴隶主*2",
	                "索瑞森大帝*1",
	                "格罗玛什·地狱咆哮*1"],
	            hero_jaina: [
	                "机械跃迁者*2",
	                "法力浮龙*2",
	                "奥术飞弹*2",
	                "不稳定的传送门*2",
	                "碎雪机器人*2",
	                "巫师学徒*2",
	                "镜像*2",
	                "寒冰箭*2",
	                "火球术*2",
	                "蜘蛛坦克*2",
	                "麦田傀儡*2",
	                "冰枪术*2",
	                "吵吵机器人*2",
	                "齿轮大师*2",
	                "烈焰轰击*2"],
	            hero_rexxar: [
	                "快速射击*2",
	                "关门放狗*2",
	                "鹰角弓*2",
	                "奥术射击*2",
	                "食腐土狼*2",
	                "猎人印记*2",
	                "森林狼*2",
	                "召唤宠物*2",
	                "动物伙伴*2",
	                "驯兽师*2",
	                "杀戮命令*2",
	                "暴躁的牧羊人*2",
	                "长鬃草原狮*2",
	                "结网蛛*2",
	                "加兹瑞拉*1",
	                "暴龙王克鲁什*1"],
	            hero_anduin: [
	                "神圣惩击*2",
	                "真言术：盾*2",
	                "维伦的恩泽*2",
	                "碧蓝幼龙*2",
	                "北郡牧师*2",
	                "暮光雏龙*2",
	                "龙眠教官*2",
	                "暮光守护者*2",
	                "黑翼腐蚀者*2",
	                "心灵之火*2",
	                "神圣之灵*1",
	                "龙人巫师*2",
	                "暗言术：灭*2",
	                "玛里苟斯*1",
	                "狂野炎术师*1",
	                "龙人打击者*1",
	                "神圣新星*2"],
	            hero_guldan: [
	                "灵魂之火*2",
	                "力量的代价*2",
	                "烈焰小鬼*2",
	                "麻风侏儒*2",
	                "叫嚣的中士*2",
	                "虚空行者*2",
	                "暗色炸弹*2",
	                "恐狼前锋*1",
	                "鬼灵爬行者*2",
	                "飞刀杂耍者*2",
	                "蛛魔之卵*2",
	                "小鬼首领*2",
	                "阿古斯防御者*1",
	                "强化机器人*1",
	                "小鬼爆破*2",
	                "碧蓝幼龙*1",
	                "末日守卫*2", ],
	            hero_malfurion: [
	                "激活*2",
	                "达纳苏斯豹骑士*2",
	                "野性成长*2",
	                "野蛮咆哮*2",
	                "横扫*2",
	                "星界沟通*2",
	                "自然之力*2",
	                "艾维娜*1",
	                "藏海*1",
	                "纳克萨玛斯之影*2",
	                "阿莱克丝塔萨*1",
	                "熔核巨人*2",
	                "死亡之翼*1",
	                "奥妮克希亚*1",
	                "炎魔之王拉格纳罗斯*1",
	                "砰砰博士*1",
	                "格鲁尔*1",
	                "迦顿男爵*1",
	                "索瑞森大帝*1",
	                "洛欧塞布*1",
	                "无面操纵者*1"],
	            hero_uther: [
	                "鱼人宝宝*2",
	                "鱼人袭击者*2",
	                "暗鳞先知*2",
	                "淤泥践踏者*2",
	                "鱼人猎潮者*2",
	                "蓝腮战士*2",
	                "飞刀杂耍者*2",
	                "恐狼前锋*2",
	                "寒光智者*2",
	                "火车王里诺艾*1",
	                "鱼人骑士*2",
	                "老瞎眼*1",
	                "鱼人领军*2",
	                "海巨人*2",
	                "复仇之怒*2",
	                "麻风侏儒*2"],
	            hero_thrall: [
	                "闪电箭*2",
	                "大地震击*2",
	                "坑道穴居人*2",
	                "石化武器*2",
	                "火舌图腾*2",
	                "自动漩涡打击装置*2",
	                "图腾魔像*2",
	                "法力之潮图腾*2",
	                "野性狼魂*2",
	                "雷铸战斧*2",
	                "熔岩爆裂*2",
	                "先祖知识*2",
	                "嗜血*2",
	                "动力战锤*2",
	                "吵吵机器人*2"],
	            hero_valeera: [
	                "锈水海盗*2",
	                "致命药膏*2",
	                "深渊巨蟒*2",
	                "剑刃乱舞*2",
	                "寒光智者*2",
	                "毒刃*2",
	                "影袭*2",
	                "窃贼*2",
	                "背刺*2",
	                "刀扇*2",
	                "盗墓匪贼*2",
	                "南海船工*2",
	                "低阶侍从*2",
	                "血帆袭击者*2",
	                "恐怖海盗*2"],
	            //皮肤
	            hero_medivh: [
	                "精灵弓箭手*2",
	                "石牙野猪*2",
	                "蓝腮战士*2",
	                "恐狼前锋*2",
	                "鬼灵爬行者*2",
	                "淡水鳄*2",
	                "鱼人猎潮者*2",
	                "银背族长*2",
	                "冰风雪人*2",
	                "狼骑兵*2",
	                "暴怒的狼人*2",
	                "载人收割机*2",
	                "碧蓝幼龙*2",
	                "火车王里诺艾*1",
	                "银色指挥官*2",
	                "砰砰博士*1", ],
	            hero_alleria: [
	                "精灵弓箭手*2",
	                "石牙野猪*2",
	                "蓝腮战士*2",
	                "恐狼前锋*2",
	                "鬼灵爬行者*2",
	                "淡水鳄*2",
	                "鱼人猎潮者*2",
	                "银背族长*2",
	                "冰风雪人*2",
	                "狼骑兵*2",
	                "暴怒的狼人*2",
	                "载人收割机*2",
	                "碧蓝幼龙*2",
	                "火车王里诺艾*1",
	                "银色指挥官*2",
	                "砰砰博士*1", ],
	            hero_liadrin: [
	                "力量祝福*1",
	                "护盾机器人*2",
	                "生而平等*1",
	                "齿轮光锤*1",
	                "神恩术*2",
	                "作战动员*2",
	                "奉献*2",
	                "愤怒之锤*1",
	                "真银圣剑*2",
	                "王者祝福*2",
	                "南海船工*2",
	                "叫嚣的中士*2",
	                "银色侍从*2",
	                "麻风侏儒*2",
	                "火车王里诺艾*1",
	                "飞刀杂耍者*2",
	                "铁喙猫头鹰*2",
	                "穆克拉*1", ],
	            hero_tyrande: [
	                "治疗之环*2",
	                "北郡牧师*2",
	                "肉用僵尸*2",
	                "快速治疗*1",
	                "神圣惩击*1",
	                "真言术：盾*2",
	                "狂野炎术师*2",
	                "暗言术：痛*2",
	                "苦痛侍僧*2",
	                "负伤剑圣*2",
	                "维伦的恩泽*2",
	                "暗言术：灭*2",
	                "奥金尼灵魂祭司*2",
	                "群体驱散*2",
	                "神圣新星*1",
	                "索瑞森大帝*1",
	                "迦顿男爵*1",
	                "炎魔之王拉格纳罗斯*1"],
	            hero_magni: [
	                "旋风斩*2",
	                "斩杀*2",
	                "盾牌猛击*2",
	                "严酷的监工*2",
	                "铸甲师*2",
	                "酸性沼泽软泥怪*1",
	                "猛击*2",
	                "炽炎战斧*2",
	                "盾牌格挡*2",
	                "苦痛侍僧*2",
	                "死亡之咬*2",
	                "库卡隆精英卫士*1",
	                "致死打击*1",
	                "碧蓝幼龙*1",
	                "无面*1",
	                "迦顿男爵*1",
	                "砰砰博士*1",
	                "格罗玛什·地狱咆哮*1",
	                "炎魔之王拉格纳罗斯*1",
	                "红龙*1", ],
	            /*hero_elise: [
	                "精灵弓箭手*2",
	                "石牙野猪*2",
	                "蓝腮战士*2",
	                "恐狼前锋*2",
	                "鬼灵爬行者*2",
	                "淡水鳄*2",
	                "鱼人猎潮者*2",
	                "银背族长*2",
	                "冰风雪人*2",
	                "狼骑兵*2",
	                "暴怒的狼人*2",
	                "载人收割机*2",
	                "碧蓝幼龙*2",
	                "火车王里诺艾*1",
	                "银色指挥官*2",
	                "砰砰博士*1", ],*/
	            hero_lunara: [
	                "精灵弓箭手*2",
	                "石牙野猪*2",
	                "蓝腮战士*2",
	                "恐狼前锋*2",
	                "鬼灵爬行者*2",
	                "淡水鳄*2",
	                "鱼人猎潮者*2",
	                "银背族长*2",
	                "冰风雪人*2",
	                "狼骑兵*2",
	                "暴怒的狼人*2",
	                "载人收割机*2",
	                "碧蓝幼龙*2",
	                "火车王里诺艾*1",
	                "银色指挥官*2",
	                "砰砰博士*1", ],
	            hero_nemsy: [
	                "精灵弓箭手*2",
	                "石牙野猪*2",
	                "蓝腮战士*2",
	                "恐狼前锋*2",
	                "鬼灵爬行者*2",
	                "淡水鳄*2",
	                "鱼人猎潮者*2",
	                "银背族长*2",
	                "冰风雪人*2",
	                "狼骑兵*2",
	                "暴怒的狼人*2",
	                "载人收割机*2",
	                "碧蓝幼龙*2",
	                "火车王里诺艾*1",
	                "银色指挥官*2",
	                "砰砰博士*1", ],
	            hero_thunder: [
	                "尘魔*2",
	                "坑道穴居人*2",
	                "闪电箭*2",
	                "大地震击*2",
	                "图腾魔像*2",
	                "火舌图腾*2",
	                "连环爆裂*2",
	                "雷铸战斧*2",
	                "法力之潮图腾*2",
	                "野性狼魂*2",
	                "土元素*2",
	                "风语者*2",
	                "妖术*2",
	                "嗜血*2",
	                "低阶侍从*2", ],
	            hero_maiev: [
	                "精灵弓箭手*2",
	                "石牙野猪*2",
	                "蓝腮战士*2",
	                "恐狼前锋*2",
	                "鬼灵爬行者*2",
	                "淡水鳄*2",
	                "鱼人猎潮者*2",
	                "银背族长*2",
	                "冰风雪人*2",
	                "狼骑兵*2",
	                "暴怒的狼人*2",
	                "载人收割机*2",
	                "碧蓝幼龙*2",
	                "火车王里诺艾*1",
	                "银色指挥官*2",
	                "砰砰博士*1", ],
	            //染柒
	            hero_addiction: [
	                "哥布林战士*2",
	                "蜘蛛人女王*2",
	                "美杜莎之女*1",
	                "茶话会*2",
	                "血法师萨尔诺斯*1",
	                "蛛魔之卵*2",
	                "鬼灵爬行者*2",
	                "麻风侏儒*2",
	                "蹒跚的食尸鬼*2",
	                "能量释放*2",
	                "寻宝*2",
	                "蛇发女妖*2",
	                "蔓生*2",
	                "萃毒*2",
	                "哥布林术士*2",
	                "死域召唤*2"],
	        },
	    };
	});