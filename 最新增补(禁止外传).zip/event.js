	"use strict";
	hearthstone.use(function(lib, game, ui, get, ai, _status) {
	    hearthstone.shijian = {
	        //重要事件内容
	        baseinit: function() { //基础初始化
	            hearthstone.cardPack.mode_RD = Object.keys(hearthstone.cardPack.monsterRD)
	                .map(i => hearthstone.funcs.createrd(i));
	            hearthstone.cardPack.spel_RD = [];
	            hearthstone.cardPack.trap_RD = [];
	            hearthstone.cardPack.weap_RD = [];
	            for (var i in hearthstone.loadTrans) lib.translate[i] = hearthstone.loadTrans[i];
	            for (var i in hearthstone.rdrd_card.spell) hearthstone.cardPack.spel_RD.add(i);
	            for (var i in hearthstone.rdrd_card.trap) hearthstone.cardPack.trap_RD.add(i);
	            for (var i in hearthstone.rdrd_card.weapon) hearthstone.cardPack.weap_RD.add(i);
	            lib.hearthstone = get.copy(window.hearthstone);
	            delete window.hearthstone;
	            //导入角色，技能和翻译
	            for (var i in lib.hearthstone.player) lib.element.player[i] = lib.hearthstone.player[i];
	            for (var i in lib.hearthstone.card) lib.element.card[i] = lib.hearthstone.card[i];
	            for (var i in lib.hearthstone.content) lib.element.content[i] = lib.hearthstone.content[i];
	            for (var i in lib.hearthstone.get) get[i] = lib.hearthstone.get[i];
	            //导入部分不可或缺的自定义函数
	            get.HSF("createrd"); //给所有怪兽添加描述、卡图
	            get.HSF("qwe"); //新增属性势力
	            lib.hearthstone.css_editdeck = lib.init.css(lib.assetURL + "extension/炉石普通", 'editdeck');
	            get.HSF("loadHS");
	            ui.arena.classList.add("hs_preinit");
	        },
	        preinit: function(trigger) { //设置检查
	            if (trigger.name == "gameDraw") trigger.cancel();
	            game.me.discard(game.me.getCards("hej"));
	            for (var i in lib.element.player) {
	                game.me[i] = lib.element.player[i];
	                game.me.next[i] = lib.element.player[i];
	            }
	            game.me.next.discard(game.me.next.getCards("hej"));
	            _status.hs_entergame = true;
	            if (lib.config.extension_十周年UI_enable) {
	                get.hs_alt("炉石普通：本扩展未适配十周年UI！已为您关闭十周年UI扩展，稍后重启。");
	                game.saveConfig("extension_十周年UI_enable", false);
	                game.reload();
	                event.finish();
	                return;
	            }
	            lib.config.damage_shake = false;
	            if (lib.config.layout != "nova") lib.init.layout("nova");
	            if (lib.config.player_border != "wide") {
	                lib.config.player_border = "wide";
	                ui.window.dataset.player_border = "wide";
	            }
	            if (lib.config.player_height != "short") {
	                ui.arena.dataset.player_height_nova = "short";
	                ui.arena.classList.remove("uslim_player");
	                ui.arena.classList.remove("lslim_player");
	                ui.arena.classList.remove("slim_player");
	            }
	            game.countPlayer(function(current) {
	                current.node.atk = ui.create.div(".hs_atk", current);
	                current.node.atk.hide();
	                current.uninit();
	            });
	            ui.arena.classList.add("hscss");
	            ui.arena.classList.add("hs1me");
	            ui.arena.classList.add("hs1enemy");
	            lib.hearthstone.css_common = lib.init.css(lib.assetURL + 'extension/炉石普通/', "common");
	            var css = window.decadeUI ? 'HS_decade' : 'HS';
	            lib.hearthstone.css_mode = lib.init.css(lib.assetURL + 'extension/炉石普通/', css);
	            lib.hearthstone.css_mode.mode = css;
	            if (get.HSF("cfg", ["hs_big_img"])) {
	                ui.arena.classList.add("hs_big_img");
	                _status.big_img = true;
	                lib.hearthstone.css_big_img = lib.init.css(lib.assetURL + 'extension/炉石普通/', "big_img");
	            }
	        },
	        init: function() { //游戏初始化(给怪随从卡加ai，制作相应的随从，增加排序方式，设置ai默认卡组等)
	            //<--感谢群友"三十功名尘与土"提供的自适应缩放代码
	            var scalef = () => {
	                var scale = Math.min(window.innerWidth / 1070, window.innerHeight / 596) + 0.001;
	                game.documentZoom = scale;
	                lib.config.extension_炉石普通_HS_customzoom = scale / game.deviceZoom;
	                ui.updatez();
	            }
	            if (!lib.device) window.addEventListener('resize', scalef);
	            var inter = setInterval(function() {
	                var scale = Math.min(window.innerWidth / 1070, window.innerHeight / 596) + 0.001;
	                if (game.documentZoom != scale) {
	                    scalef();
	                    clearInterval(inter);
	                }
	            }, 200);
	            //-->
	            lib.config.background_music = "music_custom";
	            lib.config.background_music_src = lib.assetURL + "extension/炉石普通/audio/bgm/pull up a chair.mp3";
	            game.playBackgroundMusic();
	            //冰属性伤害不触发弃牌
	            lib.hearthstone.drgf = lib.element.player.directgain;
	            lib.skill.icesha_skill.filter = function() {
	                return false
	            };
	            game.swapPlayer = function(player, player2) {
	                var swap2 = function(a, arr) {
	                    if (Array.isArray(arr)) arr.forEach(name => swap2(a, name));
	                    else {
	                        if (Array.isArray(a)) {
	                            a.forEach(div => swap2(div, arr));
	                        } else {
	                            if (a.classList.contains("me" + arr)) {
	                                a.classList.remove("me" + arr);
	                                a.classList.add("enemy" + arr);
	                            } else {
	                                a.classList.remove("enemy" + arr);
	                                a.classList.add("me" + arr);
	                            }
	                        }
	                    }
	                };
	                if (player2) {
	                    if (player == game.me) game.swapPlayer(player2);
	                    else if (player2 == game.me) game.swapPlayer(player);
	                } else {
	                    if (player == game.me) return;
	                    if (player.isMin()) {
	                        get.hs_alt("game.swapPlayer:不能和随从交换控制权");
	                        return;
	                    }
	                    var players = game.players;
	                    for (var i = 0; i < players.length; i++) {
	                        players[i].style.transition = 'all 0s';
	                    }
	                    game.addVideo('swapPlayer', player, get.cardsInfo(player.getCards('h')));

	                    _status.hsbo = !_status.hsbo;
	                    var num = get.hs_nm();
	                    players.forEach(p => {
	                        if (p.isMin()) {
	                            if (p.dataset.enemy == '0') p.dataset.enemy = '1';
	                            else p.dataset.enemy = '0';
	                            if (parseInt(p.dataset.position) > num) p.dataset.position = parseInt(p.dataset.position) - num + "";
	                            else p.dataset.position = parseInt(p.dataset.position) + num + "";
	                        } else {
	                            if (p == game.me) {
	                                p.dataset.position = "1";
	                            } else {
	                                p.dataset.position = "0";
	                            }
	                            p.heroskill.style.transition = 'all 0s';
	                            p.mana.style.transition = 'all 0s';
	                            if (p.data_weapon) {
	                                p.data_weapon.style.transition = 'all 0s';
	                                swap2(p.data_weapon, ["wp"]);
	                            }
	                            swap2(p.heroskill, ["heroskill"]);
	                            swap2(p.mana, ["mana"]);
	                        }
	                    });
	                    get.HSF("arrange");
	                    var c1 = lib.hearthstone.mecard;
	                    lib.hearthstone.mecard = lib.hearthstone.enemycard;
	                    lib.hearthstone.enemycard = c1;
	                    var c2 = ui.hs_enemycount.querySelector(".card");
	                    var c3 = c2 == c1 ? lib.hearthstone.mecard : lib.hearthstone.enemycard;
	                    ui.hs_enemycount.removeChild(c2);
	                    ui.hs_enemycount.appendChild(c3);
	                    player.appendChild(player.node.count);
	                    player.node.count.className = "count";
	                    ui.hs_enemycount.appendChild(game.me.node.count);
	                    game.me.node.count.className = "ec";
	                    ui.hs_medeckcontainer.style.transition = 'all 0s';
	                    ui.hs_enemydeckcontainer.style.transition = 'all 0s';
	                    ui.hs_medeckbox.style.transition = 'all 0s';
	                    ui.hs_enemydeckbox.style.transition = 'all 0s';
	                    swap2([ui.hs_medeckcontainer, ui.hs_enemydeckcontainer], "deckcontainer");
	                    swap2([ui.hs_medeckbox, ui.hs_enemydeckbox], "deckbox");
	                    swap2([game.me.heroskill.pos, player.heroskill.pos], "heroskillpos");
	                    game.me.discardPile.classList.remove("hs_me");
	                    game.me.discardPile.classList.add("hs_enemy");
	                    player.discardPile.classList.remove("hs_enemy");
	                    player.discardPile.classList.add("hs_me");
	                    if (_status.currentPhase == game.enemy) {
	                        ui.hs_endbtn.innerHTML = "回合结束";
	                        ui.hs_endbtn.classList.remove("hs_oppo");
	                    } else {
	                        ui.hs_endbtn.innerHTML = "对手回合";
	                        ui.hs_endbtn.classList.add("hs_oppo");
	                    }
	                    get.HSF("clickmana", [false]);
	                    get.HSF("arrange");

	                    game.me.node.handcards1.remove();
	                    game.me.node.handcards2.remove();
	                    game.enemy = game.me;
	                    game.me = player;
	                    ui.handcards1 = player.node.handcards1.animate('start')
	                        .fix();
	                    ui.handcards2 = player.node.handcards2.animate('start')
	                        .fix();
	                    ui.handcards1Container.appendChild(ui.handcards1);
	                    ui.handcards2Container.appendChild(ui.handcards2);

	                    var ele = document.querySelector("#handcards1>div");
	                    ele.style.transition = "all 0.5s";
	                    ele.towork = true;

	                    ui.updatehl();
	                }
	                if (game.me.isAlive()) {
	                    if (ui.auto) ui.auto.show();
	                    setTimeout(function() {
	                        for (var i = 0; i < players.length; i++) {
	                            players[i].style.transition = '';
	                            if (!players[i].isMin()) {
	                                players[i].heroskill.style.transition = '';
	                                players[i].mana.style.transition = '';
	                                if (players[i].data_weapon) players[i].data_weapon.style.transition = '';
	                            }
	                        }
	                        ui.hs_medeckcontainer.style.transition = '';
	                        ui.hs_enemydeckcontainer.style.transition = '';
	                        ui.hs_medeckbox.style.transition = '';
	                        ui.hs_enemydeckbox.style.transition = '';
	                    }, 100);
	                }
	            };
	            lib.skill.hs_autoswap = {
	                trigger: {
	                    player: "phaseBegin",
	                },
	                filter: function(event, player) {
	                    var mode = get.HSF("cfg", ["HS_duelMode"]);
	                    if (mode == "single") {
	                        if (event.player != game.me) return true;
	                    }
	                },
	                silent: true,
	                content: function() {
	                    game.swapPlayer(player);
	                    player.addTempSkill("hs_autoswap_msk");
	                },
	            };
	            lib.skill.hs_autoswap_msk = {
	                onremove: function(player) {
	                    game.swapPlayer(player.getOppo());
	                },
	            };
	            game.addGlobalSkill("hs_autoswap");
	            //不播放伤害抖动
	            lib.config.damage_shake = false;
	            //确定场地
	            ui.arena.classList.add("hs_kaichang");
	            ui.arena.classList.add("hs_kaichang2");
	            var mode = get.HSF("cfg", ["HS_duelMode"]);

	            if (mode == "normal") lib.hearthstone.game_num = 3;
	            else lib.hearthstone.game_num = 7;
	            if (get.hs_nm() == 7) ui.arena.classList.add("bigfield");
	            lib.hearthstone.hs_sczb = 653;
	            lib.hearthstone.hs_scjj = 108;
	            //拼装英雄技能
	            lib.hearthstone.base_heroskill = {};
	            for (var i in lib.hearthstone.heroskill) {
	                var obj = lib.hearthstone.heroskill[i];
	                var name = "hs_hero_legend_" + i;
	                lib.hearthstone.eval_heroskill("hs_hero_" + i, obj);
	                lib.hearthstone.eval_heroskill(name, obj);
	                lib.hearthstone.base_heroskill[name] = lib.skill[name];
	            }
	            //生成缺省的随从技能
	            //get.HSF("tl1");
	            get.HSF("tl2");
	            //根据随从卡牌制作随从
	            for (var i of lib.hearthstone.cardPack.mode_RD) {
	                var name = get.HSF("tr", [i]);
	                var info = get.info({
	                    name: i
	                });
	                if (!info) {
	                    get.hs_alt(i + "导入monster失败");
	                    lib.card[i] = {};
	                }
	                for (var j in lib.hearthstone.monster) {
	                    lib.card[i][j] = lib.hearthstone.monster[j];
	                }
	                get.HSF("setAi", [i]);
	                lib.character[name] = ["none", (info.rnature || "hs_neutral"), info.HP, [],
	                    ["minskin", 'ext:炉石普通/card/' + i + '.jpg', "des:" + lib.translate[i + "_info"]]
	                ];
	                lib.translate[name] = lib.translate[i];
	            }
	            var tempa = lib.hearthstone.cardPack.spel_RD.concat(lib.hearthstone.cardPack.trap_RD);
	            for (var i of tempa) {
	                get.HSF("setResult", [i, lib.hearthstone.cardPack.trap_RD.contains(i)]);
	            }
	            lib.sort.attendseq = function(a, b) { //按入场顺序排序
	                var seq = _status.hsAttendSeq;
	                var p1 = a.early || 0;
	                var p2 = b.early || 0;
	                if (p1 > p2) return -1;
	                else if (p1 < p2) return 1;
	                var p1 = a.later || 0;
	                var p2 = b.later || 0;
	                if (p1 > p2) return 1;
	                else if (p1 < p2) return -1;
	                if (seq.ind(a) > seq.ind(b)) return 1;
	                else return -1;
	            };
	            lib.sort.hs_duel = function(m, n) { //卡片排序
	                var a = m,
	                    b = n;
	                if (typeof a == "string") a = {
	                    name: m
	                };
	                if (typeof b == "string") b = {
	                    name: n
	                };
	                var info1 = get.info(a),
	                    info2 = get.info(b);

	                var c1 = info1.cost,
	                    c2 = info2.cost;
	                if (c1 > c2) return 1;
	                if (c1 < c2) return -1;
	                var type = ["HS_minor", "HS_spell", "HS_weapon"];
	                var subtype = ["HS_normal", "HS_effect", "HS_normalS", "HS_secret"];
	                if (type.indexOf(get.type(a)) > type.indexOf(get.type(b))) return 1;
	                if (type.indexOf(get.type(a)) < type.indexOf(get.type(b))) return -1;
	                if (subtype.indexOf(get.subtype(a)) > subtype.indexOf(get.subtype(b))) return 1;
	                if (subtype.indexOf(get.subtype(a)) < subtype.indexOf(get.subtype(b))) return -1;

	                if (info1.hs_legend && !info2.hs_legend) return 1;
	                if (!info1.hs_legend && info2.hs_legend) return -1;
	                if (info1.rnature != info2.rnature) {
	                    if (!info1.rnature || info1.rnature == "hs_neutral") return 1;
	                    else if (!info2.rnature || info2.rnature == "hs_neutral") return -1;
	                    else {
	                        if (info1.rnature > info2.rnature) return 1;
	                        if (info1.rnature < info2.rnature) return 1;
	                    }
	                }
	                if (info1.rkind != info2.rkind) {
	                    if (info1.rkind == "none") return 1;
	                    else return -1;
	                }
	                if (a.name > b.name) return 1;
	                if (a.name < b.name) return -1;
	                if (get.itemtype(a) == "card") return parseInt(a.cardid) - parseInt(b.cardid);
	                if (a > b) return 1;
	                if (a < b) return -1;
	            };
	            if (!lib.storage.hs_deck) lib.storage.hs_deck = {};
	            //以下是各决斗者的默认卡组
	            var deck = lib.hearthstone.const.dftDeck;
	            for (var i in deck) {
	                lib.storage.hs_deck[i + "_ai"] = deck[i];
	            }
	            //更改更新手牌函数，用于自动折叠手牌
	            var s = ui.updatehl.toString();
	            var ins = function(str) {
	                str = str.replace(new RegExp("112", "g"), "(ui.arena.classList.contains('hs_view')?70:(ui.arena.classList.contains('hs_exchange')?(ui.arena.classList.contains('hs_first')?144:100):Math.max(44,120-10*game.me.countCards('h'))))");
	                return str;
	            };
	            eval("ui.updatehl=function(){" + s.newFedit(ins) + "}");
	        },
	        postinit: function() { //剩余设置及ui
	            lib.hearthstone.css_func = document.createElement("style");
	            lib.hearthstone.css_func.innerHTML = get.HSF("css_func", [get.hs_nm()]);
	            document.head.appendChild(lib.hearthstone.css_func);

	            if (!_status.connectMode && get.HSF("cfg", ["HS_debug"])) ui.brawfo = ui.create.system("调试按钮", function() {
	                if (true && this.inter) {
	                    clearInterval(this.inter)
	                    delete this.inter;
	                    if (_status.customcss_e) document.head.removeChild(_status.customcss_e);
	                    delete _status.customcss_e;
	                    delete _status.customcss
	                } else {
	                    this.inter = setInterval(function() {
	                        if (lib.hearthstone.css_editdeck) lib.hearthstone.css_editdeck.href = lib.assetURL + "extension/炉石普通/editdeck.css?time=" + Math.random();
	                        if (lib.hearthstone.css_common) lib.hearthstone.css_common.href = lib.assetURL + "extension/炉石普通/common.css?time=" + Math.random();
	                        if (lib.hearthstone.css_mode) lib.hearthstone.css_mode.href = lib.assetURL + "extension/炉石普通/" + lib.hearthstone.css_mode.mode + ".css?time=" + Math.random();
	                        if (lib.hearthstone.css_big_img) lib.hearthstone.css_big_img.href = lib.assetURL + "extension/炉石普通/big_img.css?time=" + Math.random();
	                        if (_status.customcss) {
	                            if (!_status.customcss_e) {
	                                _status.customcss_e = document.createElement("style");
	                                document.head.appendChild(_status.customcss_e);
	                            }
	                            _status.customcss_e.innerHTML = _status.customcss;
	                        }
	                    }, 1000);
	                }
	            });
	            //下面的代码加上后，游戏开始编辑卡组时，点卡牌可以看详情
	            var cfd = ui.create.dialog;
	            ui.create.dialog = function() {
	                var res = cfd.apply(ui, arguments);
	                if (res && res.buttons && res.buttons.length) {
	                    res.buttons.forEach(i => i.listen(function() {
	                        get.HSF("morefocus", [this]);
	                    }));
	                }
	                return res;
	            };
	            document.onclick = function() {
	                var items = Array.from(document.querySelectorAll(".card.rdcreated"));
	                if (items && items.length) items.forEach(i => {
	                    if (!i.rd_checked) {
	                        i.listen(function() {
	                            i.rd_checked = true;
	                            get.HSF("morefocus", [this]);
	                        });
	                    }
	                });
	            };
	            get.HSF("morezone");
	        },
	        chooseCharacter: function() { //选人
	            var next = game.createEvent('chooseCharacter', false);
	            next.showConfig = true;
	            next.setContent(function() {
	                "step 0"
	                var list = get.HSA("duelist");
	                var list2 = list.filter(i => ["hs_warrior", "hs_mage", "hs_priest", "hs_hunter", "hs_corruptor"].contains(lib.character[i][1]))
	                    .map(i => i + "_PT");
	                list = list.concat(get.HSA("skin"));
	                if (get.hs_nm() == 3) list = list2;
	                event.list = list;
	                (function(e, l1, l2) {
	                    game.zhu.classList.add("bright");
	                    game.zhu.next.classList.add("bright");
	                    lib.hearthstone.upF = lib.element.player.update;
	                    lib.hearthstone.useF = lib.element.player.useCard;
	                    ui.arena.classList.add('choose-character');

	                    (l1.concat(l2))
	                        .forEach(i => {
	                        var job = lib.character[i][1];
	                        var heroskill = lib.hearthstone.base_heroskill;
	                        var tg;
	                        for (var j in heroskill) {
	                            if (heroskill[j].rnature == job) {
	                                tg = j;
	                                break;
	                            }
	                        }
	                        if (!tg) {
	                            get.hs_alt("找不到" + job + "对应的英雄技能！");
	                            return;
	                        }
	                        if (get.hs_nm() == 3) tg = tg.replace("_legend", "");
	                        lib.character[i][3] = [tg];
	                    });

	                })(event, list, list2);
	                game.me.identity = "zhu";
	                game.me.next.identity = "fan";
	                game.zhu = game.me;
	                //到此结束
	                get.HSF("Aud2", ["选英雄"]);
	                var cofg = get.HSF("cfg", ["HS_aichosen"]);
	                event.cdmode = get.HSF("cfg", ["HS_duelMode"]);
	                var tbo = event.cdmode != "brawl" && cofg == "player";
	                var p = tbo ? game.me : game.zhu;
	                var pro = tbo && game.me != game.zhu ? "请选择电脑要出场的决斗者" : "请选择要出场的决斗者";
	                var dialog = ui.create.dialog(pro, 'hidden');
	                dialog.add('0/1');
	                dialog.add([list.slice(0), 'character']);
	                dialog.open();

	                var next = p.chooseButton(dialog, true);
	                event.fu = function(button) {
	                    var sex = lib.character[button.link][0];
	                    if (["male", "female"].contains(cofg)) return cofg == sex ? 1 : -1;
	                    return Math.random();
	                };
	                next.set("ai", event.fu);
	                "step 1"
	                game.zhu.init(result.links[0]);
	                game.zhu.update();
	                game.zhu.node.hp.innerHTML = game.zhu.hp;
	                event.list.randomSort();
	                event.enemy = game.zhu.next;
	                if (event.enemy == game.me) game.enemy = game.zhu;
	                else game.enemy = event.enemy;
	                game.me.side = true;
	                game.enemy.side = false;
	                var cofg = get.HSF("cfg", ["HS_aichosen"]);
	                var tbo = event.cdmode != "brawl" && cofg == "player";
	                var p = tbo ? game.me : event.enemy;
	                var pro = tbo && event.enemy == game.enemy ? "请选择电脑要出场的决斗者" : "请选择要出场的决斗者";
	                var dialog = ui.create.dialog(pro, 'hidden');
	                dialog.add('0/1');
	                dialog.add([event.list, 'character']);
	                dialog.open();
	                var next = p.chooseButton(dialog, true);
	                next.set("ai", event.fu);
	                "step 2"
	                game.enemy.init(result.links[0]);
	                game.enemy.update();
	                game.enemy.node.hp.innerHTML = event.enemy.hp;
	                "step 3"
	                game.countPlayer(function(current) {
	                    current.hs_Hero();
	                });
	                ui.control.style.transitionDuration = '0s';
	                ui.refresh(ui.control);
	                ui.arena.classList.remove('choose-character');
	                setTimeout(function() {
	                    ui.control.style.transitionDuration = '';
	                }, 500);
	                "step 4"
	                //主玩家机制
	                _status.hsbo = Math.random() < 0.5;
	                var id1 = get.hs_id(game.me);
	                var id2 = get.hs_id(game.enemy);
	                _status.hsAttendSeq = [id1, id2];
	                if (!_status.hsbo) _status.hsAttendSeq.reverse();
	                _status.hsAttendSeq.log = {};
	                _status.hsAttendSeq.log2 = id => _status.hsAttendSeq.log[id];
	                _status.hsAttendSeq.ind = function(o) {
	                    return this.indexOf(get.hs_id(o));
	                };
	                _status.hsAttendSeq.ad = function(o) {
	                    var that = this;
	                    if (!o || o.length === 0) return;
	                    if (o.length) o.forEach(i => that.add(i));
	                    else {
	                        var id = get.hs_id(o);
	                        if (id) {
	                            that.add(id);
	                            _status.hsAttendSeq.log[id] = o;
	                        }
	                    }
	                };
	                _status.hsAttendSeq.cl = function(objs) {
	                    var that = this;
	                    if (objs) {
	                        if (objs.length) {
	                            objs.forEach(j => _status.hsAttendSeq.cl(j));
	                            return;
	                        } else {
	                            var ind = that.ind(objs);
	                            if (ind >= 0) {
	                                delete _status.hsAttendSeq.log[that[ind]];
	                                that[ind] = null;
	                            }
	                        }
	                    }
	                    var ids = game.me.sctp("field")
	                        .concat(game.dead)
	                        .reduce((x, y) => {
	                        var res = [];
	                        res.add(get.hs_id(y));
	                        if (y.buff && y.buff.length) res.addArray(y.buff.map(i => get.hs_id(i)));
	                        x = x.concat(res);
	                        return x;
	                    }, []);
	                    _status.hsAttendSeq.forEach(i => {
	                        if (null == i) _status.hsAttendSeq.remove(i);
	                        if (!ids.contains(i)) {
	                            delete _status.hsAttendSeq.log[i];
	                            _status.hsAttendSeq.remove(i);
	                        }
	                    });
	                };
	                _status.hs_dead_All = {}; //死者名单
	                _status.hs_dead_All[game.me.playerid] = [];
	                _status.hs_dead_All[game.enemy.playerid] = [];
	                _status.hs_dead = {}; //本回合死亡名单
	                _status.hs_dead[game.me.playerid] = [];
	                _status.hs_dead[game.enemy.playerid] = [];
	            });
	        },
	        brawl: function() { //随机乱斗
	            var next = game.createEvent('brawl', false);
	            next.setContent(function() {
	                "step 0"
	                var range = get.HSF("cfg", ["HS_brawl_range"]);
	                var stages = get.HSA("brawlscene")
	                    .reduce((x, y) => {
	                    if (range == "all" || range == y.type) x.add(y.name);
	                    return x;
	                }, []);
	                event.stage = stages.randomGet();
	                event.det = get.HSA("brawlscene")
	                    .filter(i => i.name == event.stage)[0];
	                game.me.chooseControl("ok", true)
	                    .set("dialog", [event.det.name, event.det.intro]);
	                "step 1"
	                if (event.det.type == "specialdeck") {
	                    var deck = event.det.deck;
	                    var build = function(p, d) {
	                        p.deckCards = [];
	                        if (d.certain) {
	                            for (var i = 0; i < d.certain[1]; i++) {
	                                p.deckCards.add(get.chscard(d.certain[0]));
	                            }
	                        }
	                        if (d.randomSpell) {
	                            for (var i = 0; i < d.randomSpell; i++) {
	                                var job = p.group;
	                                var kc = get.hskachi("HS_spell", (c, info) => info.rnature == job);
	                                p.deckCards.add(get.chscard(kc.randomGet()));
	                            }
	                        }
	                        if (d.random) {
	                            for (var i = 0; i < d.random; i++) {
	                                var job = p.group;
	                                var kc = get.hskachi("all", (c, info) => !info.rnature || info.rnature == job);
	                                p.deckCards.add(get.chscard(kc.randomGet()));
	                            }
	                        }
	                    };
	                    build(game.me, deck);
	                    build(game.enemy, deck);
	                } else if (event.det.type == "boss") {
	                    var bossname = event.det.name.slice(2);
	                    if (event.det.diy) game.enemy.classList.add("diyleader");
	                    get.HSF("hs_boss", [bossname, event.det.prepare, event.det.meprepare]);
	                }
	            });
	        },
	        deckBuild: function() { //组卡
	            var next = game.createEvent('deckBuild', false);
	            next.setContent(function() {
	                "step 0"
	                ui.arena.classList.add("builddeck");
	                var decks = get.hs_deck(game.me);
	                if (get.hs_nm() == 7) {
	                    game.me.chooseControl("决斗", "编辑卡组", true)
	                        .set("dialog", [get.translation(game.me) + "的卡组",
	                    decks[0].sort(lib.sort.hs_duel)]);
	                } else {
	                    game.me.chooseControl("决斗", true)
	                        .set("dialog", [get.translation(game.me) + "的卡组",
	                    decks[0].sort(lib.sort.hs_duel)]);
	                }
	                "step 1"
	                event.cho = result.control;
	                switch (event.cho) {
	                    case "决斗":
	                        event.goto(4);
	                        break;
	                    case "使用默认卡组":
	                        get.hs_deck(game.me);
	                        event.goto(4);
	                        break;
	                    case "编辑卡组":
	                        ui.morezone.hide();
	                        get.HSF("newdeckbuilder");
	                        break;
	                }
	                "step 2"
	                "step 3"
	                game.me.show();
	                game.enemy.show();
	                "step 4"
	                var div = ui.arena.querySelector(".dialog");
	                if (div) div.style.display = "none";
	                get.hs_deck(game.enemy);
	                ui.arena.classList.remove("builddeck");
	            });
	        },
	        XJBG: function() { //瞎xx改(专属技能，场地区域，备份当前背景，添加"查看场上"按钮，角色添加专属技能，系统写入剩下的自定义函数)
	            ui.hs_endbtn = ui.create.div(".hs_endbtn", ui.arena);
	            ui.hs_endbtn.innerHTML = "回合结束";
	            ui.hs_endbtn.listen(function() {
	                if (game.me.HSF("phaseUse")) {
	                    _status.hsbattling = false;
	                    if (_status.hs_pressatker) _status.hs_pressatker.classList.remove("hs_atkprepare");
	                    delete _status.hs_pressatker;
	                    delete _status.hs_pressdef;
	                    ui.click.cancel();
	                }
	            });
	            //定时任务
	            ui.hs_endbtn.inter = setInterval(function() {
	                if (game.me && game.me.heroskill && game.me.HSF("phaseUse")) {
	                    var func = function() {
	                        if (_status.hs_tempshq && !_status.hs_tempshq.classList.contains("selected")) {
	                            delete _status.hs_tempshq;
	                            get.HSF("clickmana", [true]);
	                        }
	                        if (game.me.HSF("canhrsk")) return false;
	                        if (game.me.countCards("h", ca => {
	                            return lib.filter.filterCard(ca);
	                        })) return false;
	                        else {
	                            if (game.me.countCards("h") > 0 && ui.arena.classList.contains("hs_view")) {
	                                if (!_status.hs_viewing && !_status.hdcsST) get.HSF("clickmana", [false]);
	                            }
	                        }
	                        if (game.me.getFellowN(fl => fl.HSF("canatk"))
	                            .length) return false;
	                        return true;
	                    }
	                    if (func()) ui.hs_endbtn.classList.add("active");
	                    else ui.hs_endbtn.classList.remove("active");
	                }
	            }, 500);
	            //创建牌库区、法力水晶、英雄技能
	            const createDeck = function(side) { //创建牌库区
	                let udeckcontainer = "hs_" + side + "deckcontainer";
	                let cdeckcontainer = "." + side + "deckcontainer";
	                let deckcontainer = ui.create.div(cdeckcontainer, ui.arena);
	                let udeckbox = "hs_" + side + "deckbox";
	                let cdeckbox = "." + side + "deckbox";
	                let udeck = "hs_" + side + "deck";
	                let u = "hs_" + side;

	                ui[udeckbox] = ui.create.div(cdeckbox, ui.arena);
	                ui.arena.insertBefore(ui[udeckbox], deckcontainer);
	                ui[udeckcontainer] = deckcontainer;
	                ui[udeck] = ui.create.player(deckcontainer, true);
	                let decklencontainer = ui.create.div(".decklencontainer", ui[udeck]);
	                ui[u] = ui.create.player(ui.arena, true);
	                ui[u].classList.add(u);
	                let bk = get.hscardback(game[side]);
	                let path = "url('" + lib.assetURL + "extension/" + bk + "')";
	                let cardx = ui.create.card(ui.special, "noclick", true);
	                cardx.style.backgroundImage = path;
	                cardx.style.backgroundSize = "100% 100%";
	                lib.hearthstone[side + "card"] = cardx;

	                ui[udeck].node.avatar.show();
	                ui[udeck].node.avatar.style.background = path;
	                var f = function() {
	                    if (ui.arena.classList.contains("hs_exchange2")) return;
	                    var that = ui.arena;
	                    if (this == ui.hs_medeckcontainer || this == ui.hs_enemydeckcontainer) that = this;
	                    else that = this.nextSibling;
	                    that.classList.add("hs_check");
	                    var count = that.querySelector(".count");
	                    count.show();
	                    if (!that.hs_check) that.hs_check = setTimeout(function() {
	                        delete that.hs_check;
	                        that.classList.remove("hs_check");
	                        count.hide();
	                    }, 3000);
	                }
	                deckcontainer.listen(f);
	                ui[udeck].hide();
	                ui[udeck].name = "牌库";
	                ui[u].style.transition = "all 0s";
	                ui[u].name = "墓地";
	                game[side].cardPile = ui[udeck];
	                game[side].discardPile = ui[u];
	            };
	            //法力水晶
	            const createMana = function(side) {
	                let camana = ".hs_mana." + side + "mana";
	                let p = game[side];
	                p.mana = ui.create.div(camana, ui.arena, "0");
	                p.mana.locked = ui.create.div(".manalk.lock", p.mana);
	                p.mana.owed = ui.create.div(".manalk.owe", p.mana);
	                p.mana.locked.hide();
	                p.mana.owed.hide();
	            };
	            //英雄技能
	            const createHeroskill = function(str) {
	                var p = game[str];
	                p.heroskill = ui.create.div(".hs_hrsk." + str + "heroskill", ui.arena);
	                p.heroskill.frontface = ui.create.div(".frontface", p.heroskill);
	                p.heroskill.frontface.zhezhao = ui.create.div(".skillzhezhao", p.heroskill.frontface);
	                p.heroskill.backface = ui.create.div(".backface", p.heroskill);
	                p.heroskill.pos = ui.create.player(ui.arena, true);
	                p.heroskill.pos.name = "移除";
	                p.heroskill.pos.classList.add(str + "heroskillpos");
	                p.heroskill.skill = lib.character[p.name][3][0];
	                p.heroskill.divcost = ui.create.div(".hs_hrskct", p.heroskill.frontface, p.HSF("hs_num") + "");
	                get.HSF("longP", [p.heroskill, function() {
	                    get.HSF("morefocus", [this]);
	                }]);
	                p.heroskill.listen(function(e) {
	                    if (!this.classList.contains("meheroskill")) return;
	                    if (game.me.HSF("phaseUse") && game.me.HSF("canhrsk")) ui.click.skill(this.skill);
	                    else if (game.me.HSF("phaseUse")) {
	                        if (game.me.heroskill.classList.contains("used")) game.me.HSFT("错误4");
	                        else if (game.me.HSF("hs_num") > game.me.HSF("mana")) game.me.HSFT("错误1");
	                        else if (lib.skill[game.me.heroskill.skill].summoneff && game.me.hs_full()) game.me.HSFT("错误2");
	                        else game.me.HSFT("错误5");
	                    }
	                    e.stopPropagation();
	                });
	                p.update();
	                p.heroskill.init = function(pp, skill) { //初始化英雄技能
	                    var dire = "heroskill",
	                        name = skill.replace("_legend", "");
	                    if (skill.indexOf("hs_leader") == 0) dire = "boss";
	                    this.frontface.style.backgroundImage = "url('" + lib.assetURL + "extension/炉石普通/image/" + dire + "/" + name + ".jpg')";
	                    var info = get.info(skill);
	                    if (info.diy) this.classList.add("hs_diyhrsk");
	                    else this.classList.remove("hs_diyhrsk");
	                    this.buff = [];
	                    this.skill = skill;
	                    this.usable = 1;
	                    this.used = 0;
	                    this.hrskai = info.hrskai || function() {
	                        return 1
	                    };
	                    this.filterTarget = info.filterT;
	                    this.randomHT = info.randomHT;
	                    this.baseCost = pp.HSF("hs_num", [skill]);
	                    this.cost = this.baseCost;
	                    this.name = get.translation(skill);
	                    this.content = info.effect;
	                };
	                p.heroskill.init(p, p.heroskill.skill);
	            };
	            for (let str of["me", "enemy"]) {
	                createDeck(str);
	                createMana(str);
	                createHeroskill(str);
	            }
	            get.HSF("checkall", ["hand", "heroskill"]);
	            //手牌区缩回原因
	            _status.hdcsST = null;
	            ui.hs_testfl = ui.create.div(".player.minskin", ui.arena);
	            ui.hs_testfl.name = "占位";
	            ui.hs_testfl.dataset.position = "d0";
	            ui.hs_testfl.num = 2;
	            ui.hs_testfl.dataset.enemy = "0";
	            ui.hs_testfl.classList.add("testfl");
	            ui.hs_surrender = ui.create.div(".surrender", ui.arena);
	            ui.hs_surrender.listen(function() {
	                var func = get.HSF("surrender");
	                if (game.me.HSF("phaseUse")) ui.click.skill("hs_surrender");
	                else {
	                    var next = game.createEvent("hs_surrender", false);
	                    next.setContent(func);
	                }
	            });
	            lib.onover.push(get.HSF("nextduel"));
	            lib.onover.push(function(bo) {
	                if (bo == true) get.HSF("Aud2", ["胜利"]);
	                else get.HSF("Aud2", ["失败"]);
	            });
	            for (var i in lib.hearthstone.const.ski) {
	                lib.skill["rdrd_" + i] = {};
	                var ar = lib.hearthstone.const.ski[i];
	                lib.translate["rdrd_" + i] = ar[0];
	                lib.translate["rdrd_" + i + "_info"] = ar[1];
	            }
	            ui.monsterzone = ui.create.div(".monsterzone", ui.arena);
	            ui.zonearena = ui.create.div(".zonearena", ui.arena);
	            ui.hs_enemycount = ui.create.div(".hs_enemycount", ui.arena);
	            ui.hs_enemycount.appendChild(lib.hearthstone.enemycard);
	            ui.hs_enemycount.appendChild(game.enemy.node.count);
	            game.enemy.node.count.className = "ec";
	            var ski = get.HSA("ski");
	            for (var i in ski) {
	                lib.skill["hshs_" + i] = {};
	                var ar = ski[i];
	                lib.translate["hshs_" + i] = ar[0];
	                lib.translate["hshs_" + i + "_info"] = ar[1];
	            }
	            var eventFs = { //事件方法
	                炸服: function(func) {
	                    if (func(this)) {
	                        get.hs_alt("炉石普通：怀疑你在炸服，游戏强制终止");
	                        get.HSF("checkwin", [this, true]);
	                        this.finish();
	                        return true;
	                    }
	                },
	            };
	            for (var i in eventFs) {
	                lib.element.event[i] = eventFs[i];
	            }
	            lib.element.content.phaseDraw = function() {
	                "step 0"
	                get.HSF("checkwin", [event]);
	                "step 1"
	                if (!(_status.brawlnophasedraw && player.name == _status.brawlboss)) {
	                    if (player.isSGS()) player.draw(2);
	                    else player.draw();
	                }
	                "step 2"
	                get.HSF("checkdeath");
	                "step 3"
	                get.HSF("checkwin", [event]);
	                "step 4"
	                if (game.me.countCards("h", ca => {
	                    return lib.filter.filterCard(ca);
	                }) && player == game.me) ui.arena.classList.add("hs_view");
	                "step 5"
	                get.HSF("think");
	                "step 6"
	            };
	            get.attitude = function(a, b) {
	                return a.side == b.side ? 10 : -10;
	            };
	            _status.hs_willbug = true;
	            var next = game.createEvent("XJBG", false);
	            next.setContent(function() {
	                "step 0"
	                if (_status.brawlcommd && _status.brawlcommd.length) {
	                    _status.brawlcommd.forEach(i => i());
	                }
	                ui.arena.hs_myturn = ui.create.div(".hs_myturn", ui.arena);
	                ui.arena.hs_myturn.rune = ui.create.div(".hs_rune", ui.arena.hs_myturn);
	                ui.arena.hs_myturn.img = ui.create.div(".hs_img", ui.arena.hs_myturn);
	                ui.arena.hs_myturn.img.text = ui.create.div(".hs_img_text", ui.arena.hs_myturn.img, "你的回合");
	                ui.arena.classList.remove("hs_preinit");
	                ui.morezone.hide();
	                ui.background.style.transition = "all 1s";
	                ui.background.style.filter = "brightness(0%)";
	                document.body.style.transition = "all 1s";
	                document.body.style.filter = "brightness(0%)";
	                ui.arena.classList.add("hs_black");
	                "step 1"
	                ui.create.div(".bright.hs_vs", ui.arena);
	                if (get.hs_nm() == 7) {
	                    var n1 = ui.create.div(".bright.hs_mefull", ui.arena);
	                    var n2 = ui.create.div(".bright.hs_enemyfull", ui.arena);
	                    game.me.appendChild(n1);
	                    game.enemy.appendChild(n2);
	                    n1.innerHTML = get.HSA("fullname")[game.me.name.split("_")[1]] || get.translation(game.me.name);
	                    n2.innerHTML = get.HSA("fullname")[game.enemy.name.split("_")[1]] || get.translation(game.enemy.name);
	                    var n1 = ui.create.div(".bright.hs_mejob", ui.arena);
	                    var n2 = ui.create.div(".bright.hs_enemyjob", ui.arena);
	                    n1.innerHTML = get.HS_trans(game.me.group);
	                    n2.innerHTML = get.HS_trans(game.enemy.group);
	                    game.me.appendChild(n1);
	                    game.enemy.appendChild(n2);
	                }
	                game.delay(2);
	                "step 2"
	                setTimeout(function() {
	                    document.body.style.filter = "brightness(100%)";
	                }, 400);
	                ui.arena.classList.remove("hs_black");
	                ui.background.style.filter = "brightness(25%)";
	                if (get.hs_nm() == 7) {
	                    ui.arena.classList.add("hs_exchange");
	                    ui.arena.classList.add("hs_exchange2");
	                }
	                "step 3"
	                "step 4"
	                if (game.me.deckCards) {
	                    ui.hs_medeck.directgain(game.me.deckCards);
	                    ui.hs_medeck.hs_sort();
	                }
	                if (game.enemy.deckCards) {
	                    ui.hs_enemydeck.directgain(game.enemy.deckCards);
	                    ui.hs_enemydeck.hs_sort();
	                }
	                delete game.me.deckCards;
	                delete game.enemy.deckCards;
	                get.HSF("checkdeck");
	                "step 5"
	                ui.hs_medeck.show();
	                ui.hs_enemydeck.show();
	                delete ui.hs_medeck.forcecount;
	                delete ui.hs_enemydeck.forcecount;
	                if (get.hs_nm() == 3) {
	                    setTimeout(function() {
	                        ui.hs_medeck.parentNode.classList.add("hs_check");
	                        ui.hs_enemydeck.parentNode.classList.add("hs_check");
	                        ui.hs_medeck.querySelector(".count")
	                            .show();
	                        ui.hs_enemydeck.querySelector(".count")
	                            .show();
	                        get.HSF("checkdeck");
	                        setTimeout(function() {
	                            ui.hs_medeck.parentNode.classList.remove("hs_check");
	                            ui.hs_enemydeck.parentNode.classList.remove("hs_check");
	                            ui.hs_medeck.querySelector(".count")
	                                .hide();
	                            ui.hs_enemydeck.querySelector(".count")
	                                .hide();
	                        }, 600);
	                    }, 600);
	                    game.delayx(3);
	                } else {
	                    if (get.HSF("cfg", ["HS_debug"])) game.delayx(2);
	                    else game.delayx(5);
	                }
	            });
	        },
	    };
	    /////////////////////////////////////////////////

	    //原debug.js

	    var funcs = { //自定义函数
	        //随机filter函数
	        randmgfil: function(p, sctp, fil, hp) { //随机伤害filter
	            sctp = sctp || "opposide";
	            fil = fil || lib.filter.all;
	            return p.sctp(sctp)
	                .filter(fl => fl.canhsdmg(hp) && fil(fl))
	                .randomGet();
	        },
	        ranrcvfil: function(p, sctp, fil, hp) { //随机治疗filter
	            sctp = sctp || "myside";
	            fil = fil || lib.filter.all;
	            return p.sctp(sctp)
	                .filter(fl => fl.isDamaged() && fil(fl))
	                .randomGet();
	        },
	        ranxmfil: function(p, sctp, fil, hp) { //随机消灭filter
	            sctp = sctp || "notmine";
	            fil = fil || lib.filter.all;
	            return p.sctp(sctp)
	                .filter(fl => fl.HSF("alive") && fil(fl))
	                .randomGet();
	        },
	        dmgrcvdh: function(evts) { //播放伤害动画
	            var next = game.createEvent("dmgrcvdh");
	            next.evts = evts.slice(0);
	            next.setContent(function() {
	                "step 0"
	                event.i = 0;
	                event.evnum = event.evts.length;
	                _status.hs_noupdate = false;
	                "step 1"
	                var cur = event.evts.filter(i => i.expo);
	                if (cur.length) {
	                    event.cur = cur[0];
	                    event.i = -1;
	                    event.evts.remove(event.cur);
	                    event.evnum--;
	                } else event.cur = event.evts[event.i];
	                "step 2"
	                var obj = {
	                    num: event.cur.num,
	                    type: event.cur.type,
	                    player: event.cur.player,
	                    source: event.nosource ? undefined : event.cur.source,
	                    nature: event.cur.nature,
	                };
	                obj.player[obj.type](obj.source, obj.num, obj.nature)
	                    .hs_dmgrcv = true;
	                "step 3"
	                //伤害抖动
	                event.cur.player.updatehsfl(event.cur.change);
	                "step 4"
	                var sc = event.cur.source;
	                if (event.cur.type == "damage" && sc && sc.hasgjz("qianxing")) sc.removegjz("qianxing");
	                "step 5"
	                if (event.cur.expo) game.delay(0.5);
	                "step 6"
	                event.i++;
	                if (event.i < event.evnum) event.goto(1);
	            });
	        },
	        hs_boss: function(name, obj, obj2) { //生成boss
	            //生成diy的boss
	            var data = get.HSA("bossinfo")[name];
	            var cha = data.base;
	            var skill = cha[3];
	            var info = data[skill];
	            var fullskill = "hs_leader_" + skill;
	            var zwname = name;
	            name = cha[0];
	            var hp = cha[2];
	            lib.character[name] = [cha[1], "hs_leader", hp, [fullskill],
	                ["des:", "hsboss", "ext:炉石普通/image/boss/" + name + ".jpg"]
	            ];
	            lib.translate[name] = zwname;
	            lib.hearthstone.eval_heroskill(fullskill, info);
	            game.enemy.init(name);
	            game.enemy.hs_Hero();
	            game.enemy.baseHP = hp;
	            _status.brawlfirst = obj.first;
	            _status.brawlcardback = obj.cardback;
	            //乱斗设置
	            _status.brawlboss = name;
	            _status.brawlcommd = [];
	            get.hs_deck(game.me);
	            var func = function(o, p) {
	                var bo = p == game.enemy;
	                if (o) {
	                    if (bo) _status.brawlnophasedraw = o.nophasedraw;
	                    if (o.deck) {
	                        p.deckCards = [];
	                        o.deck.forEach(c => {
	                            p.deckCards.add(get.chscard(c));
	                        });
	                    }
	                    if (o.summon) {
	                        o.summon.forEach(i => get.HSF("作弊", ["特召", i]));
	                    }
	                    if (o.equip) {
	                        _status.brawlcommd.push(function() {
	                            p.hs_weapon2(o.equip);
	                        });
	                    }
	                }
	            };
	            func(obj, game.enemy);
	            func(obj2, game.me);
	        },
	        info: function(card, info) { //获取效果
	            if (get.itemtype(card) == "player") return card.linkCard[0].HSF("info");
	            else if (card.swt) return card.linkCard[0].HSF("info");
	            if (get.type(card) == "HS_spell") {
	                if (info) return get.info(card);
	                else return get.info(card)
	                    .delayeffect;
	            } else if (get.type(card) == "HS_minor") return lib.skill[card.name.slice(0, -8)];
	            else if (get.type(card) == "HS_weapon") return get.info(card)
	                .weaponeffect;
	        },
	        longP: function(div, func) { //手机端长按，电脑端右键
	            if (lib.device) lib.setLongPress(div, func);
	            else div.addEventListener("mouseover", function(e) {
	                func.call(this);
	            });
	        },
	        recheck: function(o) { //判断描述是否有“如果” recheck:"filter",
	            var c = o;
	            if (get.itemtype(o) == "player") c = o.linkCard[0];
	            if (get.translation(c.name) == "穿刺者戈莫克") return false;
	            var str = get.translation(c.name + "_info");
	            return str.contains("如果");
	        },
	        uptris: function(p) { //更新扳机
	            if (!p.triggers) {
	                get.hs_alt("uptris", p.name, "的triggers不存在从！");
	                return;
	            }
	            for (var i in p.triggers) {
	                var tri = p.triggers[i];
	                if (["battleRoal", "jili", "deathFL", "discarded"].contains(i)) {
	                    tri.cur = p;
	                } else {
	                    tri.forEach(m => {
	                        m.cur = p;
	                    });
	                }
	            }
	        },
	        cfg: function(name) { //获取扩展设置
	            return lib.config["extension_炉石普通_" + name];
	        },
	        clickmana: function(bo) { //点自己的法力水晶
	            if (typeof bo == "boolean" && bo == ui.arena.classList.contains("hs_view")) return
	            _status.hdcsST = "click";
	            get.HSF("hs_stopview");
	            //if (!game.me.HSF("phaseUse")) return;
	            var ele = document.querySelector("#handcards1>div");
	            var num = game.me.countCards('h');
	            if (num == 0) return;
	            if (!ele.towork) return;
	            if (ui.arena.classList.contains("hs_view")) delete _status.hs_viewing;
	            ui.arena.classList.toggle("hs_view");
	            get.HSF("checkhand");
	        },
	        eee: function(n, m) { //调用事件
	            var next = game.createEvent(n, false);
	            for (var i in m) {
	                next.set(i, m[i]);
	            }
	            next.setContent(n);
	            return next;
	        },
	        first: function() { //决定先后手
	            var firstsecond = get.HSF("cfg", ["HS_first"]);
	            if (_status.brawlfirst || firstsecond == "second" || firstsecond == "random" && Math.random() > 0.5) {
	                game.me.identity = "fan";
	                game.enemy.identity = "zhu";
	                game.zhu = game.enemy;
	            }
	            _status.hs_first = game.zhu;
	            if (_status.hs_first == game.me) setTimeout(function() {
	                ui.arena.classList.add("hs_first");
	                get.HSF("checkhand");
	            }, 1000);
	            return game.zhu;
	        },
	        newdeckbuilder: function() {
	            game.pause();
	            ui.arena.classList.remove('menupaused');
	            var win = ui.create.div(".hs_duel");
	            var tx = ui.create.div(".hs_bd_tx", win);
	            tx.style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/" + game.me.name + ".jpg)";
	            var kzname = document.createElement("input");
	            kzname.type = "text";
	            kzname.placeholder = "默认卡组";
	            if (lib.storage.hs_deckname && lib.storage.hs_deckname[game.me.name]) kzname.value = lib.storage.hs_deckname[game.me.name];
	            tx.appendChild(kzname);
	            var deckarea = ui.create.div(".hs_bd_dk", win);
	            var confirm = ui.create.div(".hs_bd_cf", win);
	            var ok = ui.create.div(".hs_bd_ok", confirm, "完成");
	            var ct = ui.create.div(".hs_bd_ct", confirm, "30/30");
	            _status.deckcount = 0;

	            var addCardbar = function(name, count) { //加卡进卡组
	                var cardbar = ui.create.div(".barcard", deckarea);
	                cardbar.style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/card/" + name + ".jpg)";
	                cardbar.style.top = _status.deckcount * 28 + "px";
	                cardbar.style.width = "100%";
	                cardbar.style.height = "28px";
	                cardbar.ccount = _status.deckcount;
	                cardbar.name = name;
	                cardbar.innerHTML = get.translation(name);
	                var bo = lib.card[name].hs_legend;
	                if (bo) cardbar.classList.add("hs_legend");
	                cardbar.count = parseInt(count);
	                ui.create.div(".count", cardbar, bo ? "★" : count);
	                ui.create.div(".cost", cardbar, "" + lib.card[name].cost);
	                _status.deckcount++;
	                cardbar.listen(function() {
	                    if (this.count == 1) deckarea.removeChild(this);
	                    get.HSV()
	                        .hsdeckfs.remove(this.name);
	                });
	                return cardbar;
	            };
	            get.HSV()
	                .hsdeck = []; //当前数据卡组
	            get.HSV()
	                .hsdeckfs = { //数据卡组核心算法
	                calcTitle: function() { //更新卡组数量
	                    var sourcedeck = get.HSV()
	                        .hsdeck;
	                    var num = sourcedeck.reduce((x, y) => x + y.num, 0);
	                    ct.innerHTML = num + "/30";
	                    if (num == 30) ok.classList.remove("disabled");
	                    else ok.classList.add("disabled");
	                    return num;
	                },
	                add: function(name) { //加卡
	                    if (get.HSV()
	                        .hsdeckfs.calcTitle() == 30) return;
	                    var data = get.HSV()
	                        .hsdeckfs.find(name);
	                    var bo = lib.card[name].hs_legend;
	                    if (data && bo) return;
	                    if (data) data.num = 2;
	                    else {
	                        addCardbar(name, 1);
	                        get.HSV()
	                            .hsdeck.push({
	                            name: name,
	                            num: 1,
	                        });
	                    }
	                    get.HSV()
	                        .hsdeckfs.update();
	                    setTimeout(function() {
	                        if (get.HSV()
	                            .hsdeckfs.find(name)) {
	                            var ele = Array.from(deckarea.childNodes)
	                                .filter(i => i.name == name)[0];
	                            if (ele) ele.animate("active", 1500);
	                        }
	                    }, 500);
	                },
	                remove: function(name) { //减卡
	                    var data = get.HSV()
	                        .hsdeckfs.find(name);
	                    if (data.num == 1) {
	                        get.HSV()
	                            .hsdeck.remove(data);
	                        _status.deckcount--;
	                    } else data.num = 1;
	                    get.HSV()
	                        .hsdeckfs.update();
	                },
	                find: function(name) { //获取数据卡组中name的数据
	                    return get.HSV()
	                        .hsdeck.filter(function(c) {
	                        return c.name == name
	                    })[0];
	                },
	                update: function() { //更新卡组顺序
	                    var deckunits = deckarea.querySelectorAll(".barcard");
	                    var deck4 = get.HSV()
	                        .hsdeck.slice(0)
	                        .sort(lib.sort.hs_duel);
	                    for (var i = 0; i < deckunits.length; i++) {
	                        var name = deck4[i].name,
	                            num = deck4[i].num;
	                        deckunits[i].style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/card/" + name + ".jpg)";
	                        deckunits[i].style.top = i * 28 + "px";
	                        deckunits[i].ccount = i;
	                        deckunits[i].name = name;
	                        deckunits[i].count = num;
	                        var bo = lib.card[name].hs_legend;
	                        if (bo) deckunits[i].classList.add("hs_legend");
	                        else deckunits[i].classList.remove("hs_legend");
	                        deckunits[i].querySelector(".count")
	                            .innerHTML = bo ? "★" : num;
	                        deckunits[i].querySelector(".cost")
	                            .innerHTML = lib.card[name].cost;
	                        deckunits[i].childNodes[0].replaceData(0, 10, get.translation(name));
	                    }
	                    get.HSV()
	                        .hsdeckfs.calcTitle();
	                },
	            };

	            var deck = lib.storage.hs_deck[game.me.name] || lib.storage.hs_deck[game.me.name + "_ai"];
	            for (var i = 0; i < deck.length; i++) {
	                var piece = deck[i];
	                var plit = piece.split("*");
	                var tname = get.HSF("getEN", [plit[0]]);
	                addCardbar(tname, plit[1]);
	                get.HSV()
	                    .hsdeck.push({
	                    name: tname,
	                    num: parseInt(plit[1]),
	                });
	            }

	            var job = game.me.group;
	            var jobcards = get.hskachi("all", (ca, info) => info.rnature == job);
	            var neutral = get.hskachi("all", (ca, info) => !info.rnature);
	            var token = get.hskachi("all", (ca, info) => (!info.rnature || info.rnature == "hs_neutral" || info.rnature == job) && (info.hs_tokened || info.hs_token), true);
	            var cardboard = ui.create.div(".hs_bd_bd", win);
	            for (var i = 0; i < 8; i++) {
	                var bg = ui.create.div(".bg", cardboard);
	                bg.click = function() {
	                    var that = this;
	                    if (_status.isview) {
	                        _status.isview.classList.remove("view");
	                        var t = _status.isview;
	                        setTimeout(function() {
	                            t.classList.remove("active");
	                        }, 500);
	                    }
	                    if (_status.isview != this) {
	                        this.classList.toggle("view");
	                        this.classList.add("active");
	                        _status.isview = this;
	                        if (get.type(this) == "HS_minor") get.HSF("Aud", [this, "play"]);
	                        if (get.subtype(this) != "HS_normal" && get.HSF("cfg", ["HS_debug"])) { //调试弹窗
	                            if (get.subtype(this) == "HS_effect") get.hs_alt(get.stringify(lib.skill[this.name.slice(0, this.name.indexOf("_monster"))]));
	                            else get.hs_alt(get.stringify(lib.card[this.name]));
	                        }
	                    } else {
	                        delete _status.isview;
	                        setTimeout(function() {
	                            that.classList.remove("active");
	                        }, 500);
	                    }
	                };
	                bg.listen(bg.click);
	                if (jobcards[i]) {
	                    var j = jobcards[i];
	                    bg.name = j;
	                    bg.style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/card/" + j + ".jpg)";
	                } else bg.style.display = "none";
	            }
	            var btnfront = ui.create.div(".btnfront.hidden", cardboard, "加入");
	            btnfront.listen(function() {
	                if (_status.isview) get.HSV()
	                    .hsdeckfs.add(_status.isview.name);
	            });
	            cardboard.enter = btnfront;
	            _status.isviewit = setInterval(function() {
	                if (_status.isview) {
	                    var name = _status.isview.name;
	                    var data = get.HSV()
	                        .hsdeckfs.find(name);
	                    var bo = lib.card[name].hs_legend;
	                    var bo2 = lib.card[name].hs_tokened || lib.card[name].hs_token;
	                    if (!bo2 && get.HSV()
	                        .hsdeckfs.calcTitle() < 30 && (!data || !bo && data.num == 1)) cardboard.enter.show();
	                    else cardboard.enter.hide();
	                } else cardboard.enter.hide();
	            }, 500);
	            var na = get.HS_trans(job);
	            na = na.length > 3 ? na.slice(0, 2) : na;
	            var kbtt = ui.create.div(".hs_bd_tt", win, na);
	            var idx = ui.create.div(".hs_bd_idx", win, "第1页");
	            var jobtn = ui.create.div(".hs_bd_jobtn.active", win);
	            jobtn.style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/image/nature/" + job + ".png)";
	            var neubtn = ui.create.div(".hs_bd_neubtn", win);
	            var tokbtn = ui.create.div(".hs_bd_tokbtn", win);
	            tokbtn.style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/image/nature/" + job + ".png)";
	            var leftfy = ui.create.div(".leftfy", win);
	            var rightfy = ui.create.div(".rightfy", win);
	            var updatefy = function() { //更新翻页按钮
	                var set = _status.hs_bgset;
	                var ind = _status.hs_index;
	                var total = Math.ceil(set.length / 8);
	                if (ind == 0) leftfy.hide();
	                else leftfy.show();
	                if (ind + 1 == total) rightfy.hide();
	                else rightfy.show();
	            };
	            var updatecards = function() { //更新收藏集
	                var cur = Array.from(cardboard.querySelectorAll(".bg"));
	                var set = _status.hs_bgset;
	                var ind = _status.hs_index;
	                if (_status.hs_bgset == jobcards) kbtt.innerHTML = na;
	                else if (_status.hs_bgset == token) kbtt.innerHTML = "衍生卡";
	                else kbtt.innerHTML = "中立";
	                idx.innerHTML = "第" + (ind + 1) + "页";
	                if (_status.isview) {
	                    var f = _status.isview;
	                    _status.isview.classList.remove("view");
	                    setTimeout(function() {
	                        f.classList.remove("active");
	                    }, 500)
	                    delete _status.isview;
	                }
	                for (var i = 0; i < 8; i++) {
	                    if (set[ind * 8 + i]) {
	                        var c = set[ind * 8 + i];
	                        cur[i].style.display = "";
	                        cur[i].name = c;
	                        cur[i].style.backgroundImage = "url(" + lib.assetURL + "extension/炉石普通/card/" + c + ".jpg)";
	                    } else cur[i].style.display = "none";
	                }
	            };
	            var manas = ui.create.div(".manabar", win);
	            for (var i = 0; i < 8; i++) {
	                var mana = ui.create.div(".mana", manas, "" + i);
	                mana.num = i;
	                mana.listen(function() {
	                    if (manas.searching) return;
	                    manas.searching = true;
	                    var num = this.num;
	                    var set = _status.hs_bgset;
	                    var ind = set.findIndex(n => {
	                        var c = lib.card[n].cost;
	                        if (num == 7) return c >= 7;
	                        else return c == num
	                    });
	                    if (ind == -1) {
	                        if (num != 7) get.hs_alt("抱歉，找不到费用为", num, "的卡牌");
	                        else get.hs_alt("抱歉，找不到费用为7以上的卡牌");
	                        delete manas.searching;
	                        return;
	                    } else {
	                        var total = Math.ceil((ind + 1) / 8);
	                        _status.hs_index = total - 1;
	                        updatecards();
	                        updatefy();
	                        setTimeout(function() {
	                            delete manas.searching;
	                            var ele = Array.from(cardboard.querySelectorAll(".bg"))
	                                .filter(e => e.name == set[ind])[0];
	                            ele.click();
	                        }, 500);
	                    }
	                });
	            }
	            leftfy.listen(function() {
	                _status.hs_index--;
	                updatecards();
	                updatefy();
	            });
	            rightfy.listen(function() {
	                _status.hs_index++;
	                updatecards();
	                updatefy();
	            });
	            jobtn.listen(function() {
	                if (jobtn.classList.contains("active")) return;
	                jobtn.classList.add("active");
	                neubtn.classList.remove("active");
	                tokbtn.classList.remove("active");
	                _status.hs_bgset = jobcards;
	                _status.hs_index = 0;
	                updatecards();
	                updatefy();
	            });
	            neubtn.listen(function() {
	                if (neubtn.classList.contains("active")) return;
	                neubtn.classList.add("active");
	                jobtn.classList.remove("active");
	                tokbtn.classList.remove("active");
	                _status.hs_bgset = neutral;
	                _status.hs_index = 0;
	                updatecards();
	                updatefy();
	            });
	            tokbtn.listen(function() {
	                if (tokbtn.classList.contains("active")) return;
	                tokbtn.classList.add("active");
	                jobtn.classList.remove("active");
	                neubtn.classList.remove("active");
	                _status.hs_bgset = token;
	                _status.hs_index = 0;
	                updatecards();
	                updatefy();
	            });
	            _status.hs_bgset = jobcards; //当前子集为职业卡
	            _status.hs_index = 0;
	            updatefy();
	            ok.listen(function() {
	                if (this.classList.contains("disabled")) return;
	                var deck = get.HSV()
	                    .hsdeck,
	                    newdeck = [];
	                for (var i = 0; i < deck.length; i++) {
	                    newdeck.push(get.translation(deck[i].name) + "*" + deck[i].num);
	                }
	                get.HSF("saveDeck", [game.me.name, newdeck]);
	                get.hs_deck(game.me);
	                var ndiv = tx.querySelector("input");
	                if (ndiv.value) {
	                    if (!lib.storage.hs_deckname) lib.storage.hs_deckname = {};
	                    lib.storage.hs_deckname[game.me.name] = ndiv.value;
	                    game.save("hs_deckname", lib.storage.hs_deckname);
	                }
	                win.style.opacity = "0";
	                setTimeout(function() {
	                    if (win.parentNode == ui.window) ui.window.removeChild(win);
	                }, 500);
	                game.resume();
	            });
	            ui.window.appendChild(win);
	            get.HSV()
	                .hsdeckfs.update();
	        },
	        think: function() { //ai思考
	            _status.hdcsST = null;
	            if (_status.event.isMine()) return;
	            var cfg = get.HSF("cfg", ["HS_think"]);
	            var map = {
	                "fastest": 0.1,
	                "fast": 0.5,
	                "medium": 1,
	                "long": 2,
	                "slow": 3
	            };
	            game.delay(map[cfg] || 2);
	        },
	        xvlie: function(name, map, empty) { //创建序列
	            var next = game.createEvent(name, false);
	            get.HSF("hs_stopview");
	            _status.hs_xvlie = {
	                name: name,
	                phase: undefined,
	                loop: 0,
	            };
	            if (map) {
	                for (var i in map) next[i] = map[i];
	            }
	            get.HSF("checkwin", [next]);
	            if (empty) next.setContent("emptyHSevent");
	            return next;
	        },
	        repeat: function(item, time) { //制造重复数组
	            time = time || 1;
	            time = Math.max(1, time);
	            return new Array(time)
	                .fill(item);
	        },
	        countvelen: function(p) { //计算维伦（可能会被优化）
	            var num = 0;
	            num = p.countFellow(fl => fl.hasAuras2("velen"));
	            return Math.pow(2, num);
	        },
	        canhrsk: function(p) { //现在是否能发动英雄技能
	            if (_status.currentPhase != p || !_status.event) return false;
	            if (_status.hsbattling) return false;
	            var skill = p.heroskill.skill;
	            p.presshrskbt = true;
	            var info = lib.skill[skill];
	            var bo = info && !info.filter(_status.event, p);
	            p.presshrskbt = false;
	            if (bo) return false;
	            return true;
	        },
	        arrange: function(just) { //更新随从邻位
	            game.me.next = game.enemy;
	            game.enemy.next = game.me;
	            var mns = get.HSF("minors");
	            var dds = Array.from(ui.arena.querySelectorAll(".player.minskin.wywy"));
	            var pls = mns.addArray(dds); //场上所有随从和即将亡语随从
	            if (pls.length == 0) return;
	            var ff = function(mes, ld) {
	                if (mes.length) {
	                    var m = ld.countFellow();
	                    var bonus = ld == game.me ? 0 : get.hs_nm();
	                    var ao = mes.filter(i => i.classList.contains("wywy"));
	                    var b = ao.length > 0;
	                    if (b && (just || mes.length != m)) { //如果有死亡的随从
	                        var apos = function(a, b) { //按position重新排
	                            var p1, p2;
	                            p1 = a.dataset.position.indexOf("d") < 0 ? parseInt(a.dataset.position) : parseInt(a.dataset.position.split("_")[1]);
	                            p2 = b.dataset.position.indexOf("d") < 0 ? parseInt(a.dataset.position) : parseInt(a.dataset.position.split("_")[1]);
	                            if (p1 > p2) return 1;
	                            if (p1 < p2) return -1;
	                        };
	                        var bpos = function(a, b) { //按truepos排
	                            if (a.truepos > b.truepos) return 1;
	                            if (a.truepos < b.truepos) return -1;
	                        };
	                        if (mes.length == m) { //如果死亡随从仍算场上的随从
	                            mes.sort(apos);
	                            var cur = m + 1 + bonus;
	                            var obj = mes[mes.length - 1];
	                            while (obj != null) {
	                                if (obj.classList.contains("wywy")) cur -= 0.1;
	                                else cur = Math.ceil(cur - 1);
	                                obj.truepos = cur;
	                                obj = obj.leftseat;
	                            }
	                        } else { //死亡随从已被自动补位
	                            ld.countFellow(fl => {
	                                fl.truepos = parseInt(fl.dataset.position);
	                            });
	                            mes.sort(bpos);
	                            mes.forEach((i, j) => {
	                                i.leftseat = mes[j - 1] || null;
	                                i.rightseat = mes[j + 1] || null;
	                            });
	                        }
	                    } else { //没死亡随从就按position计算相邻
	                        mes.sort(lib.sort.position);
	                        var bo = _status.hs_fldragging;
	                        var num = bo ? ui.hs_testfl.num : 16;
	                        mes.forEach((i, j) => {
	                            var rp = 2 + j + bonus;
	                            if (bo && i.getLeader() == game.me && rp >= num) {
	                                i.dataset.position = rp + 1 + "";
	                            } else i.dataset.position = rp + "";
	                            i.leftseat = mes[j - 1] || null;
	                            i.rightseat = mes[j + 1] || null;
	                        });
	                    }
	                }
	            };
	            ff(pls.filter(i => i.dataset.enemy == "0"), game.me);
	            ff(pls.filter(i => i.dataset.enemy == "1"), game.enemy);
	        },
	        //重要函数
	        strfil: function(mm) {
	            if (typeof mm == "string") {
	                var arr = mm.split(",");
	                if (arr.length == 1) {
	                    var f = get.HSA("funcs")[arr[0]];
	                    if (f) mm = f;
	                    else get.hs_alt("addtriggerbuff:", item.filter);
	                } else {
	                    var fs = arr.map(i => get.HSA("funcs")[i]);
	                    var ff = function(e, p, f) {
	                        return ff.fs.every(i => i(e, p, f));
	                    };
	                    ff.fs = fs;
	                    mm = ff;
	                }
	            }
	            return mm;
	        },
	        tl2: function() { //随从代码2重简化
	            var bjreg = get.HSA("fzms");
	            var reg = function(str, g) { //正则兼容
	                return new RegExp(str, g)
	            };
	            var near = function(str, regexp) { //是否描述接近
	                var rr = reg(regexp);
	                if (str.like(rr)) return str.match(rr);
	                else return false;
	            };
	            var mth = function(str, regexp) { //匹配内容
	                return str.match(reg(regexp));
	            };
	            for (var cname in lib.hearthstone.cardPack.monsterRD) {
	                var rname = get.HSF("createrd", [cname]); //生成全名
	                var name = get.HSF("tr", [rname]); //生成效果名
	                var card = lib.hearthstone.cardPack.monsterRD[cname];
	                if (card[3][0] != "HS_effect") continue;
	                var ms = card[2]; //卡牌描述
	                lib.skill[name] = lib.skill[name] || {};
	                var obj = lib.skill[name]; //卡牌效果代码
	                var tz = card[4]; //卡牌标签
	                var labed = false; //已根据卡牌标签生成代码
	                if (tz && tz.eachsome(m => {
	                    if (m == "rareEff") { //稀有效果
	                        obj.active = function(p, c) {
	                            var that = this;
	                            if (that.battleRoal) {
	                                if (that.battleRoal.BRfilter && !that.battleRoal.BRfilter(null, p)) return false;
	                                if (that.battleRoal.filter) {
	                                    var nf = get.HSF("strfil", [that.battleRoal.filter]);
	                                    that.battleRoal.filter = nf;
	                                    if (!nf(p, c)) return false;
	                                }
	                                if (that.battleRoal.filterTarget && !p.sctp("all", t => that.battleRoal.filterTarget(null, p, t))) return false;
	                                if (that.battleRoal.randomRT && !that.battleRoal.randomRT(p)) return false;
	                                return true;
	                            } else return false;
	                        };
	                    } else if (m == "lianji") { //连击
	                        obj.active = function(p, c) {
	                            return p.hs_state.useCard > 0;
	                        };
	                        obj.lianjiactive = true;
	                    } else if (m.contains(":")) { //复杂点的标签
	                        var ax = m.indexOf(":");
	                        var key = m.slice(0, ax),
	                            val = m.slice(ax + 1);
	                        if (key == "anm") obj.anm = val;
	                        else if (key == "skillgh") { //光环标签
	                            if (!obj.skillgh) obj.skillgh = {};
	                            obj.skillgh[val] = true;
	                            return true;
	                        } else if (key == "guimu") { //结束阶段受伤召怪
	                            obj.ending = {
	                                self: true,
	                                recheck: "满场",
	                            };
	                            var pre = ["event.fellow.hs_dmgrcv('damage',1,event.fellow);", "event.fellow.SSfellow('" + val + "');"];
	                            obj.ending.effect = get.hsrfunc(pre);
	                            return true;
	                        } else if (bjreg[key] || get.HSA("triggers")
	                            .contains(key)) {
	                            var rkey = key;
	                            key = bjreg[key] ? bjreg[key][1] : key;
	                            var bq = rkey == key;
	                            if (!obj[key]) obj[key] = {};
	                            if (bjreg[rkey]) {
	                                for (var xx in bjreg[rkey][2]) {
	                                    obj[key][xx] = bjreg[rkey][2][xx];
	                                }
	                            }
	                            if (mth(val, "^rangain>")) { //随机置入手牌
	                                var con = val.slice(8);
	                                var gnum = parseInt(con[0]) || 1;
	                                if (gnum > 1) con = con.slice(1);
	                                var sgnum = gnum == 1 ? "()" : "s(" + gnum + ")";
	                                var pre = "var f=get.hsflt('" + con + "');player.hs_gain(get.hskachi('all',f).randomGet" + sgnum + ");";
	                                if (con == "法术") pre = "player.hs_gain(get.hskachi('HS_spell').randomGet" + sgnum + ");";
	                                obj[key].effect = get.strfunc("", pre);
	                            } else if (mth(val, "^gain>")) { //置入手牌
	                                var con = val.slice(5);
	                                var pre = "player.hs_gain(" + con + ");";
	                                obj[key].effect = get.strfunc("", pre);
	                            } else if (mth(val, "weapon>")) { //装备武器
	                                var con = val.slice(7);
	                                var pre = "player.hs_weapon(" + con + ");";
	                                obj[key].effect = get.strfunc("", pre);
	                            } else if (mth(val, "aoercv>")) { //群体回复
	                                var con = val.slice(7);
	                                var pre = "player.hs_dmgrcvaoe('recover',event.fellow," + con + ");";
	                                obj[key].effect = get.strfunc("", pre);
	                            } else if (mth(val, "buff>")) { //添加多种buff
	                                var arr = [],
	                                    rg = "mns";
	                                if (mth(val, "^fltbuff>")) {
	                                    /*
	                                    battleRoal:fltbuff>mine_,wildbeast：22
	                                    */
	                                    arr = val.slice(8)
	                                        .split("：");
	                                    rg = arr[0].split(",");
	                                    arr = arr[1].split(",");
	                                    arr = get.hsbuff(arr);
	                                    if (key == "battleRoal") obj[key].filterTarget = get.strfunc("c,p,t", "return p.sctp('" + rg[0] + "',t)&&t.rkind=='" + rg[1] + "';");
	                                    else obj[key].randomRT = get.strfunc("p", "return p.sctp('" + rg[0] + "').filter(t=>t.rkind=='" + rg[1] + "').randomGet()");
	                                    obj[key].aifamily = arr.hsai;
	                                    obj[key].effect = get.hsrfunc(arr);
	                                } else {
	                                    if (mth(val, "^buff>")) {
	                                        arr = val.slice(5)
	                                            .split(",");
	                                    } else if (mth(val, "^.{2}buff>")) {
	                                        rg = mth(val, "^mebuff>") ? "mine" : "notmine";
	                                        arr = val.slice(7)
	                                            .split(",");
	                                    } else {
	                                        rg = val.split("buff>")[0];
	                                        arr = val.slice(rg.length + 5)
	                                            .split(",");
	                                    }
	                                    if (!rg.contains("'")) rg = "'" + rg + "'";
	                                    if (key == "battleRoal") obj[key].filterTarget = get.strfunc("c,p,t", "return p.sctp(" + rg + ", t)");
	                                    else obj[key].randomRT = get.strfunc("p,evt,f", "return f.sctp(" + rg + ").randomGet()");
	                                    arr = get.hsbuff(arr);
	                                    obj[key].aifamily = arr.hsai;
	                                    obj[key].effect = get.hsrfunc(arr);
	                                }
	                            } else { //召唤
	                                if ("[]".every(i => !val.contains(i))) val = "'" + val + "'";
	                                if (bq) {
	                                    if (["beginning", "ending", "useCard"].contains(key)) obj[key].self = true;
	                                    if (n == "useCard") obj[key].notlink = true;
	                                    if (["hsdmg", "hs_rcv"].contains(key)) obj[key].fl = true;
	                                }
	                                var pre = "event.fellow.SSfellow(" + val + ",null," + (obj.anm ? "'" + obj.anm + "'" : undefined) + ");";
	                                obj[key].effect = get.strfunc("", pre);
	                                if (!val.contains(",true")) obj[key].recheck = "满场";
	                            }
	                            return true;
	                        }
	                    }
	                })) labed = true;
	                if (tz && tz.contains("i")) continue;
	                //完整描述(典型效果)
	                var mxs = ["战吼：在本回合中，使一个随从获得+2攻击力。",
	                    "在你的回合开始时，你有50%的几率额外抽一张牌。"];
	                var mxs2 = ["战吼：造成.点伤害，随机分配到所有其他角色身上。"];
	                if (mxs.some((t, i) => { //固定描述
	                    var str = ms;
	                    if (str.like(t)) {
	                        if (i == 0) {
	                            obj.prompt = str;
	                            obj.battleRoal = {
	                                filterTarget: function(card, player, target) {
	                                    return target.isMin();
	                                },
	                                effect: get.strfunc("", "target.addvaluebuff(2,1);"),
	                                aifamily: "atk",
	                            };
	                        }
	                        if (i == 1) {
	                            obj.beginning = {
	                                self: true,
	                                half: true,
	                                effect: function() {
	                                    player.hs_drawDeck();
	                                },
	                            };
	                        }
	                        return true;
	                    }
	                })) continue;
	                else if (mxs2.some((t, i) => { //可以有参数
	                    var str = ms;
	                    if (str.like(t)) {
	                        if (i == 0) {
	                            var num = parseInt(mth(str, "(?<=造成).(?=点伤害)"));
	                            obj.battleRoal = get.hsrfunc("event.fellow.hs_Missiles(" + num + ", false, 'all_');");
	                        };
	                        return true;
	                    }
	                })) continue;
	                else { //多段效果叠加
	                    var effects = { //固定效果代码
	                        draw: function() {
	                            player.hs_drawDeck()
	                        },
	                    };
	                    var regs = {
	                        //常见描述（完整）
	                        jn: "激怒：[\+1-9]{2}攻击力",
	                        dm: "战吼：造成.点伤害",
	                        cv: "战吼：恢复.点生命值",
	                        qp: "战吼：随机弃.张牌",
	                        sgj: "亡语：随机召唤一个法力值消耗为（.）的随从",
	                        fq: "法术伤害[\+1-9]{2}",
	                        //常见战吼或亡语
	                        gn: "将一张.{1,10}置入你的手牌",
	                        rcv: "为.{2}英雄恢复.点生命值",
	                        lava: "对所有.{2,4}造成.点伤害",
	                        sj: "对.{2}英雄造成.点伤害",
	                        rsh: "随机对一个敌人造成.点伤害",
	                        rsh2: "随机对一个敌方随从造成.点伤害",
	                        buff: "获得\+.*\/\+.*",
	                        buff1: "获得\\+.攻击力",
	                        buff2: "获得\\+.生命值",
	                        askl: "使你的对手获得一个法力水晶",
	                        emws: "摧毁你的一个法力水晶",
	                    };
	                    if (ms.slice(0, 5) == "无法攻击。") { //无法攻击状态
	                        obj.noattack = true;
	                        ms = ms.slice(5);
	                    }
	                    var arr = ms.split(new RegExp("，|。")); //描述根据逗号分割
	                    for (var i = 0; i < arr.length; i++) { //提取模糊时机
	                        var ms1 = arr[i],
	                            ms2 = arr[i + 1];
	                        if (ms1 && ms2) {
	                            for (var r in bjreg) {
	                                var l3 = ms1 + ms2;
	                                if (l3.indexOf(bjreg[r][0]) == 0) { //复杂句式
	                                    arr[i + 1] = r + "：" + l3.replace(bjreg[r][0], "");
	                                    arr.splice(i--, 1);
	                                    break;
	                                }
	                            }
	                        }
	                    }
	                    var gjz = true;
	                    for (var i of arr) {
	                        var yc = get.HSA("yincang")[i];
	                        if (i.indexOf("过载：") >= 0) continue;
	                        if (gjz && i.length == 2) { //关键字效果
	                            var fy = get.HSA("yineng")[i];
	                            if (fy && !obj[fy]) obj[fy] = true;
	                        } else if (yc) { //隐藏关键字
	                            gjz = false;
	                            yc = get.HSA("yineng")[yc];
	                            obj[yc] = true;
	                        } else { //可叠加效果
	                            gjz = false;
	                            if (!i) continue;
	                            if (i.match(regs.jn)) { //激怒
	                                var jn = parseInt(i.slice(4, 5));
	                                if (!obj.jinu) obj.jinu = {};
	                                obj.jinu.value = jn;
	                            } else if (near(i, regs.fq)) { //法强
	                                var num = parseInt(i.slice(5));
	                                obj.hs_fq = num;
	                            } else if (near(i, regs.dm)) { //伤害
	                                var num = parseInt(mth(i, "(?<=造成).(?=点伤害)"));
	                                obj.prompt = i;
	                                obj.battleRoal = {
	                                    aifamily: "damage"
	                                };
	                                obj.battleRoal.filterTarget = lib.filter.all;
	                                obj.battleRoal.effect = get.strfunc("", "target.hs_dmgrcv('damage',event.fellow," + num + ");");
	                            } else if (near(i, regs.cv)) { //恢复
	                                var num = parseInt(mth(i, "(?<=恢复).(?=点生命值)"));
	                                obj.prompt = i;
	                                obj.battleRoal = {
	                                    aifamily: "recover"
	                                };
	                                obj.battleRoal.filterTarget = lib.filter.all;
	                                obj.battleRoal.effect = get.strfunc("", "target.hs_dmgrcv('recover',event.fellow," + num + ");");
	                            } else if (near(i, regs.qp)) { //弃牌
	                                var num = mth(i, "(?<=随机弃).(?=张牌)");
	                                if (num == "一") num = 1;
	                                else if (num == "两") num = 2;
	                                obj.battleRoal = {};
	                                obj.battleRoal.effect = get.strfunc("", "player.hs_discard(" + num + ");");
	                            } else if (near(i, regs.sgj)) { //收割机
	                                var num = parseInt(mth(i, "(?<=消耗为（).(?=）的随从)"));
	                                obj.deathRattle = {
	                                    recheck: "满场",
	                                };
	                                obj.deathRattle.effect = get.hsrfunc("event.fellow.SSfellow('range:" + num + "',false,'降落');");
	                            }
	                        }
	                        var barr = Object.keys(bjreg)
	                            .map(g => g + "：")
	                            .concat(["战吼：", "亡语：", "激励："]);
	                        if (!labed && barr.contains(i.slice(0, 3))) { //常见战吼或亡语或激励
	                            var eff = i.slice(3);
	                            var prx = i.slice(0, 2);
	                            var yn = bjreg[prx] ? bjreg[prx][1] : get.HSA("ywm")[prx];
	                            if (!obj[yn]) {
	                                obj[yn] = {};
	                                if (bjreg[prx]) {
	                                    for (var xx in bjreg[prx][2]) {
	                                        obj[yn][xx] = bjreg[prx][2][xx];
	                                    }
	                                }
	                            } else continue;
	                            if (eff.like("抽一张牌")) {
	                                obj[yn].effect = effects.draw;
	                            } else if (near(eff, regs.gn)) { //获得一张牌
	                                var n = mth(eff, "(?<=将一张).{1,10}(?=置入你的手牌)");
	                                n = get.HSE(n);
	                                obj[yn].effect = get.strfunc("", "player.hs_gain('" + n + "',event.fellow)");
	                            } else if (near(eff, regs.lava)) { //群伤
	                                var num = parseInt(mth(eff, "(?<=造成).(?=点伤害)"));
	                                var tp = mth(eff, "(?<=对所有).{2,4}(?=造成)");
	                                var range = "damage";
	                                if (tp == "角色") range = "all";
	                                else if (tp == "其他角色") range = "all_";
	                                else if (tp == "其他随从") range = "mns_";
	                                obj[yn].effect = get.strfunc("", "get.HSF('lavaeffect',['" + range + "'," + num + ",'lava',event.fellow]);");
	                            } else if (near(eff, regs.rcv)) { //恢复
	                                var num = parseInt(mth(eff, "(?<=恢复).(?=点生命值)"));
	                                obj[yn].randomRT = function(player) {
	                                    return player;
	                                };
	                                if (i.indexOf("敌方") > 0) obj[yn].randomRT = function(player) {
	                                    return player.getOppo();
	                                };
	                                obj[yn].effect = get.strfunc("", "target.hs_dmgrcv('recover'," + num + ",event.fellow);");
	                            } else if (near(eff, regs.sj)) { //弑君（不一定是对面的）
	                                var num = parseInt(mth(eff, "(?<=造成).(?=点伤害)"));
	                                obj[yn].randomRT = function(player) {
	                                    return player;
	                                };
	                                if (i.indexOf("敌方") > 0) obj[yn].randomRT = function(player) {
	                                    return player.getOppo();
	                                };
	                                obj[yn].effect = get.strfunc("", "target.hs_dmgrcv('damage'," + num + ",event.fellow" + (obj.anm == "fireatk" ? ",'fire'" : "") + ");");
	                            } else if (near(eff, regs.rsh)) { //飞刀
	                                var num = parseInt(mth(eff, "(?<=造成).(?=点伤害)"));
	                                obj[yn].randomRT = function(player) {
	                                    return player.HSF("randmgfil", ["opposide"]);
	                                };
	                                obj[yn].effect = get.strfunc("", "target.hs_dmgrcv('damage'," + num + ",event.fellow" + (obj.anm == "fireatk" ? ",'fire'" : "") + ");");
	                            } else if (near(eff, regs.rsh2)) { //榴弹投手
	                                var num = parseInt(mth(eff, "(?<=造成).(?=点伤害)"));
	                                obj[yn].randomRT = function(player) {
	                                    return player.sctp("notmine")
	                                        .filter(fl => fl.canhsdmg())
	                                        .randomGet();
	                                };
	                                obj[yn].effect = get.strfunc("", "target.hs_dmgrcv('damage'," + num + ",event.fellow" + (obj.anm == "fireatk" ? ",'fire'" : "") + ");");
	                            } else if (near(eff, regs.buff)) { //buff
	                                var arr = eff.match(reg("(?<=\\+).", "g"));
	                                obj[yn].effect = get.strfunc("", "event.fellow.updateSelfBuff([" + arr[0] + "," + arr[1] + "]);");
	                            } else if (near(eff, regs.buff1)) { //攻击力buff
	                                var num = parseInt(mth(eff, "(?<=\\+)."));
	                                obj[yn].effect = get.strfunc("", "event.fellow.updateSelfBuff(" + num + ");");
	                            } else if (near(eff, regs.buff2)) { //生命值buff
	                                var num = parseInt(mth(eff, "(?<=\\+)."));
	                                obj[yn].effect = get.strfunc("", "event.fellow.updateSelfBuff([0," + num + "]);");
	                            } else if (near(eff, regs.askl)) { //奥术傀儡
	                                obj[yn].effect = get.strfunc("", "player.getOppo().HSF('gainmana');");
	                            } else if (near(eff, regs.emws)) { //恶魔卫士
	                                obj[yn].effect = get.strfunc("", "player.HSF('removemana');");
	                            }
	                        }
	                    }
	                }
	            }
	        },
	        evts: function(name, evts) { //多个事件依次触发
	            var next = game.createEvent("multievents", false);
	            next.evts = evts;
	            next.str = name;
	            next.evt = _status.event;
	            next.setContent(function() {
	                "step 0"
	                event.i = 0;
	                event.num = event.evts.length;
	                "step 1"
	                event.cur = event.evts[event.i];
	                event.cur.evt = event.evt;
	                if (event.str == "deathRattle") get.HSF("desevent", [event.cur]);
	                else if (event.str == "discard") get.HSF("qpevent", [event.cur]);
	                else get.HSF("event", [event.str, event.cur]);
	                "step 2"
	                event.i++;
	                if (event.i < event.num) event.goto(1);
	            });
	        },
	        jilievent: function(m) { //使用英雄技能后时机
	            var next = game.createEvent("jilievent", false);
	            for (var i in m) {
	                next.set(i, m[i]);
	            }
	            next.cantrifls = game.me.sctp("field");
	            next.setContent(function() {
	                "step 0"
	                var cantrifls = event.cantrifls;
	                var n1 = "heroskillAfter";
	                var n2 = "jili";
	                var tris = game.me.sctp("field")
	                    .filter(i => (i.triggers[n1] || i.triggers[n2] && player == i.getLeader()) && !(cantrifls.length > 0 && !cantrifls.contains(i)))
	                    .reduce((x, y) => {
	                    var tri = [];
	                    if (y.triggers[n1]) tri = y.triggers[n1].filter(t => !(t.filter && !t.filter(evt, i.getLeader(), i, t)));
	                    if (y.triggers[n2]) tri.add(y.triggers[n2]);
	                    x = x.concat(tri);
	                    return x;
	                }, [])
	                    .sort(lib.sort.attendseq);
	                event.i = 0;
	                event.tris = tris;
	                event.trisnum = event.tris.length;
	                if (!event.trisnum) event.finish();
	                "step 1"
	                var obj = event.tris[event.i];
	                var fl = obj.cur;
	                if (!game.me.sctp("field", fl)) {
	                    event.i++;
	                    if (event.i < event.evnum) event.redo();
	                } else fl.hs_trisEffect(obj, event);
	                "step 2"
	                event.i++;
	                if (event.i < event.trisnum) {
	                    game.delay(0.5);
	                    event.goto(1);
	                }
	            });
	            return next;
	        },
	        qpevent: function(m) { //弃牌时机
	            var next = game.createEvent("qpevent", false);
	            for (var i in m) {
	                next.set(i, m[i]);
	            }
	            next.cantrifls = game.me.sctp("field");
	            next.setContent(function() {
	                "step 0"
	                var cantrifls = event.cantrifls;
	                var n1 = "discard";
	                var tris = game.me.sctp("field")
	                    .filter(i => i.triggers[n1] && !(cantrifls.length > 0 && !cantrifls.contains(i)))
	                    .reduce((x, y) => {
	                    var tri = y.triggers[n1].filter(t => !(t.filter && !t.filter(evt, i.getLeader(), i, t)));
	                    x = x.concat(tri);
	                    return x;
	                }, [])
	                    .sort(lib.sort.attendseq);
	                event.i = 0;
	                event.tris = tris;
	                event.trisnum = event.tris.length;
	                if (!event.trisnum) event.finish();
	                "step 1"
	                var obj = event.tris[event.i];
	                var fl = obj.cur;
	                if (!game.me.sctp("field", fl)) {
	                    event.i++;
	                    if (event.i < event.evnum) event.redo();
	                } else fl.hs_trisEffect(obj, event);
	                "step 2"
	                event.i++;
	                if (event.i < event.trisnum) {
	                    game.delay(0.5);
	                    event.goto(1);
	                }
	                "step 3"
	                var info = get.info(card);
	                if (get.type(card) == "HS_spell" && info.sameeffect == "discarded") player.hs_spellEffect(card);
	            });
	            return next;
	        },
	        desevent: function(m) { //随从死亡时机
	            var next = game.createEvent("desevent", false);
	            for (var i in m) {
	                next.set(i, m[i]);
	            }
	            next.cantrifls = game.me.sctp("field");
	            next.setContent(function() {
	                "step 0"
	                var n1 = "deathRattle";
	                var n2 = "deathFL";
	                var evt = event;
	                var cantrifls = event.cantrifls;
	                event.pls = game.me.sctp("field")
	                    .concat(game.dead)
	                    .concat(game.dead_wp)
	                    .filter(i => {
	                    if (i.triggers[n1] && i.triggers[n1].length > 0 && evt.link == i) return true;
	                    else if (get.itemtype(evt.link) == "player" && i.triggers[n2] && !game.dead.contains(i) && !game.dead_wp.contains(i)) {
	                        var obj = i.triggers[n2];
	                        if (cantrifls.length > 0 && !cantrifls.contains(i)) return false;
	                        if (obj.filter && !obj.filter(evt, i.getLeader(), i, obj)) {
	                            return false;
	                        }
	                        return true;
	                    }
	                    return false;
	                })
	                    .sort(lib.sort.attendseq);
	                event.i = 0;
	                event.plsnum = event.pls.length;
	                if (event.plsnum == 0) event.finish();
	                "step 1"
	                var fl = event.pls[event.i];
	                if (event.link == fl) {
	                    if (get.itemtype(fl) == "player") {
	                        fl.HSF("morefocus");
	                        var info = fl.triggers.deathRattle;
	                        fl.hs_deathRattle(info);
	                    } else {
	                        var info = fl.HSF("info");
	                        if (info && info.deathRattle) fl.hs_deathRattle([info.deathRattle]);
	                    }
	                } else fl.hs_trisEffect(fl.triggers.deathFL, event);
	                "step 2"
	                event.i++;
	                if (event.i < event.plsnum) {
	                    game.delay(0.5);
	                    event.goto(1);
	                }
	            });
	            return next;
	        },
	        event: function(n, m) { //自定义时机
	            if (!_status.hsgamestart) return;
	            var next = game.createEvent(n, false);
	            for (var i in m) {
	                next.set(i, m[i]);
	            }
	            next.evt = next.evt || _status.event;
	            if (!_status.event.cantrifls) {
	                var fls = game.me.sctp("field");
	                next.cantrifls = fls;
	                next.evt.cantrifls = fls;
	            } else next.cantrifls = _status.event.cantrifls;
	            next.setContent(function() {
	                "step 0"
	                var n = event.name;
	                var evt = event;
	                var tris = [];
	                var cantrifls = event.cantrifls || [];
	                tris = player.sctp("field")
	                    .filter(i => i.triggers[n] && i.triggers[n].length)
	                    .reduce((x, y) => {
	                    var xg = y.triggers[n];
	                    return x.concat(xg);
	                }, [])
	                    .filter(i => {
	                    if (event.evt.triedeff && event.evt.triedeff.contains(i)) return false;
	                    var fl = i.cur; //执行效果的为扳机所在随从
	                    if (!fl) return false;
	                    if (cantrifls.length > 0 && !cantrifls.contains(fl)) return false;
	                    var p = fl.getLeader(); //控制者为随从主人
	                    if (i.sc && evt.source != fl) return false;
	                    if (i.self && evt.player != p) return false;
	                    if (i.fl && evt.player != (get.itemtype(fl) == "player" ? fl : fl.getLeader())) return false;
	                    if (i.notlink) {
	                        if (n.contains("summon") && evt.link == fl) return false;
	                        if (n.contains("useCard") && evt.cards == fl.linkCard) return false;
	                    }
	                    if (i.filter) {
	                        if (typeof i.filter == "string") {
	                            i.filter = get.HSF("strfil", [i.filter]);
	                        }
	                        if (!i.filter(evt, p, fl, i)) {
	                            return false;
	                        }
	                    }
	                    return true;
	                });
	                if (n == "attackEnd" && !player.isMin() && player.data_weapon) {
	                    var wp = player.data_weapon;
	                    tris.add({
	                        charlotte: true,
	                        cur: wp,
	                        fellow: wp,
	                        player: player,
	                        effect: function() {
	                            event.fellow.hs_dmgrcv(1);
	                        },
	                        stid: get.hs_id(wp),
	                    });
	                }
	                if (tris.length == 0) event.finish();
	                else {
	                    tris.sort(lib.sort.attendseq);
	                    var main = get.hs_main();
	                    event.tris1 = tris.filter(i => i.cur.getLeader() == main);
	                    event.tris2 = tris.filter(i => i.cur.getLeader() != main);
	                    event.i = 0;
	                    event.mm = event.tris1;
	                    if (!event.mm.length) event.goto(3);
	                };
	                "step 1"
	                event.evnum = event.mm.length;
	                var obj = event.mm[event.i];
	                var fl = obj.cur;
	                if (!game.me.sctp("field", fl)) {
	                    event.i++;
	                    if (event.i < event.evnum) event.redo();
	                } else fl.hs_trisEffect(obj, event);
	                "step 2"
	                event.i++;
	                if (event.i < event.evnum) {
	                    game.delay(0.5);
	                    event.goto(1);
	                }
	                "step 3"
	                if (event.mm == event.tris1 && event.tris2.length) {
	                    event.i = 0;
	                    event.mm = event.tris2;
	                    event.goto(1);
	                }
	            });
	            return next;
	        },
	        //player.HSF专用函数
	        addtodeck: function(p, cards, source) { //制造衍生卡洗入牌库
	            var next = game.createEvent("addtodeck", false);
	            next.player = p;
	            if (typeof cards == "string") cards = [cards];
	            if (cards.length == 2) {
	                if (typeof cards[1] == "number") cards = get.HSF("repeat", [cards[0], cards[1]]);
	            }
	            if (get.itemtype(cards) != "cards") cards = cards.map(i => get.chscard(i));
	            next.cards = cards;
	            next.source = source;
	            next.setContent(function() {
	                "step 0"
	                var n = player.cardPile.countCards("h");
	                player.cardPile.forcecount = n;
	                player.cardPile.style.pointEvents = "none";
	                event.shaohui = 0;
	                if (n + cards.length > 60) {
	                    event.shaohui = n + cards.length - 60;
	                    event.shcs = cards.slice(event.shaohui);
	                    player.heroskill.pos.directgain(event.shcs);
	                    cards = cards.slice(0, event.shaohui);
	                }
	                if (cards.length) player.cardPile.directgain(cards);
	                else event.finish();
	                "step 1"
	                player.hs_sort();
	                var res = cards;
	                var renum = cards.length;
	                var p = player;
	                var jishu = 0;
	                var sc = event.source;
	                p.cardPile.parentNode.classList.add("hs_check");
	                p.cardPile.querySelector(".count")
	                    .show();
	                get.HSF("checkdeck");
	                setTimeout(function() {
	                    p.cardPile.parentNode.classList.add("hs_check");
	                    p.cardPile.querySelector(".count")
	                        .show();
	                    var id = setInterval(function() {
	                        var ca = res[jishu];
	                        game.log(ca, "洗入", p, "的牌库");
	                        p.discardPile.$gain2([ca], false);
	                        p.cardPile.forcecount++;
	                        jishu++;
	                        get.HSF("checkdeck");
	                        if (jishu == renum) clearInterval(id);
	                    }, 300);
	                    setTimeout(function() {
	                        setTimeout(function() {
	                            p.cardPile.parentNode.classList.remove("hs_check");
	                            p.cardPile.querySelector(".count")
	                                .hide();
	                            p.cardPile.style.pointEvents = "";
	                            delete p.cardPile.forcecount;
	                            get.HSF("checkdeck");
	                        }, 2000);
	                    }, renum * 50);
	                }, 800);
	                "step 2"
	                if (!event.isMine()) game.delay(4);
	                else game.delay(2);
	            });
	        },
	        convert: function(p, name, self, copy) { //变形：变形对象，变成的卡名，自变形，复制
	            var next = game.createEvent("convert", false);
	            next.player = p.getLeader();
	            next.target = p;
	            if (typeof name == "string") name = get.chscard(name);
	            if (get.itemtype(name) == "card") next.cards = [name];
	            else if (get.itemtype(name) == "cards") next.cards = name;
	            if (next.cards && !next.card) next.card = next.cards[0];
	            next.canrever = true;
	            if (self || _status.event.name == "hs_spellEffect") next.canrever = false;
	            if (copy) next.copy = copy;
	            next.setContent(function() {
	                "step 0"
	                target.uninit();
	                _status.hsAttendSeq.cl([target]);
	                target.hide();
	                "step 1"
	                target.init(card.name.slice(0, -8));
	                target.hs_FL(cards, "R");
	                if (event.copy) {
	                    var c = event.copy;
	                    target.hs_dm = c.hs_dm;
	                    for (var i of c.buff) { //i为buff
	                        if (i.charlotte) continue;
	                        var ob = {};
	                        for (var k in i) { //k为buff的属性
	                            if (k == "creator" || k == "fellow") {
	                                ob[k] = target;
	                            } else if (k == "stid") ob[k] = get.id();
	                            else if (k == "value") continue;
	                            else if (k == "type") {
	                                ob.type = i.type;
	                                if (i.type == "trigger" && i.value.length) {
	                                    ob.value = [];
	                                    for (var j of i.value) { //j为一个扳机
	                                        var tn = j.triname;
	                                        var noarr = ["battleRoal", "jili", "deathFL", "discarded"];
	                                        var noarred = noarr.contains(tn);
	                                        var oo = {};
	                                        if (!noarred && !target.triggers[tn]) target.triggers[tn] = [];
	                                        if (noarred) target.triggers[tn] = oo;
	                                        else target.triggers[tn].add(oo);
	                                        for (var p in j) { //p为扳机的一个属性
	                                            if (p == "creator" || p == "fellow") {
	                                                oo[p] = target;
	                                            } else if (p == "relabuff") {
	                                                oo[p] = ob;
	                                            } else oo[p] = j[p];
	                                        }
	                                        ob.value.add(oo);
	                                    }
	                                } else {
	                                    ob.value = i.value;
	                                }
	                            } else ob[k] = i[k];
	                        }
	                        target.addhsbuff(ob);
	                    }
	                    var o = c.hs_calcv(true);
	                    if (o[0] < 0) target.baseATK = 0;
	                }
	                "step 2"
	                target.show();
	                if (!event.copy) target.hs_yin();
	                _status.hsAttendSeq.ad(target);
	                get.HSF("updateauras", [true]);
	                "step 3"
	                if (event.canrever) player.HSF("hs_rever", [target]);
	            });
	        },
	        hs_rever: function(p, pls) { //召唤回溯
	            if (get.itemtype(pls) == "player") pls = [pls];
	            pls.sort(lib.sort.attendseq);
	            var evts = [];
	            pls.forEach(i => {
	                evts.push({
	                    player: p,
	                    card: i.linkCard[0],
	                    link: i
	                });
	            });
	            get.HSF("evts", ["summonSucc", evts]);
	        },
	        cuihui: function(pls, now) { //待摧毁或强制死亡
	            if (!Array.isArray(pls)) pls = [pls];
	            if (pls[0].classList.contains("hs_wp")) {
	                pls[0].willdie = true;
	                pls[0].swt(false);
	                if (_status.event.name == "checkdeath") pls[0].classList.add("wywy");
	            }
	            if (get.itemtype(pls) == "players") pls.forEach(p => {
	                p.willdie = true;
	                if (_status.event.name == "checkdeath") {
	                    p.classList.add("wywy");
	                    setTimeout(function() {
	                        p.node.avatar.style.filter = "grayscale(1)";
	                    }, 500);
	                    p.classList.remove("dongjied");
	                    p.classList.remove("chenmo");
	                    p.classList.remove("fengnu");
	                    p.classList.remove("superfengnu");
	                    p.classList.remove("chenmo");
	                } else {
	                    p.node.avatar.style.filter = "sepia(0.7)";
	                };
	            });
	            if (now) get.HSF("checkdeath", [true]);
	        },
	        alive: function(p, ignore) { //随从在场上且没有濒死
	            if (ignore == "hp") return p.hp > 0;
	            if ((p.hp <= 0 || p.willdie) && !ignore) return false;
	            if (get.itemtype(p) != "player") return true;
	            else return game.players.some(i => get.hs_id(i, p));
	        },
	        hasCFeff: function(p) { //嘲讽效果生效
	            return p.hasgjz("chaofeng") && !p.hasgjz("qianxing") && !p.hasgjz("mianyi");
	        },
	        canbetarget: function(p, card, t, method) { //能成为目标
	            if (method == "card") {
	                if (card && get.type(card) == "HS_spell" && t.hasgjz("momian")) return false;
	                if (t.hasgjz("qianxing") || t.hasgjz("mianyi")) {
	                    if (p != t.getLeader()) return false;
	                }
	                return true;
	            }
	            if (method == "heroskill") {
	                if (t.hasgjz("momian")) return false;
	                if (t.hasgjz("qianxing") || t.hasgjz("mianyi")) {
	                    if (p != t.getLeader()) return false;
	                }
	                return true;
	            }
	            if (method == "battleroal") {
	                if (t.hasgjz("qianxing") || t.hasgjz("mianyi")) {
	                    if (p.getLeader() != t.getLeader()) return false;
	                }
	                return true;
	            }
	            if (method == "attack") {
	                if (t.hasgjz("qianxing") || t.hasgjz("mianyi")) return false;
	                var tt = t.getLeader();
	                if (tt.hasFellow(fl => fl.HSF("hasCFeff")) && !t.HSF("hasCFeff")) return false;
	                return true;
	            }
	        },
	        changeHeroskill: function(p, skill) { //更换英雄技能
	            var next = game.createEvent("changeHeroskill", false);
	            next.player = p;
	            if (skill.indexOf("hs_hero") < 0) {
	                var exhrsk = get.HSA("exhrsk");
	                var searched = false;
	                for (var i in exhrsk) {
	                    if (exhrsk[i][0] == skill) {
	                        skill = "hs_hero_" + i;
	                        searched = true;
	                        if (!lib.skill[skill]) lib.hearthstone.eval_heroskill(skill, exhrsk[i]);
	                        break;
	                    }
	                }
	                if (!searched) {
	                    get.hs_alt("changeHeroskill:", skill, "不是一个合法的英雄技能");
	                    return;
	                }
	            }
	            next.skill = skill;
	            next.dom = p.heroskill;
	            next.setContent(function() {
	                "step 0"
	                event.dom.classList.remove("used");
	                player.removeSkill(event.dom.skill);
	                delete event.dom.skill;
	                "step 1"
	                game.delay();
	                "step 2"
	                event.dom.forceused = true;
	                event.dom.classList.add("used");
	                get.HSF("checkheroskill");
	                "step 3"
	                var s = event.skill;
	                var info = get.info(s);
	                event.dom.divcost.innerHTML = player.HSF("hs_num", [s]) + "";
	                event.dom.baseCost = info.cost;
	                event.dom.cost = event.dom.baseCost;
	                event.dom.used = 0;
	                event.dom.filterTarget = info.filterT;
	                event.dom.filterTarget = info.filterT;
	                event.dom.skill = s;
	                player.addSkill(s);
	                event.dom.frontface.style.backgroundImage = "url('" + lib.assetURL + "extension/炉石普通/image/heroskill/" + skill.replace("_legend", "") + ".jpg')";
	                game.delay();
	                "step 4"
	                event.dom.classList.remove("used");
	                game.delay();
	                "step 5"
	                delete event.dom.forceused;
	                get.HSF("checkheroskill");
	            });
	        },
	        updateauras: function(bo) { //更新光环
	            game.me.sctp("field", fl => {
	                fl.buff.forEach(i => {
	                    if (i.type == "auras") {
	                        if (typeof i.sleep == "boolean") delete i.sleep;
	                    } else if (i.tvalue) {
	                        i.value = i.tvalue;
	                        delete i.tvalue;
	                    }
	                });
	            });
	            if (bo) {
	                get.HSF("checkfellow");
	                get.HSF("checkhand2");
	            }
	        },
	        hs_num: function(p, skill) { //获取法力消耗
	            skill = skill || lib.character[p.name][3][0];
	            var info = lib.skill[skill];
	            if (!info) get.hs_alt("hs_num:", skill);
	            if (typeof info.cost == "number") return info.cost;
	            else if (info.cost == "auto") return skill.indexOf("_legend") > 0 ? 2 : 1;
	            else return 0;
	        },
	        //法力水晶相关
	        mana: function(p) { //获取可用法力水晶
	            var total = p.HSF("manamax");
	            var used = p.countMark("hs_mana_used");
	            return Math.max(0, total - used);
	        },
	        manamax: function(p) { //获取上限合计
	            var max = p.countMark("hs_mana_max");
	            var temp = p.countMark("hs_mana_temp");
	            return max + temp;
	        },
	        manalimit: function() { //获取当前模式能达到的法力水晶上限
	            return get.hs_nm() == 3 ? 3 : 10;
	        },
	        updatemana: function(p) { //更新法力值显示
	            var mana = p.mana;
	            if (p.countMark("hs_mana_used") == 0) mana.childNodes[0].replaceData(0, 5, p.HSF("mana"));
	            //mana.innerHTML = p.HSF("mana");
	            else mana.childNodes[0].replaceData(0, 5, p.HSF("mana") + "/" + p.HSF("manamax"));
	            // mana.innerHTML = p.HSF("mana") + "/" + p.HSF("manamax");
	            if (p.HSF("mana") == 0 != mana.classList.contains("hs_d")) mana.classList.toggle("hs_d");
	            if (mana.innerHTML.length > 1 != mana.classList.contains("hs_s")) mana.classList.toggle("hs_s");
	            var locked = p.countMark("hs_mana_locked");
	            var owed = p.countMark("hs_mana_owed");
	            var olocked = parseInt(mana.locked.innerHTML) || 0;
	            var oowed = parseInt(mana.owed.innerHTML) || 0;
	            mana.locked.innerHTML = locked;
	            mana.owed.innerHTML = owed;
	            if (locked != olocked) mana.locked.animate("hs_start");
	            if (owed != oowed) mana.owed.animate("hs_start");
	            if (locked > 0) mana.locked.show();
	            else mana.locked.hide();
	            if (owed > 0) mana.owed.show();
	            else mana.owed.hide();
	        },
	        usemana: function(p, num, log) { //消耗法力值
	            if (num === undefined) num = 1;
	            num = Math.max(0, num);
	            if (log !== false) game.log(p, "消耗了" + num + "点法力值");
	            if (num == 0) return;
	            var max = p.countMark("hs_mana_max");
	            var used = p.countMark("hs_mana_used");
	            var temp = p.countMark("hs_mana_temp");
	            p.removeMark("hs_mana_temp", Math.min(num, temp), false);
	            if (num > temp) p.addMark("hs_mana_used", num - temp, false);
	            p.HSF("updatemana");
	            p.HSF("checkheroskill");
	        },
	        recovermana: function(p, num, log) { //回复法力值
	            var max = p.countMark("hs_mana_max");
	            var used = p.countMark("hs_mana_used");
	            var locked = p.countMark("hs_mana_locked");
	            if (num == "all") num = p.storage.hs_mana_limit;
	            if (num === undefined) num = 1;
	            num = Math.min(num, used - locked);
	            num = Math.max(0, num);
	            if (num == 0) return;
	            if (log !== false) game.log(p, "回复了" + num + "点法力值");
	            p.removeMark("hs_mana_used", num, false);
	            p.HSF("updatemana");
	        },
	        gainmana: function(p, num, empty, log) { //获得法力水晶
	            var total = p.HSF("manamax");
	            var limit = p.storage.hs_mana_limit;
	            var max = p.countMark("hs_mana_max");
	            var used = p.countMark("hs_mana_used");
	            var locked = p.countMark("hs_mana_locked");
	            var temp = p.countMark("hs_mana_temp");
	            if (num === undefined) num = 1;
	            num = Math.max(0, num); //至少为0
	            if (num == 0) return;
	            if (empty) {
	                num = Math.min(num, limit - max - temp); //最大限制
	                if (num == 0) return;
	                else {
	                    p.addMark("hs_mana_max", num, false);
	                    p.addMark("hs_mana_used", num, false);
	                }
	            } else {
	                num = Math.min(num, used + limit - max); //最大限制
	                if (num > 0 && locked > 0) {
	                    var an = Math.min(num, locked);
	                    p.removeMark("hs_mana_locked", an, false);
	                    num -= an;
	                }
	                if (num == 0) return;
	                else {
	                    var num2 = Math.min(num, limit - max);
	                    if (num2) p.addMark("hs_mana_max", num2, false);
	                    var num2 = Math.min(temp, Math.max(0, num - (limit - total)));
	                    if (num2) p.removeMark("hs_mana_temp", num2, false);
	                    var num2 = Math.max(0, num - (limit - max));
	                    if (num2) p.removeMark("hs_mana_used", num2, false);
	                }
	            }
	            if (log !== false) game.log(p, "获得了" + num + "个" + (empty ? "空的" : "") + "法力水晶");
	            p.HSF("updatemana");
	        },
	        removemana: function(p, num, log) { //摧毁法力水晶
	            var max = p.countMark("hs_mana_max");
	            if (max == 0) return;
	            if (num === undefined) num = 1;
	            num = Math.max(0, num); //至少为0
	            num = Math.min(num, max); //最大摧毁数量
	            if (num == 0) return;
	            p.removeMark("hs_mana_max", num, false);
	            p.HSF("recovermana", [num, false]);
	            if (log !== false) game.log(p, "摧毁了" + num + "个法力水晶");
	            p.HSF("updatemana");
	        },
	        gaintempmana: function(p, num, log) {
	            //获得临时法力水晶
	            var total = p.HSF("manamax"); //总水晶上限
	            var limit = p.storage.hs_mana_limit; //最大水晶上限
	            var used = p.countMark("hs_mana_used"); //已用水晶
	            var locked = p.countMark("hs_mana_locked"); //锁定水晶
	            if (num === undefined) num = 1;
	            num = Math.max(0, num); //至少为0
	            num = Math.min(num, limit - p.HSF("mana")); //最大限制
	            if (num == 0) return;
	            var num2 = Math.min(num, limit - total); //增加水晶上限数
	            if (num2 > 0) p.addMark("hs_mana_temp", num2, false);
	            var num2 = Math.max(0, num - num2); //回复水晶数
	            num2 = Math.min(num2, used - locked);
	            if (num2 > 0) p.removeMark("hs_mana_used", num2, false);
	            if (log !== false) game.log(p, "获得了" + num + "个临时法力水晶");
	            p.HSF("updatemana");
	        },
	        //其他函数
	        phaseUse: function(p) { //在你的出牌阶段
	            return _status.currentPhase == p && _status.event && _status.event.name == "chooseToUse" && _status.event.parent.name == "phaseUse";
	        },
	        dragposition: function(dx) { //拖拽随从位置
	            var p = game.me;
	            var n = p.countFellow();
	            if (n == 0) return 2;
	            var pos = 2;
	            var it = lib.hearthstone.hs_scjj * get.HSF("cfg", ["HS_customzoom"]);
	            var abs = lib.hearthstone.hs_absl;
	            var num = Math.ceil((dx - abs) * 2 / it);
	            if (n % 2 == 1) {
	                var mid = (n + 3) / 2;
	                pos = mid + Math.ceil(num / 2);
	            } else {
	                var mid = (n + 2) / 2;
	                pos = mid + Math.ceil((num + 1) / 2);
	            }
	            pos = Math.max(2, pos);
	            pos = Math.min(n + 2, pos);
	            return pos;
	        },
	        //特定效果
	        crossDraw: function(first, num) { //双方玩家抽牌
	            var next = game.createEvent("crossDraw", false);
	            if (typeof first == "string") {
	                if (first == "main") first = get.hs_main();
	                else first = get.player()
	                    .scpl(first);
	            }
	            next.player = first;
	            next.target = first.getOppo();
	            next.num = num;
	            next.setContent(function() {
	                "step 0"
	                event.i = 0;
	                "step 1"
	                player.hs_drawDeck();
	                "step 2"
	                target.hs_drawDeck();
	                "step 3"
	                event.i++;
	                if (event.i < event.num) event.goto(1);
	            });
	            return next;
	        },
	        complexDmg: function() { //分段伤害效果
	            var next = game.createEvent("complexDmg", false);

	            next.common = common;
	            /*
	            arr=>[{
	                player:target,
	                num:4,
	            },{
	                targets:target.sctp("myside_"),
	                num:1,
	            }]
	            common=>{
	                source:player,
	                card:_status.event.card,
	                type:"damage",
	                anm:claw,
	            }
	             */
	            next.setContent(function() {
	                "step 0"
	                event.i = 0;
	                event.num = event.arr.length;
	                if (event.common) {
	                    for (var i in event.common) {
	                        event.arr.forEach(j => {
	                            j[i] = event.common[i];
	                        });
	                    }
	                }
	                "step 1"
	                event.cur = event.arr[event.i];
	                var type = event.cur.type || "damage";
	                if (event.cur.line) event.cur.source.HSline(event.cur.player);
	                event.cur.player.hs_dmgrcv(type, event.cur.num, event.card, event.cur.source, event.cur.nature);
	                "step 2"
	                event.i++;
	                if (event.i < event.num) event.goto(1);
	            });
	        },
	        lavaeffect: function(type, num, anm, source) { //全体随从效果
	            num = num || 1;
	            var next = game.createEvent("lavaeffect", false);
	            next.acttype = "damage";
	            next.num = num;
	            if (type == "cuihui") {
	                if (typeof source == "string") source = get.player()
	                    .scpl(source);
	                if (typeof num == "string") next.pls = source.sctp(num);
	                next.acttype = "cuihui";
	            }
	            next.player = get.player();
	            next.card = _status.event.card;
	            next.anm = anm || "lava";
	            if (type && type != "damage" && type != "cuihui" && typeof num == "number") {
	                if (typeof source == "string") source = get.player()
	                    .scpl(source);
	                next.pls = source.sctp(type);
	            }
	            if (!next.pls) next.pls = get.HSF("minors");
	            next.source = source;
	            next.setContent(function() {
	                "step 0"
	                if (event.pls.contains(game.me) && event.pls.contains(game.enemy)) event.anm += "_2";
	                ui.zonearena.animate(event.anm, 1500);
	                "step 1"
	                game.delay(0.5);
	                "step 2"
	                if (event.acttype == "damage") {
	                    if (event.pls.length) player.hs_dmgrcvaoe(event.num, event.card, event.source, event.pls);
	                } else event.pls.forEach(i => i.HSF("cuihui"));
	                "step 3"
	                game.delay(0.5);
	            });
	            return next;
	        },
	        bladeeffect: function(type, num, source) { //旋风斩效果
	            return get.HSF("lavaeffect", [type, num, "blade", source]);
	        },
	        //其他函数
	        minors: function(func, sort) { //获取场上所有随从
	            var pls = game.me.getFellow(func)
	                .concat(game.enemy.getFellow(func));
	            if (sort) pls.sort(sort);
	            return pls;
	        },
	        css_func: function(num, init, width) { //生成随从位置css
	            num = num || 3; //随从上限
	            init = init || lib.hearthstone.hs_sczb; //中间随从的左边
	            width = width || lib.hearthstone.hs_scjj; //随从间距
	            var topme = 330; //己方随从的顶边
	            var topenemy = 474; //敌方随从的顶边
	            var calc = function(c, s, n) {
	                var res = "#arena.hscss>.player.minskin[data-enemy='0']{top:calc(100% - " + topme + "px);left:calc(100% - " + init + "px);}" +
	                    "#arena.hscss>.player.minskin[data-enemy='1']{top:calc(100% - " + topenemy + "px);left:calc(100% - " + init + "px);}";
	                for (var i = 0; i < c; i++) {
	                    var len = i + 1;
	                    for (var j = 0; j < len; j++) {
	                        var pos = 2 + j;
	                        var pos2 = 2 + c + j;
	                        var mid = i / 2;
	                        var pi = parseInt(init + (mid - j) * width);
	                        res +=
	                            "#arena.hscss.hs" + len + "me>.player.minskin[data-position='" + pos + "']{top:calc(100% - " + topme + "px);left:calc(100% - " + pi + "px);}" +
	                            "#arena.hscss.hs" + len + "enemy>.player.minskin[data-position='" + pos2 + "']{top:calc(100% - " + topenemy + "px);left:calc(100% - " + pi + "px);}" +
	                            "#arena.hscss>.player.minskin[data-position='d" + len + "_" + pos + "']{top:calc(100% - " + topme + "px);left:calc(100% - " + pi + "px);}" +
	                            "#arena.hscss>.player.minskin[data-position='d" + len + "_" + pos2 + "']{top:calc(100% - " + topenemy + "px);left:calc(100% - " + pi + "px);}";
	                    }
	                }
	                var jg = 35; //手牌间距
	                for (var i = 1; i <= 10; i++) {
	                    res += "#arena.hscss.hs_view.hs_" + i + "hand:not(.hs_kaichang):not(.single-handcard):not(.chess)>#me>#handcards1>div{left:calc(100% - " + (700 + jg * i - jg) + "px) !important;}";
	                }
	                return res;
	            }
	            return calc(num, init, width);
	        },
	        hs_testfl: function() { //隐藏指示随从
	            delete _status.hs_fldragging;
	        },
	        hs_stopview: function() { //隐藏详情区
	            if (ui.morezone.classList.contains("viewhand")) {
	                ui.morezone.hide();
	                ui.morezone.classList.remove("viewhand");
	                game.me.countCards("h", ca => {
	                    delete ca.islong;
	                });
	            }
	        },
	        hsdouble: function(player) { //更新场地样式
	            var mark = player == game.me ? "me" : "enemy";
	            var arr = Array.from(ui.arena.classList);
	            var n = arr.filter(i => i.length == 3 + mark.length && i.indexOf("hs") == 0 && i.indexOf(mark) > 0)[0];
	            ui.arena.classList.remove(n);
	            var mark2 = "hs" + (player.countFellow() + (player == game.me && _status.hs_fldragging ? 1 : 0)) + mark;
	            ui.arena.classList.add(mark2);
	        },
	        prompt: function(card) { //获取卡牌描述
	            if (get.type(card) == "HS_weapon") return get.translation(card.name + "_info");
	            var info = get.info({
	                name: card.name,
	            });
	            if (!info || !info.oriname) return "";
	            return lib.hearthstone.cardPack.monsterRD[info.oriname][2];
	        },
	        checkdeath: function(qz) { //检查死亡
	            var next = game.createEvent("checkdeath", false);
	            next.qz = qz;
	            next.setContent(function() {
	                "step 0"
	                if (!game.me.HSF("alive")) game.me.hs_losing = true;
	                if (!game.enemy.HSF("alive")) game.enemy.hs_losing = true;
	                event.willdie = game.dead.concat(game.me.sctp("mns")
	                    .concat([game.me.data_weapon, game.enemy.data_weapon])
	                    .filter(i => i && !i.HSF("alive"))
	                    .concat([game.me.old_weapon, game.enemy.old_weapon].filter(i => i)))
	                    .sort(lib.sort.attendseq);
	                if (event.willdie.length == 0) event.goto(9);
	                else game.delay(1.7);
	                "step 1"
	                game.dead_wp = [];
	                event.willdie.forEach(i => {
	                    get.HSF("cuihui", [i]);
	                    if (get.itemtype(i) == "player") {
	                        if (!i.isMin() || i.dataset.position.indexOf("d") == 0) return;
	                        var a = i.getLeader()
	                            .countFellow();
	                        var b = parseInt(i.dataset.position);
	                        i.dataset.position = "d" + a + "_" + b;
	                    } else {
	                        game.dead_wp.push(i);
	                    }
	                });
	                "step 2"
	                game.delay();
	                "step 3"
	                get.HSF("arrange", [true]);
	                game.delay(0.3);
	                "step 4"
	                event.willdiep = event.willdie.filter(t => t.isMin && t.isMin());
	                if (event.willdiep.length) {
	                    game.dead.addArray(event.willdiep);
	                    game.log(event.willdiep, "阵亡");
	                    event.willdiep.forEach(i => i.removehsbuff(i.buff.filter(j => j.type == "auras")));
	                    game.players.removeArray(event.willdiep);
	                    var hs_qc = function(p, pls) {
	                        var pls2 = pls.filter(i => get.itemtype(i) == "player");
	                        var mine = pls2.filter(i => i.getLeader() == p);
	                        _status.hs_dead[p.playerid].addArray(mine.map(i => ({
	                            name: i.linkCard[0].name,
	                            id: get.hs_id(i)
	                        })));
	                        _status.hs_dead_All[p.playerid] = _status.hs_dead_All[p.playerid].concat(mine.map(i => i.linkCard[0].name));
	                        p.actcharacterlist.removeArray(mine);
	                        var bonus = p == game.me ? 0 : get.hs_nm();
	                        mine.forEach(i => {
	                            get.HSF("Aud", [i, "death"]);
	                            if (i.hs_remove || i.hs_tokened || i.hs_token) p.heroskill.pos.directgain(i.linkCard);
	                            else p.discardPile.directgain(i.linkCard);
	                            i.classList.add("removing");
	                        });
	                        var f1 = p.getFellow()
	                            .sort(lib.sort.position);
	                        f1.forEach((i, j) => {
	                            i.dataset.position = 2 + j + bonus + "";
	                        });
	                        p.actcharacterlist = f1;
	                    }
	                    hs_qc(game.me, event.willdie);
	                    hs_qc(game.enemy, event.willdie);
	                }
	                var df = function(p) {
	                    var f = function(m) {
	                        var w = p[m];
	                        if (w && event.willdie.contains(w)) {
	                            p.discardPile.directgain(w.linkCard);
	                            w.swt(false);
	                            w.node.atk.hide();
	                            w.node.hp.hide();
	                            p.rmv_weapon = w;
	                            p[m] = null;
	                            setTimeout(function() {
	                                w.delete();
	                            }, 450);
	                            game.log(p, "的", w.linkCard, "被摧毁了");
	                        }
	                    };
	                    f("old_weapon");
	                    f("data_weapon");
	                };
	                df(game.me);
	                df(game.enemy);
	                get.HSF("updateauras", [true]);
	                "step 5"
	                game.delay(0.45);
	                "step 6"
	                var evts = [];
	                event.willdie.forEach(i => {
	                    evts.push({
	                        player: i.getLeader(),
	                        link: i,
	                    });
	                });
	                get.HSF("evts", ["deathRattle", evts]);
	                "step 7"
	                //抹杀存在
	                game.dead.forEach(i => {
	                    _status.hsAttendSeq.cl(i.buff);
	                    if (get.itemtype(i) == "player") ui.arena.removeChild(i);
	                    i = null;
	                });
	                var df = function(p) {
	                    if (p.rmv_weapon && _status.hsAttendSeq.ind(p.rmv_weapon.linkCard[0]) >= 0) {
	                        _status.hsAttendSeq.cl(p.rmv_weapon.linkCard);
	                        delete p.rmv_weapon;
	                    }
	                };
	                df(game.me);
	                df(game.enemy);
	                game.dead = [];
	                game.dead_wp = [];
	                "step 8"
	                get.HSF("arrange");
	                game.countPlayer(fl => delete fl.truepos);
	                "step 9"
	                get.HSF("updateauras", [true]);
	                "step 10"
	                var willdie = game.dead.concat(game.me.sctp("mns")
	                    .concat([game.me.data_weapon, game.enemy.data_weapon])
	                    .filter(i => i && !i.HSF("alive"))
	                    .concat([game.me.old_weapon, game.enemy.old_weapon].filter(i => i)))
	                    .sort(lib.sort.attendseq);
	                if (willdie.length > 0) event.goto(0);
	            });
	        },
	        canatk: function(t, p, ignore) { //是否可以攻击
	            if (!p) p = t.getLeader();
	            if (!t.HSF("alive")) return false;
	            if (t.hs_atk_max + t.hs_ex_atk <= t.hs_attacked) return false;
	            if (t.summoned && !t.hasgjz("chongfeng")) return false;
	            if (_status.currentPhase != p && !ignore) return false;
	            if (t.hasgjz("dongjied") && !ignore) return false;
	            if ((t.ATK == 0 || t.noattack) && !ignore) return false;
	            return true;
	        },
	        //检查
	        checkdeck: function() { //更新牌库样式
	            if (ui.hs_medeck) {
	                if (ui.hs_medeck.forcecount === undefined || isNaN(ui.hs_medeck.forcecount)) {
	                    delete ui.hs_medeck.forcecount;
	                    ui.hs_medeck.node.count.innerHTML = ui.hs_medeck.countCards("h") + "";
	                } else ui.hs_medeck.node.count.innerHTML = ui.hs_medeck.forcecount + "";
	            }
	            if (ui.hs_enemydeck) {
	                if (ui.hs_enemydeck.forcecount === undefined || isNaN(ui.hs_enemydeck.forcecount)) {
	                    delete ui.hs_enemydeck.forcecount;
	                    ui.hs_enemydeck.node.count.innerHTML = ui.hs_enemydeck.countCards("h") + "";
	                } else ui.hs_enemydeck.node.count.innerHTML = ui.hs_enemydeck.forcecount + "";
	            }
	            if (!ui.hs_medeck.decklen) ui.hs_medeck.decklen = [];
	            if (!ui.hs_enemydeck.decklen) ui.hs_enemydeck.decklen = [];
	            var maxlen = 60;
	            var mec = parseInt(ui.hs_medeck.node.count.innerHTML);
	            if (!ui.hs_medeck.hs_working && typeof mec == "number" && !isNaN(mec) && ui.hs_medeck.decklen.length != mec) {
	                ui.hs_medeck.hs_working = true; //正在整理
	                var i = 0;
	                while (ui.hs_medeck.decklen.length != mec) {
	                    i++;
	                    if (ui.hs_medeck.decklen.length > mec) {
	                        ui.hs_medeck.decklen.pop()
	                            .delete();
	                    } else {
	                        var decklenContainer = ui.hs_medeck.querySelector(".decklencontainer");
	                        var div = ui.create.div(".decklen", decklenContainer);
	                        ui.hs_medeck.decklen.push(div);
	                        div.style.top = maxlen - 2 * ui.hs_medeck.decklen.length + "px";
	                        div.style.width = 100 - Math.floor(ui.hs_medeck.decklen.length * (0.4)) + "px";
	                    }
	                }
	                ui.hs_medeck.hs_working = false; //正在整理
	            }
	            var mec = parseInt(ui.hs_enemydeck.node.count.innerHTML);
	            if (!ui.hs_enemydeck.hs_working && typeof mec == "number" && !isNaN(mec) && ui.hs_enemydeck.decklen.length != mec) {
	                ui.hs_enemydeck.hs_working = true;
	                var i = 0;
	                while (ui.hs_enemydeck.decklen.length != mec) {
	                    i++;
	                    if (ui.hs_enemydeck.decklen.length > mec) {
	                        ui.hs_enemydeck.decklen.pop()
	                            .delete();
	                    } else {
	                        var decklenContainer = ui.hs_enemydeck.querySelector(".decklencontainer");
	                        var div = ui.create.div(".decklen", decklenContainer);
	                        ui.hs_enemydeck.decklen.push(div);
	                        div.style.top = maxlen - 2 * ui.hs_enemydeck.decklen.length + "px";
	                        div.style.width = 100 + "px";
	                    }
	                }
	                ui.hs_enemydeck.hs_working = false;
	            }
	            if (ui.hs_medeck.countCards("h") == 0) ui.hs_medeckbox.classList.add("hs_nocard");
	            else ui.hs_medeckbox.classList.remove("hs_nocard");
	            if (ui.hs_enemydeck.countCards("h") == 0) ui.hs_enemydeckbox.classList.add("hs_nocard");
	            else ui.hs_enemydeckbox.classList.remove("hs_nocard");
	        },
	        checkheroskill: function() { //更新英雄技能样式
	            if (game.me.heroskill && _status.hsgamestart) {
	                [game.me, game.enemy].forEach(i => {
	                    if (i.heroskill.forceused) {
	                        i.heroskill.classList.add("used");
	                        i.heroskill.classList.remove("selectable");
	                    } else {
	                        if (i.heroskill.usable > i.heroskill.used) i.heroskill.classList.remove("used");
	                        else i.heroskill.classList.add("used");
	                    }
	                    if (!game.me.HSF("canhrsk") || game.me.heroskill.forceused) game.me.heroskill.classList.remove("selectable");
	                    else game.me.heroskill.classList.add("selectable");
	                });
	            }
	        },
	        checkhand: function() { //更新手牌样式
	            for (var i = 1; i <= 10; i++) {
	                ui.arena.classList.remove("hs_" + i + "hand");
	            }
	            var num = game.me.countCards("h");
	            if (num > 0) ui.arena.classList.add("hs_" + num + "hand");
	            ui.updatehl();
	            if (!ui.arena.classList.contains("hs_exchange2")) get.HSF("checkhand2");
	        },
	        checkhand2: function() { //仅手牌费用
	            game.me.countCards("h", c => {
	                if (["HS_minor", "HS_spell", "HS_weapon"].contains(get.type(c))) {
	                    var info = get.info(c);
	                    var co = info.cost;
	                    var cost = c.cost();
	                    if (cost < co) {
	                        c.mana.classList.remove("hs_smaller");
	                        c.mana.classList.add("hs_larger");
	                    } else if (cost > co) {
	                        c.mana.classList.remove("hs_larger");
	                        c.mana.classList.add("hs_smaller");
	                    } else {
	                        c.mana.classList.remove("hs_smaller");
	                        c.mana.classList.remove("hs_larger");
	                    }
	                    var n = parseInt(c.mana.innerHTML);
	                    c.mana.innerHTML = cost;
	                    if (n != cost) c.mana.animate("hs_start");
	                    if (get.type(c) == "HS_minor") info = lib.skill[c.name.split("_monster")[0]];
	                    if (get.type(c) == "HS_weapon") info = c.HSF("info");
	                    if (info && info.active && info.active(game.me, c)) c.classList.add("active");
	                    else c.classList.remove("active");
	                }
	            });
	        },
	        checkcanatk: function(param) { //更新攻击随从
	            var fc = t => {
	                var p = t.getLeader();
	                var res = get.HSF("canatk", [t, p]);
	                if (res && p == game.me) t.classList.add("attackable");
	                else t.classList.remove("attackable");
	            }
	            game.me.getFellowN(fc);
	            game.enemy.getFellowN(fc);
	            if (ui.hs_enemycount) {
	                if (game.enemy.countCards("h") == 0) ui.hs_enemycount.hide();
	                else ui.hs_enemycount.show();
	            }
	        },
	        checkfellow: function() { //更新随从状态
	            game.countPlayer(function(i) {
	                i.updatehsfl();
	            });
	            //更新武器
	            var upweapon = function(p) {
	                var upweapon2 = function(wp, p) {
	                    if (wp) {
	                        var o = wp.hs_calcv(false);
	                        wp.ATK = o[0];
	                        wp.hp = o[1];
	                        var fu = function(a, b, wp) {
	                            var rval = parseInt(a.innerHTML);
	                            a.innerHTML = b;
	                            if (a.classList.contains("hs_wp_atk")) {
	                                if (b > wp.baseATK) a.classList.add("hs_larger");
	                                else a.classList.remove("hs_larger");
	                            } else {
	                                if (wp.hs_dm > 0) {
	                                    a.classList.remove("hs_larger");
	                                    a.classList.add("hs_smaller");
	                                } else {
	                                    if (wp.hp > wp.baseHp) {
	                                        a.classList.add("hs_larger");
	                                        a.classList.remove("hs_smaller");
	                                    } else {
	                                        a.classList.remove("hs_larger");
	                                        a.classList.remove("hs_smaller");
	                                    }
	                                }
	                            }
	                            if (rval != b) a.animate("hs_start");
	                        }
	                        fu(wp.node.atk, wp.ATK, wp);
	                        fu(wp.node.hp, wp.hp, wp);
	                        if (wp == p.data_weapon) {
	                            if (_status.currentPhase == p && !wp.willdie) {
	                                wp.swt(true);
	                                wp.node.atk.show();
	                            } else {
	                                wp.swt(false);
	                                wp.node.atk.hide();
	                            }
	                        }
	                        wp.hs_judge();
	                        wp.HSF("uptris");
	                    }
	                };
	                upweapon2(p.data_weapon, p);
	                upweapon2(p.predata_weapon, p);
	            };
	            upweapon(game.me);
	            upweapon(game.enemy);
	            game.me.HSF("hsdouble");
	            game.enemy.HSF("hsdouble");
	        },
	        checkall: function(arr) { //更新所有内容
	            if (!arr) arr = ["deck", "hand", "heroskill", "canatk", "fellow"];
	            else if (arguments.length > 1) arr = Array.from(arguments);
	            arr.forEach(i => {
	                get.HSF("check" + i);
	            });
	        },
	        checkwin: function(e, next) { //胜负判定
	            var f = lib.element.content.checkwin;
	            if (next) e.insert(f);
	            else e.insertAfter(f);
	        },
	        //界面生成
	        surrender: function() {
	            lib.skill.hs_surrender = {
	                enable: "phaseUse",
	                filter: function() {},
	                content: function() {
	                    if (confirm("是否真的要投降？")) {
	                        game.me.HSFT("投降");
	                        game.me.die();
	                    }
	                },
	            };
	            return lib.skill.hs_surrender.content;
	        },
	        nextduel: function() {
	            return function() {
	                ui.create.control('下一局', function() {
	                    game.save('directStage', ["炉石普通", 0], 'brawl');
	                    localStorage.setItem(lib.configprefix + 'directstart', true);
	                    game.reload();
	                });
	            }
	        },
	        morezone: function() { //制作详情区
	            ui.morezone = ui.create.div(".morezone", ui.arena);
	            ui.morezone.hide();
	            var hsdetail = ui.create.player(ui.morezone, true);
	            hsdetail.hide();
	            hsdetail.listen(function() {
	                this.HSF("morefocus");
	            });
	            hsdetail.classList.add("hsdetail");
	            hsdetail.node.avatar.style.backgroundSize = "cover";
	            hsdetail.node.avatar.show();
	            hsdetail.hide();
	        },
	        morefocus: function(node, long) { //设置详情区卡牌
	            //无变化
	            if (!ui.morezone) return;
	            if (ui.arena.classList.contains("hs_exchange")) return;
	            if (_status.currentPhase == game.me) {
	                if (get.itemtype(node) == "card") {
	                    if (game.me.HSF("phaseUse") && get.position(node) == "h" && !long) return;
	                } else if (get.itemtype(node) == "player") {
	                    if (!game.me.HSF("phaseUse")) return;
	                }
	            }

	            //默认在左边显示，无过场动画
	            ui.morezone.classList.remove("viewhand");
	            ui.morezone.style.transition = "all 0s";
	            clearTimeout(ui.morezone.hidetmt);
	            var g = function() { //清除长按记录
	                game.me.countCards("h", ca => {
	                    delete ca.islong;
	                });
	            };
	            var f = function() { //隐藏详情区
	                g();
	                clearTimeout(ui.morezone.hidetmt);
	                ui.morezone.hide();
	                delete ui.morezone.current;
	            }
	            var div = ui.morezone.querySelector(".hsdetail");
	            var name;
	            //如果点详情区、点自己，隐藏详情区
	            if (node == div) {
	                return f();
	            }
	            if (get.itemtype(node) == "card") {
	                if (get.position(node) == "h" && _status.currentPhase == game.me && game.me.HSF("phaseUse") && long) ui.morezone.classList.add("viewhand");
	                else {
	                    ui.morezone.classList.remove("viewhand");
	                    delete _status.hs_viewing;
	                    g();
	                }
	            } else if (get.itemtype(node) == "player") {
	                if (!node.name || !node.isMin()) {
	                    return f();
	                }
	            } else if (get.itemtype(node) == "button") {
	                get.HSF("morefocus", [node.link]);
	                return;
	            } else if (node.classList.contains("hs_hrsk")) {
	                name = node.skill.replace("legend_", "");
	            } else {
	                return f();
	            }
	            //显示详情区，若不是长按，2秒后隐藏
	            ui.morezone.show();
	            node.f = f;
	            div.show();
	            var card = node.linkCard ? node.linkCard[0] : node;
	            name = name || card.name;
	            if (!node.islong) ui.morezone.hidetmt = setTimeout(f, 2000);
	            if (ui.morezone.current && ui.morezone.current == name) {
	                return;
	            }
	            if (get.itemtype(card) == "card") {
	                if (get.type(card) == "HS_minor") {
	                    div.classList.remove("hs_view");
	                    div.init(get.HSF("tr", [name]));
	                    if (get.info(card)
	                        .hs_diy || name.indexOf("PT_monster") > 0) div.classList.add("hs_DIYfl");
	                    else div.classList.remove("hs_DIYfl");
	                } else {
	                    div.classList.remove("hs_DIYfl");
	                    div.classList.add("hs_view");
	                    div.node.avatar.setBackgroundImage("extension/炉石普通/card/" + name + ".jpg");
	                }
	            } else {
	                var dire = "heroskill";
	                if (name.indexOf("hs_leader") == 0) dire = "boss";
	                div.node.avatar.setBackgroundImage("extension/炉石普通/image/" + dire + "/" + name + ".jpg");
	            }
	            ui.morezone.current = name;
	        },
	        tr: function(a) {
	            var num = a.indexOf("_monster");
	            if (num < 0) return a + "_monster";
	            else return a.slice(0, num);
	        },
	        outputRD: function(num) {
	            var deck = get.HSF("readD", [game.me.name]);
	            if (!num || num == 1) return deck;
	            else if (num == 2) {
	                var str = "";
	                for (var i = 0; i < deck.length; i++) {
	                    if (i > 0) str += ",\n";
	                    str += "				" + "\"" + deck[i] + "\"";
	                }
	                return str;
	            }
	        },
	        readD: function(name) {
	            var res = lib.storage.hs_deck[name] || [];
	            if (!res.length) {
	                get.hs_alt("找不到卡组数据");
	                return;
	            }
	            if (res[0].contains("hs_")) {
	                get.HSF("saveDeck", [game.me.name, res]);
	                return get.HSF("readD", [name]);
	            }
	            return get.copy(res);
	        },
	        jiag: function(deck) { //旧卡组转新卡组
	            var res = [];
	            for (var i = 0; i < deck.length; i++) {
	                var temp = deck[i];
	                var num = get.HSF("count", [deck, temp]);
	                res.push(get.translation(temp) + "*" + num);
	                for (var j = 0; j < num; j++) {
	                    deck.remove(temp);
	                }
	                i = -1;
	            }
	            return res;
	        },
	        getEN: function(arg, multi) { //由卡牌中文名获取卡牌英文名
	            if (multi) var res = [];
	            for (var i in lib.card) {
	                if (["HS_minor", "HS_spell", "HS_secret", "HS_weapon"].contains(get.type(i)) && get.translation(i) == arg) {
	                    if (multi) res.add(i);
	                    else {
	                        var ispt = function(m, bo) {
	                            if (get.type(m) == "HS_minor") {
	                                if (m.contains("PT_monster")) return true;
	                                if (bo && !lib.card[m.replace("_monster", "PT_monster")]) return true;
	                            } else {
	                                if (m.slice(-2) == "PT") return true;
	                                if (bo && !lib.card[m + "PT"]) return true;
	                            }
	                            return false;
	                        };
	                        if (get.hs_nm() == 7 && ispt(i)) continue;
	                        if (get.hs_nm() == 3 && !ispt(i, true)) continue;
	                        if (lib.card[i].nosearch) continue;
	                        return i;
	                    }
	                }
	            }
	            if (multi && res.length) return res;
	            var r2 = get.HS_trans(arg);
	            if (r2) return get.HSE(r2, multi);
	            else {
	                get.hs_alt("getEN:" + arg + "可能不是游戏中的牌！改为树人😉");
	                return "hs_Treant1_monster";
	            }
	        },
	        getEN2: function(arg) {
	            var res = get.HSE(arg);
	            if (res.contains("_monster")) return res.split("_monster")[0];
	            return res;
	        },
	        作弊: function(type, arg, p) { //你作弊
	            if (ui.arena.classList.contains("hs_exchange")) {
	                get.hs_alt("作弊：调度阶段不允许作弊！");
	                return;
	            }
	            var name;
	            p = p || game.me;
	            if (arg) {
	                if (type == "水晶") p.HSF("gainmana", [arg]);
	                else if (type == "武器") p.hs_weapon(arg);
	                else {
	                    if (type == "获得") name = get.HSE(arg);
	                    if (type == "获得" && name) p.directgain([get.chscard(name)]);
	                    else if (type == "特召") {
	                        p.SSfellow(arg);
	                    } else if (type == "强化") {
	                        p.countFellow(fl => {
	                            fl.addvaluebuff([arg, arg]);
	                        });
	                        get.HSF("checkfellow");
	                    } else if (type == "异能") {
	                        p.countFellow(fl => {
	                            fl.addgjzbuff(arg);
	                        });
	                        get.HSF("checkfellow");
	                    }
	                }
	            }
	            return name;
	        },
	        作弊2: function(type, arg) { //电脑作弊
	            return get.HSF("作弊", [type, arg, game.enemy]);
	        },

	        //计算
	        attackact: function(atk, def) { //计算攻击位置
	            var a = atk.offsetHeight;
	            var b = def.offsetTop;
	            var c = atk.offsetTop;
	            var d = def.offsetHeight;
	            var e = def.offsetLeft;
	            var f = atk.offsetLeft;
	            var g = atk.offsetWidth;
	            var h = def.offsetWidth;
	            var x = e - f,
	                y = b - c;
	            var xx = y + (d - a) / 2,
	                yy = x + (h - g) / 2;
	            var r = Math.pow(Math.pow(xx, 2) + Math.pow(yy, 2), 0.5);
	            var rat = 1 - a / 2 / r;
	            return [xx * rat, yy * rat];
	        },
	        saveDeck: function(p, d) {
	            if (d[0].contains("hs_")) lib.storage.hs_deck[p] = get.HSF("jiag", [d]);
	            else lib.storage.hs_deck[p] = d;
	            game.save("hs_deck", lib.storage.hs_deck);
	        },
	        fff: function(n) { //根据卡名(未处理的)，获取怪兽的描述
	            var str = "";
	            var list = lib.hearthstone.cardPack.monsterRD[n];
	            if (!list) return str;
	            var intro = list[2];
	            intro = (function(s) {
	                var li = get.HSA("jiacu");
	                for (var w of li) {
	                    s = s.replace((new RegExp(w, "g")), "<b>" + w + "</b>");
	                }
	                var li = get.HSA("rkind");
	                for (var w in li) {
	                    s = s.replace((new RegExp(w, "g")), "<b>" + w + "</b>");
	                }
	                return s;
	            })(intro);
	            var info = list[3];
	            if (!info || !info.length || info.length < 6) return str;
	            var func = function(type) {
	                if (["HS_normal", "HS_effect"].contains(type)) {
	                    return "/" + get.HS_trans(type) + "/" + get.HS_trans(info[2] || "hs_neutral") + "/" + get.HS_trans(list[1]);
	                }
	            };
	            str += "费用 " + info[1] + "<br>" + get.HS_trans(info[3]) + func(info[0]) + "<br>" + intro + "<br>攻击 " + info[4] + " 血量 " + info[5];
	            return str;
	        },
	        arrstr: function(val) { //数组转字符串
	            val = val.map(i => typeof i == "string" ? `
	            "${i}"` : i);
	            return "[" + val.join(",") + "]";
	        },
	    };
	    for (var i in funcs) {
	        hearthstone.funcs[i] = funcs[i];
	    }
	    var getFs = {
	        hslegend: function(card) { //是否传说
	            if (get.itemtype(card) == "card") return get.rall(obj, 'rarity') == 'legend';
	            else if (get.itemtype(card) == "player") return get.rall(card.name + "_monster", 'rarity') == 'legend';
	        },
	        rall: function(obj, key) { //获取卡牌信息
	            if (!obj) return null;
	            var str;
	            if (get.itemtype(obj) == "card") str = obj.name;
	            else str = obj;
	            var info = get.info({
	                name: str
	            });
	            if (!info) return null;
	            if (!key) return info;
	            return info[key];
	        },
	        hs_main: function() { //获取主玩家
	            return _status.hsbo ? game.me : game.enemy;
	        },
	        chsinit: function(card) { //卡牌初始化
	            card.cost = lib.element.card.cost;
	            var cf = ["HSF", "addhsbuff", "addvaluebuff", "addtriggerbuff", "addgjzbuff", "hasgjz"];
	            cf.forEach(i => {
	                card[i] = game.me[i];
	            });
	            if (["HS_minor", "HS_spell", "HS_weapon"].contains(get.type(card))) card._destroy = "true"; //不进入弃牌堆
	            card.buff = [];
	            card.triggers = {};
	            card.classList.add("rdcreated");
	            var name = card.name;
	            card.mana = ui.create.div(".hs_mana", card);
	            card.mana.innerHTML = get.info(card)
	                .cost;
	            card.setBackgroundImage('extension/炉石普通/card/' + name + '.jpg');
	            var evt = function(long) {
	                var that = this;
	                if (long === true) {
	                    get.HSF("morefocus", [that, true]);
	                } else ui.morezone.hide();
	                if (get.position(that) == "h" && long !== true && game.me.HSF("phaseUse")) {
	                    delete _status.hs_viewing;
	                    if (!lib.filter.filterCard(that)) {
	                        if (that.cost() > game.me.HSF("mana")) game.me.HSFT("错误1");
	                        else if (get.type(that) == "HS_minor" && game.me.hs_full()) game.me.HSFT("错误2");
	                        else game.me.HSFT("错误3");
	                    }
	                }
	            };
	            card.listen(evt);
	            if (lib.device) card.HSF("longP", [function() {
	                this.islong = true;
	                if (_status.currentPhase == game.me) {
	                    _status.hs_viewing = true;
	                    get.HSF("clickmana", [true]);
	                }
	                evt.call(this, true);
	            }]);
	            var df = function(e) {
	                var that = _status.hs_mousecard || this;
	                if (!that.classList) {
	                    console.log(that);
	                    return;
	                }
	                if (!lib.config.enable_drag) return;
	                if (!that.classList.contains("selectable")) return;
	                if (_status.hs_mousedown === false) return;
	                get.HSF("hs_stopview");
	                if (get.type(that) == "HS_minor") {
	                    if (_status.currentPhase != game.me || !game.me.HSF("phaseUse")) return;
	                    _status.hs_fldragging = ui.selected.cards.length == 1;
	                    if (_status.hs_fldragging) {
	                        game.me.HSF("hsdouble");
	                        var dx = (e.touches ? e.touches[0] : e)
	                            .clientX;
	                        var num = get.HSF("dragposition", [dx]);
	                        ui.hs_testfl.num = num;
	                        ui.hs_testfl.dataset.position = num + "";
	                        get.HSF("arrange");
	                    } else {
	                        game.me.HSF("hsdouble");
	                        ui.hs_testfl.dataset.position = "d0";
	                        get.HSF("arrange");
	                    }
	                } else if (get.type(that) == "HS_spell") {
	                    if (ui.arena.classList.contains("hs_view")) {
	                        get.HSF("clickmana", [false]);
	                        _status.hs_tempshq = that;
	                        that.classList.add("selected");
	                    }
	                }
	            };
	            if (lib.device) card.addEventListener("touchmove", df);
	            else {
	                _status.hs_mousedown = false;
	                card.addEventListener("mousedown", function() {
	                    _status.hs_mousedown = true;
	                    _status.hs_mousecard = this;
	                });
	                document.addEventListener("mousemove", df);
	                document.addEventListener("mouseup", function() {
	                    _status.hs_mousedown = false;
	                    delete _status.hs_mousecard;
	                });
	            }
	        },
	        chscard2: function(name) { //制作一张卡(已知英文名)
	            if (!name) {
	                get.hs_alt("chscard2:必须传入卡牌名称");
	                return;
	            }
	            if (typeof name != "string") {
	                if (Array.isArray(name) && typeof name[0] == "string") {
	                    var res = [];
	                    for (var i = 0; i < name.length; i++) {
	                        var c = get.chscard2(name[i]);
	                        if (c) res.add(c);
	                    }
	                    return res;
	                } else {
	                    get.hs_alt("chscard2:输入的内容不合法");
	                    return;
	                }
	            }
	            var isCN = function(temp) {
	                var re = /[\u4e00-\u9fa5]/;
	                return re.test(temp);
	            }
	            if (isCN(name)) {
	                get.hs_alt("chscard2:必须传入卡牌的英文名称");
	                return;
	            }
	            var card = game.createCard(name, "spade", 1);
	            get.chsinit(card);
	            return card;
	        },
	        hs_pos: function(obj) { //获取所在区域
	            if (!obj) get.hs_alt("hs_pos:", obj);
	            if (get.itemtype(obj) == "player") {
	                if (game.players.contains(obj)) return "minors";
	                else get.hs_alt("hs_pos:", obj);
	            } else {
	                if (game.me.getCards(h)
	                    .concat(game.enemy.getCards(h))
	                    .contains(obj)) return "hand";
	                else if (game.me.cardPile.getCards(h)
	                    .concat(game.enemy.cardPile.getCards(h))
	                    .contains(obj)) return "deck";
	                else if (game.me.discardPile.getCards(h)
	                    .concat(game.enemy.discardPile.getCards(h))
	                    .contains(obj)) return "grave";
	                else if (game.me.heroskill.pos.getCards(h)
	                    .concat(game.enemy.heroskill.pos.getCards(h))
	                    .contains(obj)) return "release";
	                else get.hs_alt("hs_pos:", obj);
	            }
	        },
	        hs_alt: function() { //内部调试弹窗
	            alert.apply(window, [
	                [""].concat(Array.from(arguments))
	                    .join("")]);
	        },
	        hs_id: function(obj, obj2) { //卡牌编号(作用：连系随从和卡牌，减少内存)
	            if (obj2) return get.hs_id(obj) == get.hs_id(obj2);
	            if (obj.length === 0) return;
	            var str = get.itemtype(obj);
	            if (str == "card") return obj.cardid;
	            else if (str == "player") {
	                if (!obj.linkCard) return obj.playerid;
	                else return obj.linkCard[0].cardid;
	            } else if (obj.stid) return obj.stid;
	            else if (obj.relabuff) return obj.relabuff.stid;
	            else if (obj.wpid) return obj.wpid;
	            else if (obj.id) return obj.id;
	            else {
	                //get.hs_alt("hs_id:类型不为card或player，也不为实体");
	                console.log("hs_id:类型不为card或player，也不为实体");
	                console.log(obj);
	            }
	        },
	        dmgEffect: function(t, p, v, num) { //获取伤害效果
	            num = num || 1;
	            if (v == t) {
	                if (t.hasgjz("mianyi")) return 0;
	                if (!t.isMin()) {
	                    if (num > t.hp) return -10000;
	                    else return -num;
	                }
	                if (t.hasgjz("shengdun")) return -1;
	                var base = t.ATK + t.hp;
	                if (t.triggers.deathRattle && t.hp <= num) base = 1;
	                if (t.triggers.hsdmg && t.triggers.hsdmg.fl) base = Math.max(1, t.hp - num);
	                if (num < t.hp) base -= t.ATK + t.hp - num;
	                return -base;
	            } else if (v == p) {
	                var n = get.dmgEffect(t, p, t, num);
	                if (t.getLeader() == v) return n;
	                else return -n;
	            }
	        },
	        rcvEffect: function(t, p, v, num) { //获取治疗效果
	            num = num || 1;
	            if (p.hasAuras("auchenai")) return get.dmgEffect(t, p, v, num) + 0.1;
	            else {
	                if (v == t) {
	                    if (!t.isDamaged()) return 0;
	                    return Math.min(num, t.getDamagedHp()) + 0.1;
	                } else if (v == p) {
	                    var n = get.rcvEffect(t, p, t, num);
	                    if (t.getLeader() == v) return n + 0.1;
	                    else return -n;
	                }
	            }
	        },
	        hsflt: function(filter, only) { //对卡牌的极速筛选，返回筛选函数
	            if (!filter) return lib.filter.all;
	            if (typeof filter == "function") return filter;
	            var str = "if(get.type(obj)!='HS_minor')return false;";
	            if (typeof filter == "string") {
	                if (filter == "传说") str += "if(get.rall(obj,'rarity')!='legend')return false;";
	                else if (get.HSAT("easy")[filter]) {
	                    var job = get.HSAT("easy")[filter];
	                    str += "if(get.rall(obj,'rnature')!='" + rkind + "')return false;";
	                } else if (get.HSAT("rkind")[filter]) {
	                    var rkind = get.HSAT("rkind")[filter];
	                    str += "if(get.rall(obj,'rkind')!='" + rkind + "')return false;";
	                } else if (get.HSA("yineng")[filter]) {
	                    var yn = get.HSA("yineng")[filter];
	                    str += "if(!get.rGJZ(obj,'" + yn + "'))return false;";
	                }
	            } else if (typeof filter.length == "number") {
	                for (var i = 0; i < filter.length; i++) {
	                    var val = filter[i];
	                    if (typeof val == "number") str += get.hsflt_level(val);
	                    else if (parseInt(val) > 0) str += get.hsflt_level(parseInt(val));
	                    else str += get.hsflt(val, true);
	                }
	            } else if (typeof filter == "object") {
	                for (var i in filter) {
	                    var val = filter[i];
	                    if (["cost", "ATK", "HP"].contains(i)) str += get.hsflt_level(val, i);
	                    else {
	                        if (Array.isArray(val)) str += "if(!" + get.HSF("arrstr", [val]) + ".contains(get.rall(obj,'" + i + "')))return false;";
	                        else str += "if(get.rall(obj,'" + i + "')!='" + val + "')return false;";
	                    }
	                }
	            }
	            if (only) return str;
	            str += "return true;";
	            return get.strfunc("obj", str);
	        },
	        hsflt_level: function(val, key) { //数字范围的筛选函数
	            key = key || "cost";
	            if (val % 1 == 0) return "if(get.rall(obj,'" + key + "')!=" + val + ")return false;";
	            var lim = Math.round(val);
	            var bo = lim > val ? "<" : ">";
	            var bo2 = Math.abs(val - lim) < 0.3 ? "=" : "";
	            return "if(!get.rall(obj,'" + key + "')" + bo + bo2 + lim + "))return false;";
	        },
	        hs_deck: function(player) { //给角色配卡组
	            var str = player.name + "_ai";
	            var deck = lib.storage.hs_deck[str].slice(0);
	            var cfg = get.HSF("cfg", ["HS_aideck"]);
	            if ((player == game.me || cfg == "yourdeck") && lib.storage.hs_deck[player.name]) deck = lib.storage.hs_deck[player.name].slice(0);
	            player.deckCards = [];
	            player.extraCards = [];
	            deck.forEach(i => {
	                var cs = get.hs_deck2(i);
	                player.deckCards.addArray(cs);
	            });
	            return [player.deckCards, player.extraCards];
	        },
	        hs_deck2: function(old) { //兼容新旧卡组格式
	            var put = [];
	            if (old.contains("*")) {
	                var yh = 0;
	                var arr = old.split("*");
	                var num = parseInt(arr[1]);
	                for (var i = 0; i < num; i++) {
	                    var card = get.chscard(arr[0], true, yh);
	                    if (card) put.push(card);
	                    else get.hs_alt('卡牌"' + arr[0] + '"不存在！');
	                }
	            } else put.push(get.chscard(old));
	            return put;
	        },
	        HSV: function(name, def) { //获取炉石变量存储
	            if (!name) return lib.hearthstone.custom;
	            if (def != undefined && lib.hearthstone.custom[name] == undefined) lib.hearthstone.custom[name] = def;
	            return lib.hearthstone.custom[name];
	        },
	        HSVV: function(name, def) { //获取炉石变量存储
	            if (!name) return lib.hearthstone.ranvv;
	            if (def != undefined && lib.hearthstone.ranvv[name] == undefined) lib.hearthstone.ranvv[name] = def;
	            return lib.hearthstone.ranvv[name];
	        },
	        hskachi: function(tp, func, token) { //获取当前模式卡池
	            if (!func) func = () => true;
	            var kachi = get.hscardpool();
	            if (tp != "all") kachi = kachi.filter(i => get.type(i) == tp || get.subtype(i) == tp);
	            if (get.hs_nm() == 7) {
	                kachi = kachi.filter(i => {
	                    if (get.type(i) == "HS_minor") return i.indexOf("PT_monster") < 0;
	                    else return i.slice(-2) != "PT";
	                });
	            } else {
	                kachi = kachi.filter(i => {
	                    if (get.type(i) == "HS_minor") return !lib.card[i.replace("_monster", "PT_monster")];
	                    else return !lib.card[i + "PT"];
	                });
	            }
	            kachi = kachi.filter(i => {
	                var info = get.info({
	                    name: i
	                });
	                if (!token && (info.hs_tokened || info.hs_token)) return false;
	                return func(i, info);
	            });
	            return kachi;
	        },
	        hscardpool: function(func) { //获取卡池
	            if (!func) func = () => true;
	            var kachi = lib.hearthstone.cardPack.mode_RD.concat(lib.hearthstone.cardPack.spel_RD)
	                .concat(lib.hearthstone.cardPack.trap_RD)
	                .concat(lib.hearthstone.cardPack.weap_RD);
	            return kachi.filter(func)
	                .sort(lib.sort.hs_duel);
	        },
	        hscardback: function(player) { //获取卡背路径
	            var str = "炉石普通/cardback/";
	            if (_status.brawlboss == player.name && _status.brawlcardback) return str + _status.brawlcardback + ".jpg";
	            if (player == game.enemy && get.HSF("cfg", ["HS_enemycardback"]) == "random") {
	                if (!_status.enemycb) _status.enemycb = Object.keys(_status.hsextra)
	                    .randomGet();
	                return str + _status.enemycb + ".jpg";
	            }
	            var cr;
	            var cb = get.HSF("cfg", ["hscardback"]);
	            cr = (!cb || cb == "default") ? "经典卡背" : cb;
	            return str + cr + ".jpg";
	        },
	    };
	    for (var i in getFs) {
	        hearthstone.get[i] = getFs[i];
	    }

	    var playerFs = {
	        //新增
	        toNTRed: function(pre, tmp) { //控制权转移
	            if (!this.isMin()) return;
	            if (!this.HSF("alive")) return;
	            this.summoned = true;
	            var player = this.getLeader();
	            if (player == pre) return;
	            var next = game.createEvent("toNTRed");
	            next.fellow = this;
	            next.player = player;
	            next.tmp = tmp;
	            next.setContent(function() {
	                "step 0"
	                game.delay(0.5);
	                "step 1"
	                var pre = player.getOppo();
	                if (pre.hs_full()) {
	                    event.fellow.HSF("cuihui");
	                    event.fellow.hide();
	                    game.players.remove(event.fellow);
	                    game.dead.add(event.fellow);
	                    player.actcharacterlist.remove(event.fellow);
	                    get.HSF("arrange");
	                    get.HSF("updateauras", [true]);
	                    return;
	                }
	                var m = pre.countFellow();
	                var n = pre == game.me ? 0 : get.hs_nm();
	                var pos = m + n + 2;
	                pre.hs_place(pos);
	                event.fellow.dataset.position = pos + "";
	                event.fellow.dataset.enemy = pre.dataset.enemy;
	                event.fellow.side = pre.side;

	                player.actcharacterlist.remove(event.fellow);
	                pre.actcharacterlist.add(event.fellow);

	                get.HSF("arrange");
	                if (event.tmp) {
	                    var obj = event.fellow.addgjzbuff("chongfeng", 1);
	                    obj.name = "aykl";
	                    obj.onremove = function(p) {
	                        p.toNTRed();
	                    };
	                    event.fellow.addtriggerbuff({
	                        info: {
	                            ending: {
	                                effect: function() {
	                                    event.fellow.removehsbuff(event.fellow.findhsbuff("aykl"));
	                                    event.fellow.removehsbuff(event.obj.relabuff);
	                                },
	                            },
	                        }
	                    });
	                }
	            });
	            return next;
	        },
	        hs_join: function(cards) { //(手牌)置入战场
	            var next = game.createEvent("hs_join", false);
	            next.player = this;
	            next.cards = cards;
	            next.setContent(function() {

	            });
	            return next;
	        },
	        hs_revive: function(cards) { //复活随从
	            var next = game.createEvent("hs_revive", false);
	            next.fellow = this;
	            next.player = this.getLeader();
	            next.cards = cards;
	            next.setContent(function() {
	                if (!cards) cards = function(p, a) {
	                    return a[p.playerid].randomGet();
	                }
	                if (typeof cards == "function") {
	                    cards = cards(player, _status.hs_dead_All, _status.hs_dead[player.playerid]);
	                }
	                if (!cards || !cards.length) {
	                    event.finish();
	                    return;
	                }
	                event.fellow.SSfellow(cards, undefined, "落地", ["复活"]);
	            });
	            return next;
	        },
	        hs_compare: function(callback) { //拼点
	            var next = game.createEvent("hs_compare", false);
	            next.player = this;
	            next.target = this.getOppo();
	            next.callback = callback;
	            next.setContent(function() {
	                "step 0"
	                event.cs1 = player.cardPile.getCards("h", {
	                    type: "HS_minor"
	                });
	                event.cs2 = target.cardPile.getCards("h", {
	                    type: "HS_minor"
	                });
	                event.result = {
	                    bool: false
	                };
	                if (!event.cs1.length) event.goto(3);
	                else if (!event.cs2.length) event.goto(2);
	                else {
	                    event.c1 = event.cs1.randomGet();
	                    event.n1 = event.c1.cost();
	                    event.c2 = event.cs2.randomGet();
	                    event.n2 = event.c2.cost();
	                    player.$compare(event.c1, target, event.c2);
	                    setTimeout(function() {
	                        ui.clear();
	                    }, 3000);
	                    game.delay(2);
	                }
	                "step 1"
	                if (event.n1 <= event.n2) event.goto(3);
	                "step 2"
	                event.result.bool = true;
	                get.HSF("morefocus", [event.c1]);
	                if (event.callback) event.callback(player, event);
	                "step 3"
	                player.hs_sort();
	                target.hs_sort();
	            });
	            return next;
	        },
	        hs_shaohui: function(num) { //烧毁牌库
	            if (num === undefined) num = 1;
	            num = Math.max(0, num);
	            if (num == 0) return;
	            var that = this;
	            var deck = that.cardPile;
	            if (deck.countCards("h")) {
	                var next = game.createEvent("hs_shaohui", false);
	                next.player = that;
	                next.deck = deck;
	                next.deck2 = that.discardPile;
	                next.num = num;
	                next.setContent(function() {
	                    "step 0"
	                    event.i = 0;
	                    "step 1"
	                    event.cards = event.deck.getCards("h")
	                        .slice(0, 1);
	                    event.deck2.$throw(event.cards);
	                    "step 2"
	                    game.log(player, "的", event.cards, "被摧毁了！");
	                    player.heroskill.pos.directgain(event.cards);
	                    game.delay(0.5);
	                    "step 3"
	                    event.i++;
	                    if (event.i < event.num && event.deck.countCards("h")) event.goto(1);
	                    "step 4"
	                    ui.clear();
	                });
	            }
	        },
	        isSGS: function() { //是三国杀武将
	            return get.translation(this.group)
	                .length == 1;
	        },
	        hs_rcdh: function(pos, left, dh, anm2, dft) { //入场动画
	            var fellow = this;
	            var p = fellow.getLeader();
	            var anm = dh;
	            fellow.hide();
	            var dcfs = { //
	                飞入: (function() {
	                    var init = lib.hearthstone.hs_sczb; //中间随从的左边
	                    var width = lib.hearthstone.hs_scjj; //随从间距
	                    var m = p.countFellow();
	                    var n = p == game.me ? 0 : get.hs_nm();
	                    return "translateY(-450px) translateX(" + (800 + (m - (pos - n - 1)) * width) + "px)";
	                })(),
	                降落: "translateY(-450px)",
	                报告: "translateX(700px)",
	                火车王: "translateX(700px)",
	                冒出: ["perspective(10px) translateZ(-100px)", "perspective(100px) translateZ(10px)"],
	                呼出: (function() {
	                    return "translateX(" + (left ? "" : "-") + "100px) scale(0.4)";
	                })(),
	                落地: "perspective(100px) translateY(-20px) translateZ(50px)",
	                旋落: "perspective(100px) translateZ(40px) rotate(270deg)",
	            };
	            if (!dh) {
	                if (anm2) anm = anm2;
	                else {
	                    var ca = null;
	                    var al = get.HSA("anms");
	                    for (var i in al) {
	                        if (al[i].contains(get.translation(fellow.name))) {
	                            ca = i;
	                            break;
	                        }
	                    }
	                    if (ca) anm = ca;
	                    else anm = dft;
	                }
	            }
	            var tm = get.HSA("anmstm")[anm] || 700;
	            var str = dcfs[anm];
	            if (typeof str == "string") str = [str, ""];
	            fellow.style.transform = str[0];
	            setTimeout(function() {
	                fellow.show();
	                fellow.style.transform = str[1];
	                setTimeout(function() {
	                    fellow.style.transform = "";
	                }, 300)
	            }, get.hslegend(fellow) ? 1200 : tm);
	            return [anm, tm];
	        },
	        hs_animate: function(value, time, func) { //创建临时动画
	            var that = this;
	            func = func || "";
	            var name = "divcls" + get.rand(1, 1000) + "f" + get.rand(1, 1000) + "_" + that.classList[0];
	            var str = ".newys{animation:" + name + " " + time / 1000 + "s " + func + ";}@keyframes " + name + "{" + value + "}";
	            _status.customcss += str;
	            if (!_status.customcss_e) {
	                _status.customcss_e = document.createElement("style");
	                document.head.appendChild(_status.customcss_e);
	            }
	            _status.customcss_e.innerHTML = _status.customcss;
	            that.animate(name, time);
	        },
	        hs_sort: function() { //牌堆洗牌
	            var that = this;
	            if (that.parentNode == ui.arena) {
	                that = that.getLeader();
	                that.cardPile.hs_sort();
	            } else {
	                var ms = that.getCards("h");
	                if (ms.length) {
	                    ms.randomSort();
	                    ms.forEach(i => {
	                        that.node.handcards1.insertBefore(i, that.node.handcards1.firstChild);
	                    });
	                }
	            }
	        },
	        //随机条件
	        canhsdmg: function(ignore) { //能成为随机伤害目标
	            var pre = this.HSF("alive", [ignore]);
	            return pre && !(this.hp == 1 && this.aurasEffed("hs_mlnh"));
	        },
	        addweapon: function(card) { //武器显示
	            var that = this;
	            card.buff = [];
	            card.triggers = {};
	            card.equiping = that;
	            var mark = that == game.me ? "me" : "enemy";
	            var div = ui.create.div(".hs_wp" + "." + mark + "wp", ui.arena);
	            for (var i in lib.element.player) {
	                div[i] = lib.element.player[i];
	            }
	            div.side = that.side;
	            div.hs_dmgrcv = function(num, type) {
	                var that = this;
	                num = num || 1;
	                type = type || "damage";
	                if (type == "damage" && that.hasgjz("wpmianyi")) return;
	                if (type == "recover") num = -num;
	                that.hs_dm += num;
	                get.HSF("checkfellow");
	            };
	            div.swt = function(bo) {
	                if (this.classList.contains("kaiqiao") != bo) {
	                    this.animate("doudong", 200);
	                    if (bo) this.classList.add("kaiqiao");
	                    else this.classList.remove("kaiqiao");
	                }
	            }
	            div.HSline = game.me.HSline;
	            card.divweapon = div
	            div.equiping = that;
	            div.name = card.name;
	            div.buff = [];
	            div.triggers = {};
	            div.linkCard = [card];
	            div.wpid = card.cardid;
	            div.baseATK = get.rATK(card);
	            div.baseHP = get.rHP(card);
	            div.maxHp = div.baseHP;
	            div.hs_dm = 0;
	            ui.create.div(".hs_zh", div); //战吼
	            ui.create.div(".hs_bj", div); //扳机
	            ui.create.div(".hs_wy", div); //亡语
	            ui.create.div(".hs_gh", div); //光环
	            div.zhezhao = ui.create.div(".hs_wp_zz", div);
	            div.img = ui.create.div(".hs_wp_img", div);
	            div.img.qiao1 = ui.create.div(".hs_wp_img_qiao1", div.img);
	            div.img.qiao2 = ui.create.div(".hs_wp_img_qiao2", div.img);
	            div.img.style.backgroundImage = "url('" + lib.assetURL + "extension/炉石普通/card/" + card.name + ".jpg')";
	            div.node = {};
	            div.node.atk = ui.create.div(".hs_wp_atk", div);
	            div.node.atk.innerHTML = div.baseATK;
	            div.node.hp = ui.create.div(".hs_wp_dr", div);
	            div.node.hp.innerHTML = div.baseHP;
	            div.listen(function() {
	                get.HSF("morefocus", div.linkCard);
	            });
	            return div;
	        },
	        hs_weapon2: function(card) { //直接装武器
	            var player = this;
	            if (typeof card == "string") card = get.chscard(card);
	            var div = player.addweapon(card);
	            _status.hsAttendSeq.ad(card);
	            div.hs_yin();
	            player.data_weapon = div;
	            div.classList.add("bright");
	            get.HSF("checkfellow");
	            div.swt(true);
	            div.node.atk.show();
	            player.updatehsfl();
	        },
	        hs_weapon: function(card) { //装武器
	            var next = game.createEvent("hs_weapon", false);
	            next.player = this;
	            if (typeof card == "string") card = get.chscard(card);
	            next.card = card;
	            next.setContent(function() {
	                "step 0"
	                //摧毁旧武器
	                if (player.data_weapon) get.HSF("event", ["equipBefore", {
	                    heroskill: event.hs_heroskill,
	                    player: player,
	                    div: player.data_weapon,
	                    card: player.data_weapon.linkCard[0],
	                }]);
	                "step 1"
	                game.log(player, "装备了", card);
	                if (player.data_weapon) {
	                    player.data_weapon.HSF("cuihui");
	                    player.old_weapon = player.data_weapon;
	                    delete player.data_weapon;
	                }
	                "step 2"
	                event.div = player.addweapon(card);
	                _status.hsAttendSeq.ad(card);
	                event.div.hs_yin();
	                //武器进场
	                "step 3"
	                game.delay();
	                "step 4"
	                get.HSF("event", ["equipAfter", {
	                    player: player,
	                    div: event.div,
	                    card: card,
	                }]);
	                "step 5"
	                player.data_weapon = event.div;
	            });
	            return next;
	        },
	        hs_atkhj: function(val) { //攻击和护甲不分家
	            var next = game.createEvent("hs_atkhj", false);
	            next.player = this;
	            if (!val) {
	                get.hs_alt("hs_atkhj:参数val不能为空");
	                return;
	            }
	            if (typeof val == "number") val = [val, 0];
	            if (val.length == 1) val.push(0);
	            next.val = val;
	            next.setContent(function() {
	                if (event.val[0] > 0) {
	                    var num = event.val[0];
	                    player.addvaluebuff(num, 1);
	                }
	                var num = event.val[1];
	                if (num > 0) player.changeHujia(num);
	            });
	        },
	        hs_full: function() { //自己的随从满了
	            return this.countFellow() >= get.hs_nm();
	        },
	        hs_exchange2: function() {
	            var next = game.createEvent("hs_exchange2", false);
	            next.player = this;
	            next.setContent(function() {
	                "step 0"
	                event.band2 = ui.create.div(".bright.hs_band2", ui.arena);
	                event.daith2 = player.getCards("h");
	                player.countCards("h", function(c) {
	                    ui.create.div(".hs_tih", c);
	                    ui.create.div(".hs_tihwz", c, "替换");
	                });
	                player.chooseCard("h", true, [0, Infinity], " ");
	                var enemy = player.next;
	                setTimeout(function() {
	                    var cs = enemy.getCards("h", c => c.cost() > 2);
	                    if (cs.length) {
	                        var cg = enemy.cardPile.getCards("h")
	                            .randomGets(cs.length);
	                        enemy.cardPile.directgain(cs);
	                        enemy.update();
	                        setTimeout(function() {
	                            enemy.hs_sort();
	                            enemy.$give(get.HSF("repeat", [lib.hearthstone.enemycard, cs.length]), enemy.discardPile, false);
	                            setTimeout(function() {
	                                enemy.update();
	                                enemy.directgain(cg);
	                                enemy.discardPile.$give(get.HSF("repeat", [lib.hearthstone.enemycard, cs.length]), enemy, false);
	                                setTimeout(function() {
	                                    enemy.update();
	                                }, 1000);
	                            }, 2000);
	                        }, 1000);
	                    }
	                }, 2000);
	                "step 1"
	                if (result.bool && result.cards.length) {
	                    event.cs = result.cards;
	                    event.num = result.cards.length;
	                    event.i = 0;
	                    if (player.cardPile.getCards("h")
	                        .length < event.num) {
	                        event.willcg = event.cs.concat(player.cardPile.getCards("h"))
	                            .randomGets(event.num);
	                    } else event.willcg = player.cardPile.getCards("h")
	                        .randomGets(event.num);
	                    event.daith = event.cs.map(i => event.daith2.indexOf(i))
	                        .sort();
	                } else event.goto(6);
	                event.band2.delete();
	                "step 2"
	                player.cardPile.directgain([event.cs[event.i]]);
	                player.$give(event.cs[event.i], player.discardPile, false);
	                event.i++;
	                game.delay();
	                if (event.i < event.num) event.redo();
	                "step 3"
	                player.hs_sort();
	                event.i = 0;
	                event.hs_res = event.daith2.slice(0);
	                for (var i = 0; i < event.num; i++) {
	                    var c = game.createCard();
	                    c.style.display = "none";
	                    event.hs_res[event.daith[i]] = c;
	                }
	                player.node.handcards1.innerHTML = "";
	                event.hs_res.forEach((i, j) => {
	                    player.node.handcards1.appendChild(i);
	                    if (event.daith.contains(j)) event.hs_res[j] = event.willcg.pop();
	                });
	                game.delay(2);
	                "step 4"
	                var pos = event.daith[event.i];
	                var cs = event.hs_res[pos];
	                player.cardPile.node.handcards1.removeChild(cs);
	                player.node.handcards1.removeChild(player.node.handcards1.childNodes[pos]);
	                player.node.handcards1.appendChild(cs);
	                player.node.handcards1.insertBefore(cs, player.node.handcards1.childNodes[pos]);
	                ui.updatehl();
	                if (pos == 0) cs.animate("start");
	                player.discardPile.$give([cs], player, false);
	                event.i++;
	                game.delay();
	                if (event.i < event.num) event.redo();
	                "step 5"
	                game.delay(1.5);
	                "step 6"
	                game.delay(1.5);
	            });
	            return next;
	        },
	        hs_place: function(num) { //其他随从给新增随从腾出位置
	            var m = this.countFellow();
	            var n = get.hs_nm();
	            if (m == 0 || m == n) return;
	            var fls = this.getFellow()
	                .sort(lib.sort.position);
	            if (!this.hasFellow(fl => parseInt(fl.dataset.position) == num)) fls.forEach((i, j) => i.dataset.position = 2 + j + (this == game.me ? 0 : n) + "");
	            this.countFellow(fl => {
	                var i = parseInt(fl.dataset.position);
	                if (i >= num) {
	                    fl.dataset.position = i + 1 + "";
	                    if (fl.truepos) fl.truepos++;
	                }
	            });
	        },
	        //from extension.js
	        hs_drawDeck: function() { //抽牌
	            if (this.isMin()) return;
	            var next = game.createEvent('hs_drawDeck', false);
	            next.player = this;
	            for (var i = 0; i < arguments.length; i++) {
	                var g = arguments[i];
	                if (typeof g == "number") {
	                    if (g > 0) next.num = g;
	                    else {
	                        _status.event.next.remove(next);
	                        return;
	                    }
	                } else if (typeof g == "boolean") next.log = g;
	                else if (get.itemtype(arguments[i]) == "cards") next.cards = arguments[i];
	                else if (typeof g == "string") {
	                    if (g == "notrigger") next.notrigger = true;
	                }
	            }
	            if (next.num === undefined) next.num = 1;
	            if (next.log === undefined) next.log = true;
	            next._args = Array.from(arguments);
	            next.setContent(function() { //抽卡
	                "step 0"
	                event.i = 0;
	                event.a = 0;
	                event.remv = [];
	                "step 1"
	                if (event.炸服 (evt => evt.i >= 30)) return;
	                var deck = player.cardPile;
	                var deck2 = player.discardPile;
	                if (!event.cards) {
	                    event.cards = [];
	                    if (deck.countCards("h")) event.cards = deck.getCards("h")
	                        .slice(0, 1);
	                }
	                event.i++;
	                event.deck = deck;
	                event.deck2 = deck2;
	                if (event.cards.length && !event.notrigger) {
	                    var card = event.cards[0];
	                    var info = get.info(card);
	                    if (info.onhsdraw) {
	                        if (event.log) game.log(player, "从", event.deck, "获得了", card);
	                        event.remv.add(card);
	                        card.HSF("morefocus");
	                        event.insert(info.onhsdraw, {
	                            player: player,
	                            card: card,
	                        });
	                        game.delay();
	                        player.heroskill.pos.directgain(event.cards);
	                        player.hs_drawDeck();
	                    }
	                }
	                "step 2"
	                get.HSF("checkdeck");
	                if (!player.HSF("alive") && event.i >= event.num) event.finish();
	                else {
	                    event.pre = event.a;
	                    if (event.cards.length) {
	                        if (!event.remv.contains(event.cards[0])) {
	                            if (player.countCards('h') < player.getHandcardLimit()) {
	                                if (event.log) game.log(player, "从", event.deck, "获得了一张牌");
	                                event.a++;
	                                player.directgain(event.cards);
	                                event.deck2.$give(player == game.me ? lib.hearthstone.mecard : lib.hearthstone.enemycard, player, false);
	                            } else {
	                                event.deck2.$throw(event.cards);
	                                setTimeout(function() {
	                                    ui.clear()
	                                }, 500);
	                            }
	                            get.HSF("checkhand");
	                        } else event.a++;
	                    } else {
	                        game.log(player, "#g疲劳", "！");
	                        if (get.hs_nm() == 3) {
	                            player.hs_dmgrcv("damage", "nosource", "nocard");
	                            event.goto(7);
	                        } else {
	                            player.addMark("hs_pilao", 1, false);
	                            player.hs_dmgrcv("damage", player.countMark("hs_pilao"), "nosource", "nocard");
	                            event.goto(6);
	                        }
	                    }
	                }
	                "step 3"
	                if (event.pre == event.a && player.countCards('h') >= player.getHandcardLimit()) {
	                    game.log(player, "的", event.cards, "被摧毁了！");
	                    player.heroskill.pos.directgain(event.cards);
	                    player.HSFT("爆牌");
	                    game.delay(0.5);
	                    event.goto(6);
	                }
	                if (event.deck.countCards("h") <= 1) {
	                    if (event.deck.countCards("h") == 1) player.HSFT("牌库快空");
	                    else {
	                        player.HSFT("牌库空");
	                        event.deck.classList.add("hs_nocard");
	                    }
	                }
	                "step 4"
	                if (event.cards.length) {
	                    if (player.getStat()
	                        .gain == undefined) player.getStat()
	                        .gain = 1;
	                    else player.getStat()
	                        .gain++;
	                    event.result = {
	                        cards: event.cards
	                    };
	                    if (!event.notrigger) {
	                        var card = event.cards[0];
	                        var info = get.info(card);
	                        if (info.addhand) {
	                            if (event.log) game.log(player, "从", event.deck, "获得了", card);
	                            card.HSF("morefocus");
	                            get.HSF("Aud", [card, "trigger"]);
	                            event.insert(info.addhand, {
	                                player: player,
	                                card: card
	                            });
	                        }
	                        get.HSF("event", ["drawAfter", {
	                            player: player,
	                            card: card,
	                        }]);
	                    }
	                }
	                "step 5"
	                game.delay();
	                "step 6"
	                if (event.onbuff) event.onbuff(event.cards);
	                if (event.i < event.num) {
	                    delete event.cards;
	                    event.goto(1);
	                } else event.finish();
	                "step 7"
	                var cs = player.discardPile.getCards("h");
	                if (cs.length) {
	                    cs.randomSort();
	                    var c = cs.randomRemove();
	                    event.todrop = c;
	                    player.heroskill.pos.directgain([c]);
	                    player.cardPile.directgain(cs);
	                    if (cs.length) {
	                        player.cardPile.forcecount = 0;
	                        player.cardPile.style.pointEvents = "none";
	                    } else {
	                        game.log(player, "弃牌堆中的", c, "移出游戏");
	                        player.discardPile.$throw([c]);
	                        setTimeout(function() {
	                            ui.clear();
	                        }, 500);
	                        event.goto(6);
	                    }
	                } else {
	                    game.log(player, "弃牌堆无牌");
	                    player.die();
	                    event.finish();
	                    return;
	                }
	                "step 8"
	                var res = player.cardPile.getCards("h");
	                var renum = res.length;
	                var p = player;
	                var c = event.todrop;
	                var jishu = 0;
	                setTimeout(function() {
	                    p.cardPile.parentNode.classList.add("hs_check");
	                    p.cardPile.querySelector(".count")
	                        .show();
	                    var id = setInterval(function() {
	                        var ca = res[jishu];
	                        game.log(p, "的", "#b弃牌堆", "中的", ca, "洗回牌库");
	                        p.discardPile.$gain2([ca], false);
	                        p.cardPile.forcecount++;
	                        jishu++;
	                        get.HSF("checkdeck");
	                        if (jishu == renum) clearInterval(id);
	                    }, 300);
	                    setTimeout(function() {
	                        setTimeout(function() {
	                            p.cardPile.parentNode.classList.remove("hs_check");
	                            p.cardPile.querySelector(".count")
	                                .hide();
	                            p.cardPile.style.pointEvents = "";
	                            delete p.cardPile.forcecount;
	                            get.HSF("checkdeck");
	                            game.log(p, "弃牌堆中的", c, "移出游戏");
	                            p.discardPile.$throw([c]);
	                            setTimeout(function() {
	                                ui.clear();
	                            }, 500);
	                        }, 2000);
	                    }, renum * 50);
	                }, 800);
	                "step 9"
	                if (!event.isMine()) game.delay(4);
	                "step 10"
	                event.goto(6);
	            });
	            return next;
	        },
	        hs_calcv: function(pure) { //计算攻守 可以为负数,实操
	            var that = this;
	            var atk = that.baseATK;
	            var hp = that.baseHP;
	            var maxHp = that.baseHP;
	            var dm = that.hs_dm;
	            that.buff.filter(i => i.iswork() && i.type == "value")
	                .forEach(i => {
	                var val = i.value;
	                if (typeof val == "function") val = val(that, atk, hp);
	                if (i.subtype == "final") {
	                    if (val[0] != 0) atk = val[0];
	                    if (val[1] != 0) {
	                        maxHp = val[1];
	                        hp = val[1];
	                    }
	                } else {
	                    atk += val[0];
	                    maxHp += val[1];
	                    hp += val[1];
	                }
	            });
	            var auras = that.sctp("field")
	                .reduce((x, y) => x.concat(y.buff.filter(i => i.ghwork("value", that, [null, y, that]))), []);
	            auras.sort(lib.sort.attendseq);
	            auras.forEach(i => {
	                var val = i.value;
	                if (typeof val == "function") val = val(that, atk, hp);
	                if (i.subtype == "final") {
	                    if (val[0] != 0) atk = val[0];
	                } else {
	                    atk += val[0];
	                    maxHp += val[1];
	                    hp += val[1];
	                }
	            });
	            hp -= dm;
	            if (!pure) atk = Math.max(0, atk);
	            return [atk, hp, maxHp];
	        },
	        hs_calcad: function() { //计算身材
	            var that = this;
	            if (!that.isMin()) {
	                if (that.data_weapon) {
	                    if (that.data_weapon.classList.contains("kaiqiao")) that.baseATK = that.data_weapon.ATK;
	                    else that.baseATK = 0;
	                } else that.baseATK = 0;
	            }
	            var atk = that.baseATK;
	            var hp = that.baseHP;
	            var maxHp = that.baseHP;
	            hp -= that.hs_dm;
	            get.HSA("canchenmo")
	                .forEach(i => {
	                if (that.classList.contains(i) != that.hasgjz(i)) that.classList.toggle(i);
	            });
	            if (that.classList.contains("superfengnu")) that.classList.add("fengnu");
	            get.HSA("canchenmozt")
	                .forEach(i => {
	                if (that[i] != that.buff.some(y => y.iswork() && y.type == "status" && y.value.contains(i))) that[i] = !that[i];
	            });
	            that.HSF("uptris");
	            that.hs_atk_max = that.hasgjz("superfengnu") ? 4 : (that.hasgjz("fengnu") ? 2 : 1);
	            var o = that.hs_calcv(false);
	            that.ATK = o[0];
	            if (that.isSGS()) {
	                that.SGShp = o[1];
	                that.SGSmaxHp = o[2];
	                that.hp = that.SGShp / 10;
	                that.maxHp = that.SGSmaxHp / 10;
	            } else {
	                that.hp = o[1];
	                that.maxHp = o[2];
	            }
	        },
	        settlehsFL: function() { //给即将上场的随从安排位置
	            var m = this.countFellow();
	            var pos;
	            if (this == game.me) {
	                if (ui.hs_testfl.num <= m + 2 && !game.me.hasFellow(fl => parseInt(fl.dataset.position) == ui.hs_testfl.num)) {
	                    pos = ui.hs_testfl.num;
	                    ui.hs_testfl.num = 2;
	                } else pos = get.rand(2, m + 2);
	            } else {
	                var n = get.hs_nm();
	                pos = get.rand(2, m + 2) + n;
	            }
	            return pos;
	        },
	        updatehsfl: function(hpcg) { //更新随从
	            if (_status.hs_noupdate) {
	                this.ATK = parseInt(this.node.atk.innerHTML);
	                this.hp = parseInt(this.node.hp.innerHTML);
	                return;
	            }
	            var ratk = this.ATK,
	                rhp = this.hp;
	            lib.hearthstone.upF.apply(this);
	            hpcg = hpcg || 0;
	            this.hs_dm -= hpcg;
	            this.hs_dm = Math.max(0, this.hs_dm);
	            this.hs_calcad();
	            var co = this.node.atk;
	            var hp = this.node.hp;
	            if (this.isMin() || this.ATK > 0) co.innerHTML = this.ATK;
	            else this.hideatkdiv = true;
	            hp.innerHTML = this.hp;
	            this.hs_judge();
	            var f = function(t, a, b) {
	                var cls = ["hs_smaller", "hs_larger"];
	                if (a == b) {
	                    if (t.classList.contains("hs_atk")) cls.forEach(i => {
	                        t.classList.remove(i)
	                    });
	                    else {
	                        var base = t.parentNode.baseHP;
	                        if (b <= base) cls.forEach(i => {
	                            t.classList.remove(i)
	                        });
	                        else {
	                            t.classList.add("hs_larger");
	                            t.classList.remove("hs_smaller");
	                        }
	                    }
	                } else if (a > b) {
	                    t.classList.add("hs_larger");
	                    t.classList.remove("hs_smaller");
	                } else {
	                    if (t.classList.contains("hs_atk")) {
	                        t.classList.remove("hs_larger");
	                    } else {
	                        t.classList.add("hs_smaller");
	                        t.classList.remove("hs_larger");
	                    }
	                }
	            }
	            if (!this.hideatkdiv) f(co, this.ATK, this.baseATK);
	            f(hp, this.hp, this.maxHp);
	            if (!this.hideatkdiv && this.ATK != ratk) co.animate("hs_start");
	            if (this.hp != rhp) hp.animate("hs_start");
	            delete this.hideatkdiv;
	            if (this.hujia) {
	                var div = this.querySelector(".overflowmark");
	                div.innerHTML = this.hujia;
	            }
	            get.HSF("checkcanatk");
	            if (!this.isMin()) {
	                if (this.ATK == 0) this.node.atk.hide();
	                else this.node.atk.show();
	            }
	        },
	        //攻击
	        hs_attack: function(target) {
	            var next = get.HSF("xvlie", ["hs_attackxl", {
	                attacker: this,
	                victim: target,
	            }]);
	            next.setContent(function() {
	                "step 0"
	                game.log(event.attacker, "对", event.victim, "发动了攻击");
	                event.orivictim = event.victim;
	                event.triedeff = [];
	                "step 1"
	                event.resact = get.HSF("attackact", [event.attacker, event.victim]);
	                event.curvictim = event.victim;
	                "step 2"
	                //攻击前事件
	                get.HSF("event", ["attackBefore", {
	                    player: event.attacker,
	                    target: event.orivictim,
	                }]);
	                "step 3"
	                if (event.curvictim != event.victim) {
	                    game.log("攻击目标改为了", event.victim);
	                    event.backflowed = true;
	                    event.goto(1);
	                } else {
	                    delete event.triedeff;
	                    game.delay(0.5);
	                }
	                "step 4"
	                //攻击时事件
	                get.HSF("event", ["attackBegin", {
	                    player: event.attacker,
	                    target: event.victim,
	                }]);
	                "step 5"
	                if (!event.attacker.HSF("alive") || !event.victim.HSF("alive")) {
	                    event.attacker.classList.remove("hs_atkprepare");
	                    if (!event.attacker.HSF("alive")) event.goto(11);
	                    else event.goto(9);
	                } else event.attacker.removegjz("qianxing");
	                "step 6"
	                if (!event.quick) game.delay(0.5);
	                "step 7"
	                //进攻动画
	                var atk = event.attacker;
	                var def = event.victim;
	                var res = event.resact;
	                var a = atk.style.transform;
	                var z = atk.style.zIndex;
	                atk.hs_attackAct = true;
	                if (atk.isMin()) atk.style.transition = "all 0.08s";
	                else atk.style.transition = "all 0.14s";
	                atk.style.zIndex = 99;
	                atk.classList.remove("hs_atkprepare");
	                var begin = 'translateY(' + res[0] + 'px) translateX(' + res[1] + 'px)';
	                var end = (function(o) {
	                    if (o.isMin()) {
	                        if (game.me.hasFellow(o)) return "perspective(100px) translateY(8px) translateZ(10px) scale(0.9)";
	                        else return "perspective(100px) translateY(-8px) translateZ(10px) scale(0.9)";
	                    } else {
	                        if (o == game.me) return "perspective(100px) rotateX(2deg) translateY(17px) translateZ(10px)";
	                        else return "perspective(100px) translateY(-18px) translateZ(10px)";
	                    }
	                })(atk);
	                atk.style.transform = begin;
	                setTimeout(function() {
	                    atk.style.transition = "all 0.5s";
	                    atk.style.transform = end;
	                    setTimeout(function() {
	                        atk.style.transform = a;
	                    }, 500);
	                }, (atk.isMin() ? 80 : 140));
	                setTimeout(function() {
	                    delete atk.hs_attackAct;
	                    atk.style.zIndex = z;
	                }, 1550);
	                "step 8"
	                //伤害步骤
	                event.attacker.hs_dmgrcvbt(event.victim);
	                "step 9"
	                event.attacker.hs_attacked++;
	                if (!event.attacker.isMin()) event.attacker.hs_state.atks++;
	                get.HSF("checkcanatk");
	                "step 10"
	                //攻击后事件
	                get.HSF("event", ["attackEnd", {
	                    player: event.attacker,
	                    target: event.victim,
	                }]);
	                "step 11"
	                //状态清除
	                "step 12"
	                get.HSF("checkdeath");
	                "step 13"
	                if (event.attacker == game.me) game.delay(0.5);
	            });
	            return next;
	        },
	        //使用英雄技能
	        hs_use_heroskill: function() { //使用英雄技能
	            var h = this.heroskill;
	            var next = get.HSF("xvlie", ["hs_use_heroskillxl", {
	                player: this,
	                skill: h.skill,
	                needTarget: true,
	                filterTarget: h.filterTarget,
	                randomHT: h.randomHT,
	                ai: h.hrskai,
	                cost: h.cost,
	            }]);
	            if (!next.filterTarget && !next.randomHT) next.needTarget = false;
	            next.setContent("hs_use_heroskill");
	            return next;
	        },
	        hs_heroskillEffect: function(t, con) { //结算英雄技能
	            var next = game.createEvent("hs_heroskillEffect", false);
	            next.player = this;
	            next.target = t;
	            next.setContent(con);
	            return next;
	        },
	        //初始化
	        hs_Hero: function() { //英雄进行初始化
	            var current = this;
	            var s = current.directgain.toString();
	            var ins = function(str) {
	                str = str.replace("insertBefore", "appendChild");
	                return str;
	            };
	            eval("current.directgain=function(cards,broadcast,gaintag){" + s.newFedit(ins) + "}");
	            ui.create.div(".hs_dj", current);
	            ui.create.div(".hs_my", current);
	            ui.create.div(".hs_fn", current);
	            current.hs_state = { //全局记录
	                hrsk: 0, //使用英雄技能次数
	                atks: 0, //本回合攻击次数
	                useCard: 0, //本回合使用牌数
	            };
	            current.ATK = 0;
	            current.baseATK = 0;
	            current.baseHP = current.hp;
	            //非牌面属性
	            current.dataset.enemy = current == game.me ? "0" : "1";
	            current.update = current.updatehsfl;
	            current.nodying = true;
	            current.buff = [];
	            current.triggers = {};
	            current.actcharacterlist = [];
	            current.hs_dm = 0; //伤害标记数量
	            current.hs_atk_max = 1; //最大攻击次数
	            current.hs_attacked = 0; //攻击过次数
	            current.hs_ex_atk = 0; //额外攻击次数
	            current.storage.hs_mana_limit = get.HSF("manalimit"); //最大法力水晶
	            current.storage.hs_mana_used = 0; //已用法力水晶
	            current.storage.hs_mana_max = 0; //法力水晶上限
	            current.storage.hs_mana_temp = 0; //临时法力水晶
	            current.storage.hs_mana_locked = 0; //本回合过载法力水晶
	            current.storage.hs_mana_owed = 0; //下回合过载法力水晶
	            //非牌面属性结束
	            current.listen(get.HSA("clickatk"));
	            current.addSkill(["hs_battlephase", "hs_summonlimit"]);
	            current.popup = function() {};
	            current.draw = function() {
	                var that = this;
	                that.hs_drawDeck.apply(that, arguments);
	            };
	            current.useCard = function() {
	                if (this.isSGS()) return lib.element.player.useCard.apply(this, arguments);
	                var next = get.HSF("xvlie", ["hs_usexl"]);
	                next.args = Array.from(arguments);
	                next.player = this;
	                for (var i = 0; i < arguments.length; i++) {
	                    if (get.itemtype(arguments[i]) == 'cards') next.cards = arguments[i].slice(0);
	                    else if (get.itemtype(arguments[i]) == 'players') next.targets = arguments[i];
	                    else if (get.itemtype(arguments[i]) == 'player') next.targets = [arguments[i]];
	                    else if (get.itemtype(arguments[i]) == 'card') next.card = arguments[i];
	                    else if (typeof arguments[i] == 'object' && arguments[i] && arguments[i].name) next.card = arguments[i];
	                    else if (typeof arguments[i] == 'boolean') next.addCount = arguments[i];
	                }
	                if (next.cards == undefined) {
	                    if (get.itemtype(next.card) == 'card') next.cards = [next.card];
	                    else next.cards = [];
	                } else if (next.card == undefined) {
	                    if (next.cards) next.card = next.cards[0];
	                }
	                if (next.targets && !next.target) next.target = next.targets[0];
	                if (get.type(next.card) == "HS_minor") next.setContent('hs_use_minor');
	                else if (get.type(next.card) == "HS_spell") next.setContent('hs_use_spell');
	                else if (get.type(next.card) == "HS_weapon") next.setContent('hs_use_weapon');
	                return next;
	            };
	        },
	        hs_FL: function(cards, type) { //随从召唤出来进行初始化
	            var that = this;
	            get.HSA("canchenmo")
	                .concat(get.HSA("bjcls"))
	                .forEach(i => that.classList.remove(i));
	            get.HSA("canchenmozt")
	                .forEach(i => (delete that[i]));
	            that.classList.remove("hs_DIYfl");
	            this.linkCard = cards;
	            cards[0].buff = [];
	            var info = get.info({
	                name: this.name + "_monster"
	            });
	            this.smtp = type;
	            this.ATK = info.ATK;
	            this.baseATK = info.ATK;
	            this.baseHP = info.HP;
	            this.rkind = info.rkind;
	            this.subtype = info.subtype;
	            this.hs_remove = info.hs_remove;
	            this.hs_token = info.hs_token;
	            if (info.hs_tokened) {
	                this.hs_token = true;
	                this.hs_tokened = true;
	            }
	            if (info.hs_quetu || info.hs_tokened || info.hs_diy || this.name.indexOf("PT") > 0) this.classList.add("hs_DIYfl");

	            if (type != "R") {
	                that.listen(get.HSA("clickatk"));
	                that.node.atk = ui.create.div(".hs_atk", this);
	                ui.create.div(".hs_zhezhao", this); //遮罩
	                ui.create.div(".hs_dragon", this); //金龙
	                ui.create.div(".hs_jinu", this.node.avatar); //激怒
	                ui.create.div(".hs_gh", this); //光环
	                ui.create.div(".hs_bj", this); //扳机
	                ui.create.div(".hs_wy", this); //亡语
	                ui.create.div(".hs_jl", this); //激励
	                ui.create.div(".hs_jd", this); //剧毒
	                ui.create.div(".hs_xx", this); //吸血

	                ui.create.div(".hs_cof", this); //冲锋
	                ui.create.div(".hs_zh", this); //战吼
	                ui.create.div(".hs_qx", this); //潜行
	                ui.create.div(".hs_cm1", this); //沉默环(横)
	                ui.create.div(".hs_cm2", this); //沉默环(纵)
	                ui.create.div(".hs_dj", this); //冻结
	                ui.create.div(".hs_my", this); //免疫
	                ui.create.div(".hs_cf", this); //嘲讽
	                ui.create.div(".hs_sd", this); //圣盾
	                ui.create.div(".hs_fn", this); //风怒
	                ui.create.div(".hs_mm", this); //魔免
	            }
	            this.update = this.updatehsfl;
	            //非牌面属性
	            this.summoned = true; //召唤失调
	            this.nodying = true;
	            this.buff = [];
	            this.triggers = {};
	            this.hs_dm = 0; //伤害标记数量
	            this.hs_atk_max = 1; //最大攻击次数
	            this.hs_attacked = 0; //攻击过次数
	            this.hs_ex_atk = 0; //额外攻击次数
	            this.updatehsfl();
	            //非牌面属性结束
	            this.node.identity.hide();
	            if (this.getLeader() == game.me) this.dataset.enemy = "0";
	            else this.dataset.enemy = "1";
	            this.getLeader()
	                .update();
	        },
	        hs_judge: function(key) { //判断随从扳机类型
	            var that = this;
	            if (!key)["guanghuan", "legend", "banji", "wangyu", "jili"].forEach(i => that.hs_judge(i));
	            else {
	                var bo = false;
	                if (key == "guanghuan") {
	                    bo = that.buff.some(i => i.type == "auras");
	                    if (bo != that.classList.contains("guanghuan")) that.classList.toggle("guanghuan");
	                }
	                if (key == "legend") {
	                    var info = get.info({
	                        name: this.name + "_monster"
	                    });
	                    bo = info != undefined && info.hs_legend != undefined;
	                    if (bo != that.classList.contains("hs_legend")) that.classList.toggle("hs_legend");
	                } else if (key == "banji") {
	                    var tri = that.triggers;
	                    for (var i in tri) {
	                        if (["battleRoal", "deathRattle", "jili"].contains(i)) continue;
	                        if (tri[i]) {
	                            var col = Array.isArray(tri[i]) ? tri[i] : [tri[i]];
	                            bo = col.some(y => {
	                                if (["冻结", "剧毒", "吸血"].contains(y.alias)) return false;
	                                else if (y.charlotte || y.direct) return false;
	                                return true;
	                            });
	                        }
	                    }
	                    if (bo != that.classList.contains("banji")) that.classList.toggle("banji");
	                } else if (key == "wangyu") {
	                    bo = that.triggers.deathRattle != undefined;
	                    if (bo != that.classList.contains("wangyu")) that.classList.toggle("wangyu");
	                } else if (key == "jili") {
	                    bo = that.triggers.jili != undefined;
	                    if (bo != that.classList.contains("jili")) that.classList.toggle("jili");
	                }
	                return bo;
	            }
	        },
	        hs_yin: function(tm) { //入场
	            var that = this;
	            var info = that.HSF("info");
	            if (info) {
	                var f = function() {
	                    that.subtype = "HS_effect";
	                    if (get.itemtype == "player") that.addtriggerbuff(that, undefined, that.HSF("recheck"));
	                    else that.addtriggerbuff(that.linkCard[0], undefined, that.HSF("recheck"));
	                    if (info.hs_fq) that.addFqbuff("hs_power", info.hs_fq);
	                    if (info.skillgh) {
	                        for (var i in info.skillgh) {
	                            that.addaurasbuff(i)
	                                .subtype = "skillgh";
	                        }
	                    }
	                    if (info.numgh) {
	                        if (info.numgh.auras) {
	                            info.numgh.auras.forEach(i => {
	                                that.addaurasbuff(i);
	                            });
	                        } else that.addaurasbuff(info.numgh);
	                    }
	                    if (info.noattack) that.addztbuff("noattack");
	                    if (info.jinu) {
	                        that.addjinubuff(info.jinu);
	                    }
	                    var yin = get.HSAT("yineng");
	                    for (var i in yin) {
	                        if (info[i]) that.addgjzbuff(i);
	                    }
	                };
	                f();
	                if (info.chongfeng) setTimeout(function() {
	                    if (that.HSF("alive")) that.animate("chongfeng2");
	                }, (tm || 0) + 600) + (get.hslegend(that) ? 500 : 0);
	                that.hs_judge();
	            }
	            get.HSF("updateauras", [that.swt]);
	        },
	        hasAuras: function(name) { //己方单位有光环
	            var that = this;
	            if (that.isMin()) return that.hasAuras2(name);
	            return that.sctp("myside", i => i.hasAuras2(name));
	        },
	        hasAuras2: function(name) { //计算一个单位是否有光环
	            var that = this;
	            return that.buff.some(m => {
	                if (m.iswork() && m.name == name && m.type == "auras") {
	                    if (that.HSF("alive")) return true;
	                    else return m.subtype != "skillgh";
	                }
	            });
	        },
	        aurasEffed: function(name) { //受到光环影响
	            var that = this;
	            var auras = that.sctp("field")
	                .reduce((x, y) => x.concat(y.buff.filter(i => i.ghwork(name, that, [null, y, that]))), []);
	            return auras.length;
	        },
	        countFq: function() { //获取法强
	            var that = this;
	            var cost = 0;
	            var buffs = that.sctp("myside")
	                .reduce((x, y) => x.concat(y.buff.filter(i => i.iswork() && i.type == "hs_power")), [])
	                .concat(that.sctp("field")
	                .reduce((x, y) => x.concat(y.buff.filter(i => i.ghwork("hs_power", null, [null, y, that]))), []));
	            buffs.sort(lib.sort.attendseq);
	            buffs.forEach(i => {
	                cost += i.value;
	            });
	            return cost;
	        },
	        hs_silence: function() { //沉默
	            var that = this;
	            that.buff.forEach(i => {
	                if (i.onremove) i.onremove(that);
	            });
	            that.buff = [];
	            var num = that.maxHp - that.baseHP;
	            that.maxHp = that.baseHP;
	            that.hs_dm -= num;
	            that.hs_dm = Math.max(0, that.hs_dm);
	            that.triggers = {};
	            that.addgjzbuff("chenmo");
	        },
	        //buff相关
	        addhsbuff: function(obj) { //加buff
	            if (!obj) return null;
	            var that = this;
	            if (Array.isArray(obj)) this.buff.addArray(obj);
	            else {
	                obj.creator = obj.creator || that;
	                obj.fellow = obj.fellow || that;
	                obj.iswork = function() {
	                    if (this.type == "trigger") return true;
	                    var f = this.fellow;
	                    return !this.sleep && (!this.filter || this.filter(f.getLeader(), f));
	                };
	                obj.inrange = function(tg) {
	                    var f = this.fellow;
	                    if (tg && tg.swt) return this.wpal;
	                    else return !this.range || this.range(f, tg);
	                };
	                obj.ghwork = function(name, target, args) {
	                    return this.type == "auras" && this.name == name && this.iswork() && this.inrange(target) && (!this.ghfilter || this.ghfilter.apply(null, args));
	                };
	                obj.stid = get.id();
	                _status.hsAttendSeq.ad(obj);
	                this.buff.add(obj);
	            }
	        },
	        addautovaluebuff: function(value, tg) { //加自动取名的身材buff
	            var that = this;
	            if (typeof value == "number") value = [value, 0];
	            var obj = {
	                type: "value",
	                value: value,
	            };
	            if (typeof tg == "string") obj.uniquename = tg;
	            else obj.uniquename = tg.name;
	            that.addhsbuff(obj);
	            setTimeout(function() {
	                if (obj.iswork() && value[0] > 0 && value[1] == 0 && !that.classList.contains("jinu")) that.animate("kuangbao", 700);
	            }, 100);
	            return obj;
	        },
	        addvaluefinal: function(value) { //身材变成固定值
	            var that = this;
	            if (typeof value == "number") value = [value, 0];
	            var obj = {
	                type: "value",
	                subtype: "final",
	                value: value,
	            };
	            that.addhsbuff(obj);
	            if (value[1] != 0) that.hs_dm = 0;
	            that.updatehsfl();
	            return obj;
	        },
	        addvaluebuff: function(value, num, name, uniquename) { //加身材buff
	            var that = this;
	            if (typeof value == "number") value = [value, 0];
	            var obj = {
	                type: "value",
	                value: value,
	                temp: num,
	            };
	            obj.name = name;
	            if (uniquename) obj.uniquename = uniquename;
	            else if (obj.name) obj.uniquename = obj.name;
	            that.addhsbuff(obj);
	            setTimeout(function() {
	                if (obj.iswork() && value[0] > 0 && value[1] == 0 && !that.classList.contains("jinu")) that.animate("kuangbao", 700);
	            }, 100);
	            return obj;
	        },
	        addgjzbuff: function(word, num) { //加关键字buff
	            var that = this;
	            if (typeof word == "string") {
	                if (["dongjie", "jvdu", "xixie"].contains(word)) {
	                    var obj = ({
	                        sc: true,
	                    });
	                    if (word != "xixie") obj.alias = get.HSAT("yineng")[word];
	                    if (word == "jvdu") {
	                        obj.filter = function(evt) {
	                            return evt.player.isMin();
	                        };
	                        obj.effect = function() {
	                            get.HSF("cuihui", [event.evt.player]);
	                        };
	                    } else if (word == "xixie") {
	                        obj.filter = function(evt) {
	                            return !evt.card;
	                        };
	                        obj.effect = function() {
	                            player.hs_dmgrcv("recover", event.evt.num, event.fellow);
	                        };
	                    } else {
	                        obj.effect = function() {
	                            event.evt.player.addgjzbuff("dongjied");
	                        };
	                    }
	                    that.addtriggerbuff({
	                        info: {
	                            hsdmg: obj
	                        }
	                    });
	                } else if (word == "jianwang") {
	                    var obj = ({
	                        half: true,
	                        fl: true,
	                        filter: function(evt, p, f) {
	                            return evt.target.sctp("myside_", t => t.HSF("alive"));
	                        },
	                        effect: function() {
	                            var ntg = event.evt.target.sctp("myside_")
	                                .filter(t => t.HSF("alive"))
	                                .randomGet();
	                            event.orievt.victim = ntg;
	                        },
	                    });
	                    that.addtriggerbuff({
	                        info: {
	                            attackBefore: obj
	                        }
	                    });
	                }
	                word = [word];
	            }
	            var bo = that.smtp == "S";
	            var obj = {
	                type: "ability",
	                value: word,
	                temp: num,
	            };
	            that.addhsbuff(obj);
	            setTimeout(function() {
	                if (that.smtp == "S" && that.HSF("alive")) {
	                    that.updatehsfl();
	                    delete that.smtp;
	                }
	            }, bo ? 1800 : 1000);
	            return obj;
	        },
	        addztbuff: function(zt, num) { //加状态buff
	            var that = this;
	            if (typeof zt == "string") zt = [zt];
	            var obj = {
	                type: "status",
	                value: zt,
	                temp: num,
	            };
	            that.addhsbuff(obj);
	            return obj;
	        },
	        addtriggerbuff: function(card, num, recheck) { //加扳机buff
	            var that = this;
	            var info = null;
	            if (card && card.info) {
	                info = card.info;
	                card = card.creator || that;
	            }
	            var obj = {
	                type: "trigger",
	                value: [],
	                player: get.player(),
	                creator: card,
	                fellow: that,
	                num: num,
	            };
	            if (!info) {
	                if (get.itemtype(card) == "card") info = card.HSF("info");
	                else if (get.itemtype(card) == "player") info = lib.skill[card.name];
	                else get.hs_alt("addtriggerbuff:info不存在");
	            }
	            get.HSA("triggers")
	                .forEach(i => {
	                if (info[i]) {
	                    var item = typeof info[i] == "function" ? {
	                        effect: info[i]
	                    } : get.copy(info[i]);
	                    item.triname = i;
	                    item.anm = info.anm;
	                    item.creator = card;
	                    item.fellow = that;
	                    item.relabuff = obj;
	                    if (!["battleRoal", "jili", "deathFL", "discarded"].contains(i)) {
	                        if (!that.triggers[i]) that.triggers[i] = [];
	                        that.triggers[i].add(item);
	                    } else that.triggers[i] = item;
	                    obj.value.add(item);
	                    if (item.recheck === undefined && recheck) item.recheck = "filter";
	                }
	            });
	            if (obj.value.length) that.addhsbuff(obj);
	            return obj;
	        },
	        addaurasbuff: function(name, f, num) { //加光环buff
	            var that = this;
	            var obj = {};
	            if (typeof name == "string") obj.name = name;
	            else obj = get.copy(name);
	            if (f) obj.value = f;
	            if (num) obj.temp = num;
	            obj.type = "auras";
	            obj.sleep = true;
	            obj.creator = that;
	            obj.fellow = that;
	            obj.leader = that.getLeader();
	            if (!obj.range) obj.range = "mine_";
	            if (typeof obj.range == "string") obj.range = get.HSA("funcs")[obj.range];
	            that.addhsbuff(obj);
	            return obj;
	        },
	        addFqbuff: function(name, f, num) { //加法强buff(其他buff)
	            var that = this;
	            var obj = {
	                name: name,
	                type: name,
	                value: f,
	                temp: num,
	                creator: that,
	                fellow: that,
	                leader: that.getLeader(),
	            };
	            that.addhsbuff(obj);
	            return obj;
	        },
	        addjinubuff: function(obj) { //加激怒buff
	            var that = this;
	            var f = function(p, f) {
	                return f.isDamaged();
	            };
	            var o = this.addgjzbuff("jinu");
	            o.filter = f;
	            if (obj.value) {
	                var a = that.addvaluebuff(obj.value);
	                a.filter = f;
	            }
	            if (obj.ability) {
	                var b = that.addgjzbuff(obj.ability);
	                b.filter = f;
	            }
	        },
	        addwpbuff: function() { //添加武器buff
	            var that = this;
	            var wp = that.data_weapon,
	                vbuff, gbuff;
	            for (var i = 0; i < arguments.length; i++) {
	                if (typeof arguments[i] == "number") vbuff = arguments[i];
	                else if (typeof arguments[i] == "string") gbuff = arguments[i];
	                else if (Array.isArray(arguments[i])) vbuff = arguments[i];
	                else if (arguments[i] && arguments[i].classList) {
	                    if (arguments[i].classList.contains("hs_wp")) wp = arguments[i];
	                }
	            }
	            if (vbuff) wp.addvaluebuff(vbuff);
	            if (gbuff) wp.addgjzbuff(gbuff);
	        },
	        findhsbuff: function(name) { //根据名字寻找buff
	            if (!name) return null;
	            for (var i = 0; i < this.buff.length; i++) {
	                var j = this.buff[i];
	                if (j.name == name) return j;
	            }
	            return null;
	        },
	        removehsbuff: function(obj) { //移除buff
	            var that = this;
	            if (Array.isArray(obj)) {
	                obj.forEach(i => that.removehsbuff(i));
	                return;
	            }
	            if (obj.type == "value" && obj.value) {
	                if (obj.subtype != "final" && (typeof obj.value != "function") && obj.value[1] > 0) {
	                    var v = obj.value[1];
	                    that.hs_dm = Math.max(0, that.hs_dm - v);
	                }
	            }
	            if (obj.name == "value" && obj.type == "auras" && obj.value) {
	                if (obj.subtype != "final" && (typeof obj.value != "function") && obj.value[1] > 0) {
	                    var v = obj.value[1];
	                    game.filterPlayer(p => obj.range(that, p))
	                        .forEach(p => {
	                        p.hs_dm = Math.max(0, p.hs_dm - v);
	                    });
	                }
	            }
	            if (obj.type == "trigger") {
	                var tris = get.HSA("triggers");
	                tris.forEach(i => {
	                    var tr = that.triggers[i];
	                    if (tr && tr.length) {
	                        tr.removeArray(obj.value);
	                    }
	                });
	            }
	            if (obj.onremove) obj.onremove(that);
	            that.buff.remove(obj);
	        },
	        updateSelfBuff: function(value, temp) { //更新随从牌面的buff
	            if (typeof value == "number") value = [value, 0];
	            var p = this;
	            var id = p.playerid;
	            var name = p.name + "_" + id;
	            var obj = p.buff.findLast(i => i.name == name);
	            if (!obj || p.buff.slice(p.buff.indexOf(obj) + 1)
	                .filter(i => i.type == "value")
	                .length) {
	                p.addvaluebuff(value, temp, name);
	                get.HSF("checkfellow");
	            } else {
	                if (obj.tvalue == undefined) obj.tvalue = get.copy(obj.value);
	                obj.tvalue[0] += value[0];
	                obj.tvalue[1] += value[1];
	                setTimeout(function() {
	                    if (obj.iswork() && value[0] > 0 && value[1] == 0 && !p.classList.contains("jinu")) p.animate("kuangbao", 700);
	                }, 100);
	            }
	        },
	        hasgjz: function(word) { //有关键字
	            var that = this;
	            if (that.buff.some(i => i.iswork() && i.type == "ability" && i.value.contains(word))) return true;
	            else {
	                if (get.itemtype(that) != "player") return false;
	                else {
	                    var bo1 = that.predata_weapon && that.predata_weapon.hasgjz(word);
	                    var bo2 = that.data_weapon && that.data_weapon.hasgjz(word);
	                    return bo1 || bo2 || that.sctp("all", y => y.buff.some(i => i.name == "ability" && i.type == "auras" && i.value.contains(word) && i.iswork() && i.inrange(that) && (!i.ghfilter || i.ghfilter(null, y, that))));
	                }
	            }
	        },
	        removegjz: function(word) { //失去关键字buff
	            var that = this;
	            if (Array.isArray(word)) {
	                word.forEach(i => {
	                    that.removegjz(i);
	                });
	                return;
	            }
	            if (that.buff) {
	                var bin = [];
	                for (var i of that.buff) {
	                    if (i.type == "ability" && i.value.contains(word)) {
	                        i.value.remove(word);
	                        if (i.value.length == 0) bin.add(i);
	                    }
	                }
	                that.removehsbuff(bin);
	            }
	            if (get.itemtype(that) == "player" && !that.isMin() && that.data_weapon) that.data_weapon.removegjz(word);
	        },
	        scpl: function(str) { //根据字符串获取角色
	            if (get.itemtype(str) == "player") return str;
	            var full = ["self", "me", "enemy", "leader", "oppo", "fellow"];
	            if (full.contains(str)) str = "SMELOF" [full.indexOf(str)];
	            var obj = {
	                S: this,
	                M: game.me,
	                E: game.enemy,
	                L: this.getLeader(),
	                O: this.getLeader()
	                    .getOppo(),
	                F: _status.event.fellow,
	            };
	            return obj[str] || get.player();
	        },
	        sctp: function(str, mr) { //根据字符串获取角色们
	            if (get.itemtype(str) == "players") return str;
	            var notthis;
	            if (!str) str = "mr";
	            if (typeof str == "string" && str.slice(-1) == "_") {
	                str = str.slice(0, -1);
	                notthis = true;
	            }
	            var full = ["minors"];
	            if (full.contains(str)) str = ["mns"][full.indexOf(str)];
	            var obj = {
	                mns: get.HSF("minors"),
	                heros: [this.getLeader(), this.getLeader()
	                    .getOppo()],
	                main: [get.hs_main(), get.hs_main()
	                    .getOppo()],
	                me: game.me.getFellowN(),
	                enemy: game.enemy.getFellowN(),
	                myside: this.getLeader()
	                    .getFellowN(),
	                opposide: this.getLeader()
	                    .getOppo()
	                    .getFellowN(),
	                mine: this.getLeader()
	                    .getFellow(),
	                notmine: this.getLeader()
	                    .getOppo()
	                    .getFellow(),
	                neighbor: this.HSF("alive", [true]) ? [this.leftseat, this.rightseat].filter(i => i) : [],
	                all: game.filterPlayer(),
	                field: [game.me.data_weapon, game.me.predata_weapon, game.enemy.data_weapon, game.enemy.predata_weapon].filter(i => i)
	                    .concat(game.filterPlayer()),
	                mr: (typeof mr == "string" ? this.sctp(mr) : game.filterPlayer())
	            };
	            var res = obj[str] || [];
	            if (notthis) res.remove(this);
	            if (typeof mr == "function") return res.eachsome(mr);
	            if (get.itemtype(mr) == "player") return res.contains(mr);
	            return res;
	        },
	        //新事件函数
	        hs_Missiles: function(num, bo, range) { //导弹效果
	            var next = game.createEvent("hs_Missiles", false);
	            next.player = this;
	            next.num = num || 3;
	            if (bo) {
	                next.num += next.player.countFq();
	                next.num *= next.player.HSF("countvelen");
	            }
	            next.ng = range;
	            next.setContent(function() {
	                "step 0"
	                event.i = 0;
	                "step 1"
	                event.pls = player.sctp(event.ng, "opposide")
	                    .filter(t => t.canhsdmg());
	                if (event.pls.length) {
	                    var t = event.pls.randomGet();
	                    player.HSline(t, "green");
	                    t.hs_dmgrcv("damage", player);
	                    event.i++;
	                } else event.goto(3);
	                "step 2"
	                game.delay();
	                if (event.i < event.num) event.goto(1);
	                "step 3"
	            });
	        },
	        hs_spellEffect: function(c, t, eff) { //魔法效果
	            var next = game.createEvent("hs_spellEffect", false);
	            next.card = c;
	            next.cards = [c];
	            next.player = this;
	            next.target = t;
	            next.active = eff;
	            var f = get.info(c);
	            if (!next.target && f.randomRT) {
	                next.target = f.randomRT(this);
	                if (Array.isArray(next.target)) {
	                    next.targets = next.target;
	                    next.target = next.targets[0];
	                }
	                next.filterStop = function() {
	                    if (!this.target) {
	                        delete this.filterStop;
	                        this.finish();
	                        this._triggered = null;
	                        return true;
	                    }
	                };
	            }
	            if (next.target && !next.targets) next.targets = [next.target];
	            if (next.target) {
	                this.HSline(next.targets, "green");
	                if (next.targets.length == 1) game.log(this, "对", (next.target == this ? "#b自己" : next.target), "使用了", c);
	                else game.log(this, "对", next.targets, "使用了", c);
	            } else game.log(this, "使用了", c);
	            next.effect = f.content || lib.filter.all;
	            next.setContent(function() {
	                "step 0"
	                game.delay();
	                "step 1"
	                event.insert(event.effect, {
	                    player: player,
	                    target: target,
	                    targets: targets,
	                    card: card,
	                    cards: cards,
	                    active: event.active
	                });
	            });
	            return next;
	        },
	        hs_battleRoal: function(t, f) { //战吼
	            var that = this;
	            if (get.itemtype(that) != "player") that = that.equiping;
	            var next = game.createEvent("hs_battleRoal", false);
	            next.fellow = this;
	            next.player = that.getLeader();
	            next.target = t;
	            if (!next.target && f.randomRT) {
	                if (!next.target && f.randomRT) {
	                    next.target = f.randomRT(next.player, next);
	                    if (!next.target) {
	                        next.setContent(function() {});
	                        return;
	                    }
	                }
	            }
	            next.effect = f.effect;
	            next.setContent(function() {
	                "step 0"
	                game.delay(0.5);
	                "step 1"
	                var ch = function(p) {
	                    if (get.itemtype(p) == "player") return p;
	                    return p.linkCard[0];
	                };
	                if (target) {
	                    event.fellow.HSline(target, "green");
	                    game.log(ch(event.fellow), "对", (target == event.fellow ? "#b自己" : ch(target)), "发动了战吼效果");
	                } else game.log(ch(event.fellow), "发动了战吼效果");
	                event.insert(event.effect, {
	                    player: player,
	                    fellow: event.fellow,
	                    target: target
	                });
	            });
	            return next;
	        },
	        hs_trisEffect: function(obj, evt) { //扳机效果
	            if (this.swt && !this.HSF("alive")) return;
	            var next = game.createEvent("hs_trisEffect", false);
	            next.fellow = this;
	            next.player = this.getLeader();
	            var cancel = false;
	            if (obj.half) {
	                if (Math.random() < 0.5) {
	                    if (evt.evt.triedeff) evt.evt.triedeff.add(obj);
	                    cancel = true;
	                }
	            }
	            if (obj.randomRT) {
	                next.target = obj.randomRT(next.player, evt, next.fellow);
	                if (!next.target) cancel = true;
	            }
	            if (obj.recheck) {
	                if (obj.recheck == "filter") obj.recheck = obj.filter || lib.filter.all;
	                if (typeof obj.recheck == "string") {
	                    var arr = obj.recheck.split(",");
	                    if (arr.length == 1) {
	                        var f = get.HSA("funcs")[arr[0]];
	                        if (f) obj.recheck = f;
	                        else get.hs_alt("hs_trisEffect:", obj.recheck);
	                    } else {
	                        var fs = arr.map(i => get.HSA("funcs")[i]);
	                        var ff = function(e, p, f) {
	                            return ff.fs.every(i => i(e, p, f));
	                        };
	                        ff.fs = fs;
	                        obj.recheck = ff;
	                    }
	                }
	                if (!obj.recheck(evt, next.player, this, obj)) cancel = true;
	            }
	            if (cancel || !game.me.sctp("field", this)) {
	                next.setContent(function() {});
	                return next;
	            }
	            next.effect = obj.effect;
	            if (!next.effect) {
	                get.hs_alt("hs_trisEffect:效果内容不存在。\n", obj);
	                next.effect = lib.filter.all;
	            }
	            next.evt = evt;
	            next.anm = obj.anm;
	            next.obj = obj;
	            if (obj.triname == "jili") next.tp = "hs_jl";
	            else if (next.evt.name == "hsdmg") {
	                if (obj.alias == "剧毒") next.tp = "hs_jd";
	                else if (obj.alias == "冻结") next.tp = "none";
	                else next.tp = "hs_bj";
	            } else next.tp = "hs_bj";
	            next.setContent(function() {
	                "step 0"
	                if (event.obj.charlotte || event.obj.direct) event.goto(4);
	                else {
	                    if (event.evt.name == "summonSucc") game.delay(1.1);
	                    else game.delay(0.5);
	                }
	                "step 1"
	                if ([game.me, game.me.data_weapon, game.me.predata_weapon].contains(event.fellow)) get.HSF("clickmana", [false]);
	                if (target && [game.me, game.me.data_weapon, game.me.predata_weapon, game.me.heroskill].contains(target)) get.HSF("clickmana", [false]);
	                if (event.tp != "none") {
	                    var dom = event.fellow.querySelector('.' + event.tp);
	                    if (!dom) get.hs_alt("no dom:", event.tp);
	                    dom.animate('active');
	                }
	                get.HSF("Aud", [event.fellow, "trigger"]);
	                game.delay();
	                "step 2"
	                var ch = function(p) {
	                    if (get.itemtype(p) == "player") return p;
	                    return p.linkCard[0];
	                };
	                if (target) {
	                    event.fellow.HSline(target, "green");
	                    game.log(player, "的", ch(event.fellow), "对", (target == event.fellow ? "#b自己" : ch(target)), "触发了扳机");
	                } else game.log(player, "的", ch(event.fellow), "触发了扳机");
	                "step 3"
	                if (event.evt.name == "summonSucc") game.delay(0.3);
	                "step 4"
	                event.insert(event.effect, {
	                    player: player,
	                    target: target,
	                    fellow: event.fellow,
	                    obj: event.obj,
	                    evt: event.evt,
	                    orievt: event.evt.evt,
	                    anm: event.anm,
	                });
	                "step 5"
	                if (!event.isMine()) game.delay(0.5);
	            });
	            return next;
	        },
	        hs_deathRattle: function(f) { //亡语
	            var next = game.createEvent("hs_deathRattle", false);
	            next.fellow = this;
	            next.player = this.getLeader();
	            next.effects = f;
	            if (!next.effects) next.effects = next.fellow.triggers.deathRattle;
	            if (!next.effects) next.effects = [{
	                effect: function() {}
	            }];
	            next.setContent(function() {
	                "step 0"
	                event.wyed = 0; //结算过亡语（全部）次数
	                "step 1"
	                event.i = 0; //从第一个亡语开始结算
	                event.eff = event.effects[event.i];
	                event.num = (get.itemtype(event.fellow) == "player" && player.hasAuras("doubledeathrattle")) ? 2 : 1;
	                "step 2"
	                event.target = null;
	                if (event.eff.randomRT) {
	                    event.target = event.eff.randomRT(player);
	                    if (!event.target) event.goto(4);
	                }
	                var ch = function(p) {
	                    if (get.itemtype(p) == "player") return p;
	                    return p.linkCard[0];
	                };
	                if (event.target) {
	                    if ([game.me, game.me.data_weapon, game.me.predata_weapon, game.me.heroskill].contains(event.target)) get.HSF("clickmana", [false]);
	                    if (event.fellow.isMin()) {
	                        event.fellow.HSline(event.target, "green");
	                        game.log(ch(event.fellow), "对", ch(event.target), "发动了亡语效果");
	                    } else {
	                        event.fellow.HSline(event.target, "green");
	                        game.log(ch(player), "的", ch(event.fellow), "对", ch(event.target), "发动了亡语效果");
	                    }
	                } else {
	                    if (event.fellow.isMin()) game.log(ch(event.fellow), "发动了亡语效果");
	                    else game.log(ch(player), "的", ch(event.fellow), "发动了亡语效果");
	                }
	                "step 3"
	                event.insert(event.eff.effect, {
	                    player: player,
	                    fellow: event.fellow,
	                    target: event.target
	                });
	                "step 4"
	                event.i++;
	                get.HSF("updateauras", [true]);
	                if (event.i < event.effects.length) {
	                    game.delay();
	                    event.goto(2);
	                }
	                "step 5"
	                event.wyed++;
	                if (event.wyed < event.num) {
	                    game.delay();
	                    event.goto(1);
	                }
	            });
	            return next;
	        },
	        hs_discard: function(num) { //弃牌
	            var next = game.createEvent("hs_discard", false);
	            next.player = this;
	            if (num == "all") num = this.countCards("h");
	            next.num = num || 1;
	            next.setContent(function() {
	                "step 0"
	                var cs = player.getCards("h");
	                if (cs.length) {
	                    var cards = cs.randomGets(num);
	                    event.cards = cards;
	                    game.log(player, "弃置了", cards);
	                    player.lose(cards, ui.special);
	                    player.$throw(cards);
	                    setTimeout(function() {
	                        ui.clear();
	                        player.discardPile.directgain(cards);
	                        get.HSF("checkhand");
	                    }, 500);
	                } else event.finish();
	                "step 1"
	                game.delay(0.5);
	                "step 2"
	                var evts = [];
	                event.cards.forEach(i => {
	                    evts.push({
	                        player: player,
	                        card: i,
	                    });
	                });
	                get.HSF("evts", ["discard", evts]);
	                "step 3"
	                get.HSF("updateauras", [true]);
	            });
	        },
	        hs_gain: function(cards, source, visible) { //获得牌
	            if (!cards.length) return;
	            var next = game.createEvent("hs_gain", false);
	            next.player = this;
	            next.cards = cards;
	            if (typeof cards == "string" || cards.length === undefined) next.cards = [cards];
	            if (cards.length == 2 && typeof cards[1] == "number") next.cards = get.HSF("repeat", [cards[0], cards[1]]);
	            next.source = source;
	            next.visible = visible;
	            next.setContent(function() {
	                "step 0"
	                if (!event.result) event.result = {
	                    cards: []
	                };
	                if (player.countCards("h") < player.getHandcardLimit()) {
	                    var c = cards.shift();
	                    if (get.itemtype(c) != "card") {
	                        c = get.chscard(c);
	                        c.hs_temp = true;
	                    }
	                    event.result.cards.add(c);
	                    player.directgain([c]);
	                    c.hs_creator = _status.event.fellow || player;
	                    if (event.visible !== false) player.$gain2(player == game.me ? c : lib.hearthstone.enemycard, event.source);
	                    get.HSF("checkhand");
	                    if (cards.length) {
	                        game.delay(0.1);
	                        event.redo();
	                    }
	                }
	            });
	        },
	        hs_dmgrcv: function() { //伤害&&治疗
	            var next = game.createEvent("hs_dmgrcv", false);
	            next.player = this;
	            for (var i = 0; i < arguments.length; i++) {
	                if (typeof arguments[i] == "number") next.num = arguments[i];
	                else if (typeof arguments[i] == "string") {
	                    if (arguments[i] == "sgs") next.sgs = true;
	                    else if (arguments[i] == "recover") next.type = "recover";
	                    else if (arguments[i] == "damage") next.type = "damage";
	                    else if (arguments[i] == "nocard") next.nocard = true;
	                    else if (arguments[i] == "nosource") next.nosource = true;
	                    else if (["ice", "fire", "thunder"].contains(arguments[i])) next.nature = arguments[i];
	                    else next.sctp = arguments[i];
	                } else if (get.itemtype(arguments[i]) == "player") next.source = arguments[i];
	                else if (get.itemtype(arguments[i]) == "card") next.card = arguments[i];
	                else if (get.itemtype(arguments[i]) == "cards") next.cards = arguments[i];
	            }
	            if (!next.card) {
	                if (next.cards) next.card = next.cards[0];
	                else next.card = _status.event.card;
	            }
	            if (!next.cards && next.card) next.cards = [next.card];
	            if (next.nocard) {
	                delete next.card;
	                delete next.cards;
	            }
	            if (!next.source) next.source = this.scpl(next.sctp);
	            if (!next.source) next.nosource = true;
	            if (next.nosource) delete next.source;
	            if (!next.type) next.type = "damage";
	            if (next.num === undefined) next.num = 1;
	            next.num = Math.max(0, next.num);
	            if (next.sgs) next.num *= 10;
	            next.setContent("hs_dmgrcv");
	            return next;
	        },
	        hs_dmgrcvbt: function(tg) { //战斗伤害
	            var p = this;
	            var evts = [];
	            if (p.ATK) evts.add({
	                source: p,
	                player: tg,
	                num: p.ATK
	            });
	            if (tg.ATK) evts.add({
	                source: tg,
	                player: p,
	                num: tg.ATK
	            });
	            if (evts.length) {
	                var next = game.createEvent("hs_dmgrcv", false);
	                next.evts = evts;
	                next.setContent("hs_dmgrcvbt");
	                return next;
	            } else return;
	        },
	        hs_dmgrcvaoe: function() { //aoe伤害&&治疗
	            var next = game.createEvent("hs_dmgrcv", false);
	            next.player = this;
	            for (var i = 0; i < arguments.length; i++) {
	                if (typeof arguments[i] == "number") next.num = arguments[i];
	                else if (typeof arguments[i] == "string") {
	                    if (arguments[i] == "recover") next.type = "recover";
	                    else if (arguments[i] == "damage") next.type = "damage";
	                    else if (arguments[i] == "nocard") next.nocard = true;
	                    else if (arguments[i] == "nosource") next.nosource = true;
	                    else if (arguments[i] == "nodelay") next.nodelay = true;
	                    else if (["ice", "fire", "thunder"].contains(arguments[i])) next.nature = arguments[i];
	                    else next.sctp = arguments[i];
	                } else if (get.itemtype(arguments[i]) == "player") next.source = arguments[i];
	                else if (get.itemtype(arguments[i]) == "players") next.targets = arguments[i];
	                else if (get.itemtype(arguments[i]) == "card") next.card = arguments[i];
	                else if (get.itemtype(arguments[i]) == "cards") next.cards = arguments[i];
	                else if (Array.isArray(arguments[i]) && arguments[i].length == 2) next.expo = arguments[i];
	            }
	            if (!next.source && next.sctp) next.source = this.scpl(next.sctp);
	            if (!next.source) next.nosource = true;
	            if (next.nosource) delete next.source;
	            if (!next.type) next.type = "damage";
	            if (next.num === undefined) next.num = 1;
	            next.num = Math.max(0, next.num);
	            if (next.targets && next.targets.length > 0) next.setContent("hs_dmgrcvaoe");
	            else next.setContent("emptyHSwait");
	            return next;
	        },
	        SSfellow: function(fls, oppo, anm, extra) { //召随从
	            var l = this.getLeader();
	            if (oppo) l = l.getOppo();
	            if (l.hs_full()) return;
	            var next = game.createEvent("SSfellow", false);
	            next.player = l;
	            if (this.isMin()) next.fellow = this;
	            next.leader = this.getLeader();
	            if (typeof fls == "string") {
	                next.fls = [fls];
	            } else next.fls = fls;
	            if (next.fls.length == 1 && next.fls[0].contains(":")) {
	                if (next.fls[0].indexOf("cdset:") == 0) {
	                    var st = next.fls[0].slice(6);
	                    next.fls = [get.HSA("collect")[st].randomGet()];
	                } else if (next.fls[0].indexOf("range:") == 0) {
	                    var st = next.fls[0].slice(6);
	                    var arr = st.split(",");
	                    var fil = get.hsflt(arr);
	                    var kc = get.hskachi("HS_minor", fil);
	                    next.fls = [kc.randomGet()];
	                }
	            }
	            if (next.fls.length == 2) {
	                if (typeof next.fls[1] == "number") {
	                    next.fls = get.HSF("repeat", [next.fls[0], next.fls[1]]);
	                }
	            }
	            if (next.fls[1] != undefined && typeof next.fls[1] != "string") {
	                get.hs_alt("SSfellow异常：", next.fls);
	            }
	            if (next.fls.some(i => !i.contains("_monster") && get.type(get.HSF("getEN", [i])) != "HS_minor")) {
	                get.hs_alt(next.fls.join(","), ":包含非随从牌");
	            }
	            next.oppo = oppo;
	            next.anm = anm || _status.event.anm;
	            if (extra) next.extra = extra;
	            next.setContent(function() {
	                "step 0"
	                event.num = event.fls.length;
	                event.i = 0;
	                event.toadd = [];
	                "step 1"
	                if (player.hs_full()) event.goto(10);
	                "step 2"
	                var p = player;
	                var nam = event.fls[event.i];
	                var cards = [get.chscard(nam)];
	                nam = cards[0].name;
	                var info = get.info({
	                    name: nam
	                });
	                var name = nam.slice(0, nam.indexOf('_monster'));
	                var pos = (function(evt) {
	                    var m = p.countFellow();
	                    var n = p == game.me ? 0 : get.hs_nm();
	                    var fh = evt.extra && evt.extra.contains("复活");
	                    if (fh) evt.notrigger = true;
	                    if (fh || evt.oppo || !evt.fellow) return m + n + 2;
	                    else if (game.dead.contains(evt.fellow)) { //亡语召怪
	                        var o = Math.ceil(evt.fellow.truepos);
	                        while (evt.toadd.filter(fl => {
	                            return fl.HSF("alive") && fl.dataset.position == o + "";
	                        })
	                            .length) {
	                            o++;
	                        }
	                        return o;
	                    } else { //战吼召怪
	                        var o = parseInt(evt.fellow.dataset.position);
	                        var i = evt.i;
	                        var dr = Math.pow(-1, i);
	                        var j = 1;
	                        var res = o + dr * j;
	                        if (dr < 0) res++;
	                        res = Math.max(n + 2, res);
	                        return res;
	                    }
	                })(event);
	                var left = !event.oppo && event.fellow && !game.dead.contains(event.fellow) && parseInt(event.fellow.dataset.position) >= pos;
	                p.hs_place(pos);
	                var fellow = game.addFellow(pos, name);
	                fellow.side = p.side;
	                fellow.hs_FL(cards, "S");
	                event.cs = cards;
	                if (event.extra && event.extra.contains("复制")) fellow.addvaluefinal([1, 1]);
	                var dft = !event.oppo && event.fellow && !game.dead.contains(event.fellow) && event.num > 1 ? "呼出" : "冒出";
	                var rcdhs = fellow.hs_rcdh(pos, left, event.anms, event.anm, dft);
	                event.rcdh = rcdhs[0];
	                event.rctm = rcdhs[1];
	                p.actcharacterlist.add(fellow)
	                    .sort(lib.sort.position);
	                event.link = fellow;
	                if (event.oppo) game.log((event.fellow || event.leader), "召唤了", fellow, "到", p, "场上");
	                else game.log((event.fellow || event.leader), "召唤了", fellow);
	                "step 3"
	                var plp = function() {
	                    get.HSF("Aud", [event.cs[0], "play", player]);
	                };
	                setTimeout(plp, event.rctm);
	                player.HSF("hsdouble");
	                event.link.hs_yin(event.rctm);
	                _status.hsAttendSeq.ad(event.link);
	                event.toadd.add(event.link);
	                get.HSF("arrange");
	                "step 4"
	                if (event.notrigger) event.goto(7);
	                "step 5"
	                //增加"预召唤"的时机
	                get.HSF("event", ["summonBefore", {
	                    player: player,
	                    card: event.cs[0],
	                    link: event.link
	                }]);
	                "step 6"
	                //增加"召唤后"的时机
	                if (event.link.HSF("alive")) get.HSF("event", ["summonAfter", {
	                    player: player,
	                    card: event.cs[0],
	                    link: event.link
	                }]);
	                "step 7"
	                event.i++;
	                if (event.i < event.num && !player.hs_full()) {
	                    event.goto(1);
	                }
	                "step 8"
	                game.delay(get.hslegend(event.link) ? 1 : 0.5);
	                if (event.notrigger) event.goto(10);
	                "step 9"
	                event.toadd = event.toadd.filter(i => i.HSF("alive"));
	                event.toadd.forEach(t => {
	                    if (t.name == "hs_Hound") {
	                        setTimeout(function() {
	                            t.animate("kuangbao", 700);
	                        }, 1000);
	                    }
	                });
	                if (event.toadd.length) player.HSF("hs_rever", [event.toadd])
	                "step 10"
	                if (!event.isMine()) game.delay(0.5);
	            });
	            return next;
	        },
	        //简化命令
	        HSF: function(name, args) { //调用get.HSF，第一个参数传入this
	            return get.HSF(name, [this].concat(args));
	        },
	        HSFT: function(tc, order) { //说台词
	            var p = this;
	            var key = (tc.contains("错误") || ["牌库快空", "牌库空", "爆牌"].contains(tc)) ? "common" : lib.translate[this.name];
	            var words = get.HSA("台词")[key];
	            if (!words) {
	                p.say("[ERROR]找不到台词！！");
	                return;
	            }
	            if (tc == "开局") {
	                if (order && game.me.name == game.enemy.name) tc = "镜像开局";
	                else {
	                    var oppo = get.translation(p.next.name);
	                    if (words[oppo]) tc = oppo;
	                }
	            }
	            if (!words[tc]) return;
	            var tsay = words[tc];
	            if (Array.isArray(tsay)) tsay = tsay.randomGet();
	            this.say(tsay);
	            if (!this.isMin()) {
	                var tm = this.HSF("Aud3", [tc]);
	                return tm;
	            }
	        },
	    };
	    for (var i in playerFs) {
	        hearthstone.player[i] = playerFs[i];
	    }
	    /////////////////////////////////////////////////

	    //新框架
	    var cardE = { //卡牌相关函数
	        cost: function() { //获取牌的费用
	            var that = this;
	            var info = get.info({
	                name: that.name
	            });
	            if (!info) get.hs_alt(that.name + "找不到cost");
	            var cost = info.cost;
	            if (cost === undefined) return 0;
	            var player = get.owner(that);
	            if (!player) return cost;
	            var buffs = that.buff.filter(i => i.iswork() && i.name == "hs_cost")
	                .concat(player.sctp("field")
	                .reduce((x, y) => x.concat(y.buff.filter(i => i.ghwork("hs_cost", null, [that, y, player]))), []));
	            buffs.sort(lib.sort.attendseq);
	            buffs.forEach(i => {
	                if (i.subtype == "final") cost = i.value;
	                else {
	                    var vl = i.value;
	                    if (typeof vl == "function") vl = vl(that, cost);
	                    cost -= vl;
	                }
	            });
	            if (info.changecost) cost -= info.changecost(player);
	            cost = Math.max(0, cost);
	            return cost;
	        },
	    };
	    var conE = { //事件
	        hs_exchange: function() { //开局调度
	            "step 0"
	            game.zhu.next.hs_drawDeck("notrigger");
	            "step 1"
	            if (!get.HSF("cfg", ["HS_debug"])) game.delay(3);
	            "step 2"
	            var coin = ui.arena.querySelector(".hs_coin:not(.second)")
	            if (coin) coin.delete();
	            game.me.hs_exchange2();
	        },
	        greeting: function() { //开局
	            "step 0"
	            ui.arena.querySelector(".hs_vs")
	                .delete();
	            if (get.hs_nm() == 7) {
	                ui.arena.querySelector(".hs_mefull")
	                    .delete();
	                ui.arena.querySelector(".hs_enemyfull")
	                    .delete();
	                ui.arena.querySelector(".hs_mejob")
	                    .delete();
	                ui.arena.querySelector(".hs_enemyjob")
	                    .delete();
	            }
	            game.me.style.transition = "all 0.5s";
	            game.enemy.style.transition = "all 0.5s";
	            ui.arena.classList.remove("hs_kaichang2");
	            var zhu = game.zhu;
	            var oppo = zhu.getOppo();
	            setTimeout(function() {
	                ui.arena.classList.remove("hs_kaichang");
	                var ty = function(p, b) {
	                    var tm = p.HSFT("开局", b);
	                    setTimeout(function() {
	                        p.classList.remove("bright");
	                    }, 1600);
	                    return tm;
	                };
	                var ddsj = ty(oppo);
	                setTimeout(function() {
	                    if (get.hs_nm() == 7) {
	                        setTimeout(function() {
	                            var coin = ui.create.div(".bright.hs_coin", ui.arena);
	                            ui.create.div(".img", coin)
	                            ui.create.div(".comet1", coin);
	                            ui.create.div(".comet2", coin);
	                            event.coin = coin;
	                            setTimeout(function() {
	                                get.HSF("first");
	                                var coin = event.coin;
	                                coin.classList.add("result");
	                                var bang = ui.create.div(".bright.arrowbang", ui.arena);
	                                bang.animate("start");
	                                var bo = game.zhu == game.me;
	                                bang.innerHTML = bo ? "你抢到了先攻" : "你可以多抽一张牌";
	                                setTimeout(function() {
	                                    bang.delete();
	                                }, 1500);
	                                if (!bo) coin.classList.add("second");
	                                get.HSF("eee", ["hs_exchange"]);
	                            }, 1000);
	                        }, 200);
	                    }
	                    setTimeout(function() {
	                        ty(zhu, true);
	                    }, ddsj * 1000);
	                }, 500);
	            }, 500);
	            "step 1"
	            game.zhu.cardPile.give(game.zhu.cardPile.getCards("h")
	                .randomGets(3), game.zhu);
	            game.zhu.next.cardPile.give(game.zhu.next.cardPile.getCards("h")
	                .randomGets(3), game.zhu.next);
	            "step 2"
	            game.delay(2);
	            "step 3"
	            var ele = document.querySelector("#handcards1>div");
	            ele.style.transition = "all 0.5s";
	            ele.towork = true;
	            "step 4"
	            game.delay();
	            "step 5"
	            game.me.mana.listen(function() {
	                if (this.classList.contains("memana")) lib.hearthstone.funcs.clickmana();
	            });
	            game.enemy.mana.listen(function() {
	                if (this.classList.contains("memana")) lib.hearthstone.funcs.clickmana();
	            });
	            "step 6"
	            ui.arena.classList.remove("hs_exchange");
	            get.HSF("checkhand");
	            lib.hearthstone.hs_absl = ui.hs_testfl.getBoundingClientRect()
	                .left;
	            if (get.hs_nm() == 7) game.delay(2);
	            else event.goto(10);
	            "step 7"
	            var coin = ui.arena.querySelector(".hs_coin.second");
	            if (coin) {
	                coin.classList.add("gain");
	                coin.delete();
	            }
	            game.zhu.next.hs_gain("幸运币", null, false);
	            "step 8"
	            game.delay(0.5);
	            "step 9"
	            ui.arena.classList.add("recovering");
	            ui.background.style.transition = "all 3s";
	            ui.background.style.filter = "brightness(100%)";
	            var i = 0;
	            var inte = setInterval(function() {
	                game.me.style.filter = "brightness(" + (25 + i * 0.25) + "%)";
	                game.enemy.style.filter = "brightness(" + (25 + i * 0.25) + "%)";
	                i++;
	            }, 10);
	            game.pause();
	            setTimeout(function() {
	                clearInterval(inte);
	                game.me.style.filter = "";
	                game.enemy.style.filter = "";
	                ui.arena.classList.remove("hs_exchange2");
	                ui.arena.classList.remove("recovering");
	                game.resume();
	                setTimeout(function() {
	                    ui.background.style.transition = "";
	                }, 1000);
	            }, 3000);
	            "step 10"
	            _status.hsgamestart = true;
	        },
	        emptyHSevent: function() { //无阶段事件
	            "step 0"
	            get.HSF("event", [event.name.slice(0, -2), {
	                player: player
	            }]);
	            "step 1"
	            get.HSF("checkdeath");
	        },
	        emptyHSwait: function() { //什么都不发生
	            "step 0"
	            game.delay();
	            "step 1"
	        },
	        checkwin: function() { //胜负判定
	            "step 0"
	            if (game.me.hp <= 0) game.me.hs_losing = true;
	            if (game.enemy.hp <= 0) game.enemy.hs_losing = true;
	            if (game.me.hs_losing || game.enemy.hs_losing) get.HSF("think");
	            else event.finish();
	            "step 1"
	            var df = function(p) {
	                if (p.hs_losing) {
	                    p.removegjz("dongjied");
	                    p.HSF("Aud3", ["死亡"]);
	                    p.HSFT("死亡");
	                }
	            };
	            df(game.me);
	            df(game.enemy);
	            get.HSF("checkfellow");
	            if (game.me.hs_losing && game.enemy.hs_losing) {
	                game.me.$die();
	                game.enemy.$die();
	                game.players.removeArray([game.me, game.enemy]);
	                game.dead.addArray([game.me, game.enemy]);
	                game.over("平局");
	            } else if (game.me.hs_losing) game.me.die();
	            else game.enemy.die();
	            "step 2"
	        },
	        hs_use_minor: function() { //使用随从
	            "step 0"
	            //扣费阶段
	            event.usingcost = cards[0].cost();
	            player.HSF("usemana", [event.usingcost]);
	            //检测是否能触发战吼和连击
	            var name = get.HSF("tr", [card.name]);
	            var info = lib.skill[name];
	            if (info && info.battleRoal) {
	                event.hasbattleroal = true;
	                event.canzh = true;
	                if (info.battleRoal.BRfilter && !info.battleRoal.BRfilter(null, player)) event.canzh = false;
	                if (info.battleRoal.filter) {
	                    var nf = get.HSF("strfil", [info.battleRoal.filter]);
	                    info.battleRoal.filter = nf;
	                    if (!nf(player, cards[0])) event.canzh = false;
	                }
	                if (info.battleRoal.filterTarget) {
	                    event.needtarget = true;
	                    event.canzhtg = game.filterPlayer(function(target) {
	                        return player.HSF("canbetarget", [null, target, "battleroal"]) && info.battleRoal.filterTarget(card, player, target);
	                    });
	                    if (event.canzhtg.length == 0) event.canzh = false;
	                }
	            }
	            event.n = name;
	            event.info = info;
	            game.log(player, "使用了", card);
	            "step 1"
	            //扔牌动画
	            get.HSF("checkfellow");
	            game.me.HSF("hs_testfl");
	            player.lose(cards, ui.special);
	            event.node = player.$throw(cards, 500);
	            //game.delay(0.5);
	            "step 2"
	            get.HSF("checkhand");
	            "step 3"
	            //创建随从
	            var pos = player.settlehsFL();
	            player.hs_place(pos);
	            var fellow = game.addFellow(pos, event.n);
	            fellow.side = player.side;
	            fellow.hs_FL(event.cards);
	            //播放入场动画
	            var rcdhs = fellow.hs_rcdh(pos, null, null, null, "落地");
	            event.rcdh = rcdhs[0];
	            event.rctm = rcdhs[1];
	            player.actcharacterlist.add(fellow)
	                .sort(lib.sort.position);
	            //扔牌动画结束
	            if (event.node) event.node.moveDelete(fellow);
	            event.link = fellow;
	            "step 4"
	            //等待入场动画完成
	            var plp = function() {
	                get.HSF("Aud", [card, "play", player]);
	            };
	            setTimeout(plp, event.rctm);
	            player.HSF("hsdouble");
	            game.log(player, "召唤了", event.link);
	            get.HSF("morefocus", event.link.linkCard);
	            get.HSF("arrange");
	            "step 5"
	            //战吼选目标
	            if (event.hasbattleroal) {
	                if (event.needtarget && event.canzh) {
	                    var info = event.info;
	                    var tgs = event.canzhtg;
	                    if (tgs.contains(game.me)) get.HSF("clickmana", [false]);
	                    var next = player.chooseTarget((info.prompt || get.HSF("prompt", [card])), function(card, player, target) {
	                        return tgs.contains(target);
	                    }, true);
	                    next.set("pl", player);
	                    var ai = () => 1;
	                    if (info.battleRoal.aifamily) {
	                        switch (info.battleRoal.aifamily) {
	                            case "damage":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    return get.dmgEffect(target, player, player) + 0.1;
	                                };
	                                break;
	                            case "recover":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    return get.rcvEffect(target, player, player);
	                                };
	                                break;
	                            case "atk":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    if (target.summoned && !target.hasgjz("chongfeng")) return 0;
	                                    if (target.getLeader() != player) return 0;
	                                    return target.ATK == 0 ? 3 : target.ATK;
	                                };
	                            case "hp":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    if (target.getLeader() != player) return 0;
	                                    return target.hp;
	                                };
	                            default:
	                        }
	                    }
	                    next.set("ai", ai);
	                }
	            } else {
	                game.delay(event.rctm / 1000);
	                event.goto(7);
	            }
	            "step 6"
	            //是否结算战吼
	            if (event.hasbattleroal) {
	                event.willzh = false;
	                if (event.canzh) {
	                    if (event.needtarget) {
	                        if (result.bool) {
	                            event.willzh = true;
	                            event.target = result.targets[0];
	                        }
	                    } else event.willzh = true;
	                }
	            }
	            "step 7"
	            //随从进场，效果可以触发
	            event.link.hs_yin(event.rctm);
	            _status.hsAttendSeq.ad(event.link);
	            event.link.HSF("uptris");
	            player.hs_state.useCard++;
	            game.delay(get.hslegend(event.link) ? 2.4 : 1.9);
	            "step 8"
	            //反制阶段
	            get.HSF("event", ["useCardBefore", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 9"
	            player.actionHistory[player.actionHistory.length - 1].useCard.push(event);
	            if (!game.getGlobalHistory()
	                .useCard) game.getGlobalHistory()
	                .useCard = [];
	            game.getGlobalHistory()
	                .useCard.push(event);
	            if (player.stat[player.stat.length - 1].card[card.name] == undefined) {
	                player.stat[player.stat.length - 1].card[card.name] = 1;
	            } else {
	                player.stat[player.stat.length - 1].card[card.name]++;
	            }
	            //抉择变形
	            "step 10"
	            //增加"预召唤"的时机
	            get.HSF("event", ["summonBefore", {
	                player: player,
	                card: cards[0],
	                link: event.link
	            }]);
	            "step 11"
	            //使用时事件
	            get.HSF("event", ["useCard", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 12"
	            //增加"召唤时"的时机
	            get.HSF("event", ["summonSucc", {
	                player: player,
	                card: cards[0],
	                link: event.link
	            }]);
	            "step 13"
	            //过载
	            var info = get.info(card);
	            if (info.hs_gz) {
	                var num = info.hs_gz;
	                player.addMark("hs_mana_owed", num, false);
	                game.log(player, "过载了", num, "个法力水晶");
	                player.HSF("updatemana");
	                get.HSF("event", ["overload", {
	                    player: player,
	                    card: card,
	                    cards: cards,
	                    num: num,
	                }]);
	            }
	            "step 14"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 15"
	            //战吼次数
	            if (event.link.triggers.battleRoal) {
	                event.zh_num = player.hasAuras("doublebattleroal") ? 2 : 1;
	                if (event.link.triggers.battleRoal.bonus) event.zh_num += event.link.triggers.battleRoal.bonus(player, event.link);
	                event.zhed = 0;
	            } else event.goto(19);
	            "step 16"
	            //重选目标
	            if (target) get.HSF("event", ["battleRoalTo", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 17"
	            //战吼
	            event.link.animate("zhanhou");
	            if (event.willzh && (!target || target.HSF("alive", [true]))) {
	                var cancel = false;
	                var recheck = event.info.battleRoal.recheck;
	                if (recheck) {
	                    if (typeof recheck == "string") {
	                        if (recheck == "filter" && event.info.battleRoal.filter) {
	                            var fs = event.info.battleRoal.filter;
	                            var ff = function(e, p, f) {
	                                return fs(p);
	                            };
	                            recheck = ff;
	                        } else {
	                            var arr = recheck.split(",");
	                            if (arr.length == 1) {
	                                var f = get.HSA("funcs")[arr[0]];
	                                if (f) recheck = f;
	                                else get.hs_alt("战吼recheck:", recheck);
	                            } else {
	                                var fs = arr.map(i => get.HSA("funcs")[i]);
	                                var ff = function(e, p, f) {
	                                    return ff.fs.every(i => i(e, p, f));
	                                };
	                                ff.fs = fs;
	                                recheck = ff;
	                            }
	                        }

	                    }
	                    if (!recheck(null, player, event.link, event.info.battleRoal)) cancel = true;
	                }
	                if (!cancel) event.toRun = event.link.hs_battleRoal(event.target, event.link.triggers.battleRoal);
	            }
	            "step 18"
	            event.zhed++;
	            if (event.zhed < event.zh_num) {
	                get.HSF("updateauras", [true]);
	                game.delay();
	                event.goto(17);
	            }
	            "step 19"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 20"
	            //交换顺序
	            //使用后事件
	            get.HSF("event", ["useCardAfter", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 21";
	            //交换顺序
	            //增加"召唤后"的时机
	            if (event.link.HSF("alive")) get.HSF("event", ["summonAfter", {
	                player: player,
	                card: cards[0],
	                link: event.link
	            }]);
	            "step 22"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 23"
	            get.HSF("think");
	        },
	        hs_use_spell: function() { //使用法术
	            "step 0"
	            event.usingcost = cards[0].cost();
	            player.HSF("usemana", [event.usingcost]);
	            var info = get.info(card);
	            event.info = info;
	            if (info.active && info.active(player)) event.active = true;
	            if (player.HSF("manamax") == 10 && ["hs_WildGrowth", "hs_AstralCommunion"].contains(card.name)) event.hs_guosheng = true;
	            player.lose(cards, ui.special);
	            event.node = player.$throw(cards, 1000);
	            game.delay(0.5);
	            "step 1"
	            get.HSF("checkhand");
	            if (event.node) event.node.delete();
	            "step 2"
	            //法术进场
	            get.HSF("morefocus", cards);
	            get.HSF("updateauras", [true]);
	            _status.hsAttendSeq.ad(cards[0]);
	            player.hs_state.useCard++;
	            "step 3"
	            //反制阶段
	            get.HSF("event", ["useCardBefore", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 4"
	            player.actionHistory[player.actionHistory.length - 1].useCard.push(event);
	            if (!game.getGlobalHistory()
	                .useCard) game.getGlobalHistory()
	                .useCard = [];
	            game.getGlobalHistory()
	                .useCard.push(event);
	            if (player.stat[player.stat.length - 1].card[card.name] == undefined) {
	                player.stat[player.stat.length - 1].card[card.name] = 1;
	            } else {
	                player.stat[player.stat.length - 1].card[card.name]++;
	            }
	            //更换牌
	            get.HSF("event", ["useCardBegin", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 5"
	            //使用时事件
	            get.HSF("event", ["useCard", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 6"
	            //过载
	            if (event.info.hs_gz) {
	                var num = event.info.hs_gz;
	                player.addMark("hs_mana_owed", num, false);
	                game.log(player, "过载了", num, "个法力水晶");
	                player.HSF("updatemana");
	                get.HSF("event", ["overload", {
	                    player: player,
	                    card: card,
	                    cards: cards,
	                    num: num,
	                }]);
	            }
	            "step 7"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 8"
	            //计算次数
	            "step 9"
	            //重选目标
	            if (targets) get.HSF("event", ["useCardTo", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 10"
	            //结算效果
	            event.toRun = player.hs_spellEffect(cards[0], target, event.active);
	            "step 11"
	            //送墓
	            game.delay(0.5);
	            get.HSF("updateauras", [true]);
	            if (cards[0].hs_temp || get.info(card)
	                .hs_token) player.heroskill.pos.directgain(cards);
	            else player.discardPile.directgain(cards);
	            _status.hsAttendSeq.cl(cards);
	            get.HSF("checkfellow");
	            "step 12"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 13"
	            //使用后事件
	            ui.clear();
	            get.HSF("event", ["useCardAfter", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 14"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 15"
	            if (event.hs_guosheng) player.hs_gain("法力过剩");
	            "step 16"
	            get.HSF("think");
	        },
	        hs_use_weapon: function() { //使用武器
	            "step 0"
	            get.HSF("clickmana", [false]);
	            event.usingcost = cards[0].cost();
	            player.HSF("usemana", [event.usingcost]);
	            game.log(player, "使用了", card);
	            var info = get.info(card);
	            var info2 = info.weaponeffect;
	            var name = card.name;
	            if (info2 && info2.battleRoal) {
	                event.hasbattleroal = true;
	                event.canzh = true;
	                if (info2.battleRoal.BRfilter && !info2.battleRoal.BRfilter(null, player)) event.canzh = false;
	                if (info2.battleRoal.filter) {
	                    var nf = get.HSF("strfil", [info2.battleRoal.filter]);
	                    info2.battleRoal.filter = nf;
	                    if (!nf(player, cards[0])) event.canzh = false;
	                }
	                if (info2.battleRoal.filterTarget) {
	                    event.needtarget = true;
	                    event.canzhtg = game.filterPlayer(function(target) {
	                        return player.HSF("canbetarget", [null, target, "battleroal"]) && info2.battleRoal.filterTarget(card, player, target);
	                    });
	                    if (event.canzhtg.length == 0) event.canzh = false;
	                }
	            }
	            event.cinfo = info;
	            event.info2 = info2;
	            if (info.active && info.active(player)) event.active = true;
	            player.lose(cards, ui.special);
	            event.node = player.$throw(cards, 1000);
	            game.delay(0.5);
	            "step 1"
	            get.HSF("checkhand");
	            if (event.node) event.node.delete();
	            "step 2"
	            //武器进场
	            get.HSF("morefocus", cards);
	            var c = cards[0];
	            event.div = player.addweapon(c);
	            player.predata_weapon = event.div;
	            _status.hsAttendSeq.ad(c);
	            "step 3"
	            game.delay();
	            "step 4"
	            player.hs_state.useCard++;
	            player.actionHistory[player.actionHistory.length - 1].useCard.push(event);
	            if (!game.getGlobalHistory()
	                .useCard) game.getGlobalHistory()
	                .useCard = [];
	            game.getGlobalHistory()
	                .useCard.push(event);
	            if (player.stat[player.stat.length - 1].card[card.name] == undefined) {
	                player.stat[player.stat.length - 1].card[card.name] = 1;
	            } else {
	                player.stat[player.stat.length - 1].card[card.name]++;
	            }
	            event.div.hs_yin();
	            "step 5"
	            //战吼选目标
	            if (event.div.triggers.battleRoal) {
	                if (event.needtarget && event.canzh) {
	                    var info = event.info2;
	                    var tgs = event.canzhtg;
	                    if (tgs.contains(game.me)) get.HSF("clickmana", [false]);
	                    var next = player.chooseTarget((info.prompt || get.HSF("prompt", [card])), function(card, player, target) {
	                        return tgs.contains(target);
	                    }, true);
	                    next.set("pl", player);
	                    var ai = () => 1;
	                    if (info.battleRoal.aifamily) {
	                        switch (info.battleRoal.aifamily) {
	                            case "damage":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    return get.dmgEffect(target, player, player) + 0.1;
	                                };
	                                break;
	                            case "recover":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    return get.rcvEffect(target, player, player);
	                                };
	                                break;
	                            case "atk":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    if (target.summoned && !target.hasgjz("chongfeng")) return 0;
	                                    if (target.getLeader() != player) return 0;
	                                    return target.ATK == 0 ? 3 : target.ATK;
	                                };
	                            case "hp":
	                                ai = function(target) {
	                                    var player = _status.event.pl;
	                                    if (target.getLeader() != player) return 0;
	                                    return target.hp;
	                                };
	                            default:
	                        }
	                    }
	                    next.set("ai", ai);
	                }
	            } else event.goto(7);
	            "step 6"
	            if (event.hasbattleroal) {
	                if (event.canzh) {
	                    if (event.needtarget) {
	                        if (result.bool) {
	                            event.willzh = true;
	                            event.target = result.targets[0];
	                        } else event.willzh = false;
	                    } else event.willzh = true;
	                } else event.willzh = false;
	            }
	            "step 7"
	            //使用时事件
	            get.HSF("event", ["useCard", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 8"
	            //过载
	            if (event.cinfo.hs_gz) {
	                var num = event.cinfo.hs_gz;
	                player.addMark("hs_mana_owed", num, false);
	                game.log(player, "过载了", num, "个法力水晶");
	                player.HSF("updatemana");
	                get.HSF("event", ["overload", {
	                    player: player,
	                    card: card,
	                    cards: cards,
	                    num: num,
	                }]);
	            }
	            "step 9"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 10"
	            //战吼次数
	            if (event.div.triggers.battleRoal) {
	                event.zh_num = player.hasAuras("doublebattleroal") ? 2 : 1;
	                if (event.div.triggers.battleRoal.bonus) event.zh_num += event.div.triggers.battleRoal.bonus(player, event.div);
	                event.zhed = 0;
	            } else event.goto(14);
	            "step 11"
	            //重选目标
	            if (targets) get.HSF("event", ["useCardTo", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 12"
	            //战吼
	            event.div.animate("zhanhou");
	            if (event.willzh && (!target || target.HSF("alive", [true]))) {
	                var cancel = false;
	                var recheck = event.info2.battleRoal.recheck;
	                if (recheck) {
	                    if (typeof recheck == "string") {
	                        var arr = recheck.split(",");
	                        if (arr.length == 1) {
	                            var f = get.HSA("funcs")[arr[0]];
	                            if (f) recheck = f;
	                            else get.hs_alt("战吼recheck:", recheck);
	                        } else {
	                            var fs = arr.map(i => get.HSA("funcs")[i]);
	                            var ff = function(e, p, f) {
	                                return ff.fs.every(i => i(e, p, f));
	                            };
	                            ff.fs = fs;
	                            recheck = ff;
	                        }

	                    }
	                    if (!recheck(null, player, event.link, event.info.battleRoal)) cancel = true;
	                }
	                if (!cancel) event.toRun = event.div.hs_battleRoal(event.target, event.div.triggers.battleRoal);
	            }
	            "step 13"
	            event.zhed++;
	            if (event.zhed < event.zh_num) {
	                get.HSF("updateauras", [true]);
	                game.delay();
	                event.goto(12);
	            }
	            "step 14"
	            //摧毁旧武器
	            if (player.data_weapon) {
	                player.data_weapon.HSF("cuihui");
	                player.old_weapon = player.data_weapon;
	            }
	            delete player.predata_weapon;
	            player.data_weapon = event.div;
	            game.log(player, "装备了", card);
	            get.HSF("event", ["equipAfter", {
	                player: player,
	                div: event.div,
	                card: cards[0],
	            }]);
	            "step 15"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 16"
	            //使用后事件
	            get.HSF("event", ["useCardAfter", {
	                player: player,
	                card: card,
	                cards: cards,
	                target: target,
	                targets: targets,
	            }]);
	            "step 17"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 18"
	            get.HSF("think");
	        },
	        hs_use_heroskill: function() { //使用英雄技能
	            "step 0"
	            player.hs_state.hrsk++;
	            if (!event.filterTarget) event.goto(3);
	            if (event.randomHT) {
	                var t = event.randomHT(player);
	                event.target = t;
	                if (!event.target) event.finish();
	            }
	            "step 1"
	            //英雄技能选目标
	            var fil = event.filterTarget;
	            player.chooseTarget(get.prompt2(event.skill), function(c, p, t) {
	                return p.HSF('canbetarget', [null, t, 'heroskill']) && fil(null, p, t);
	            })
	                .set('ai', event.ai);
	            "step 2"
	            if (result.bool && result.targets[0]) event.target = result.targets[0];
	            else event.finish();
	            "step 3"
	            get.HSF("morefocus", [player.heroskill]);
	            player.HSF("usemana", [event.cost]);
	            "step 4"
	            //重选目标
	            get.HSF("event", ["useHeroskillTo", {
	                player: player,
	                target: target,
	            }]);
	            "step 5"
	            //英雄技能结算
	            player.heroskill.using = true;
	            player.heroskill.used++;
	            "step 6"
	            setTimeout(function() {
	                player.heroskill.forceused = true;
	                get.HSF("checkheroskill");
	                setTimeout(function() {
	                    delete player.heroskill.forceused;
	                    get.HSF("checkheroskill");
	                }, 500);
	            }, 1000);
	            player.logSkill(event.skill, target, false);
	            player.heroskill.pos.HSline(target, "green");
	            player.hs_heroskillEffect(target, get.info(event.skill)
	                .effect);
	            "step 7"
	            delete player.heroskill.using;
	            "step 8"
	            game.delay();
	            "step 9"
	            //激励
	            get.HSF("jilievent", [{
	                player: player,
	                target: target,
	            }]);
	            "step 10"
	            //死亡阶段
	            get.HSF("checkdeath");
	            "step 11"
	            get.HSF("think");
	        },
	        hs_dmgrcvbt: function() { //战斗伤害
	            "step 0"
	            event.i = 0;
	            event.evnum = event.evts.length;
	            game.delay(2);
	            "step 1"
	            event.cur = event.evts[event.i];
	            event.source = event.cur.source;
	            event.player = event.cur.player;
	            event.num = event.cur.num;
	            "step 2"
	            _status.hs_noupdate = true;
	            "step 3"
	            //伤害步骤开始
	            if (player.hasgjz("mianyi")) {
	                game.log(player, "的免疫抵消了", event.num, "点伤害");
	                event.num = 0;
	            }
	            if (event.num <= 0) event.goto(11);
	            "step 4"
	            //预伤害扳机1
	            //改变目标
	            get.HSF("event", ["hsdmgBefore", {
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 5"
	            if (player.hasgjz("mianyi")) {
	                game.log(player, "的免疫抵消了", event.num, "点伤害");
	                event.num = 0;
	                event.goto(11);
	            } else {
	                //预伤害扳机2
	                //改变伤害量
	                get.HSF("event", ["hsdmgBegin1", {
	                    player: player,
	                    source: event.source,
	                    num: event.num,
	                }]);
	            }
	            "step 6"
	            //预伤害扳机3
	            //防止伤害
	            get.HSF("event", ["hsdmgBegin2", {
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 7"
	            event.cur.num = event.num;
	            if (player.hasgjz("shengdun")) {
	                player.removegjz("shengdun");
	                game.log(player, "的圣盾抵消了", event.num, "点伤害");
	                event.cur.shengdun = true;
	                event.goto(11);
	            }
	            "step 8"
	            //伤害结算
	            event.change = (function(e, p) {
	                var n = -1 * e.num;
	                var max = p.maxHp;
	                var hp = p.hp;
	                var hj = p.hujia;
	                var zz = Math.min(0, hj + n);
	                if (p.aurasEffed("hs_mlnh")) {
	                    if (zz + hj + hp < 1) {
	                        var cg = 1 - hj - hp - zz;
	                        e.num -= cg;
	                        zz = 1 - hj - hp;
	                    }
	                }
	                return zz;
	            })(event, player);
	            var obj = {
	                num: event.num,
	                type: "damage",
	                player: player,
	                source: event.source,
	            };
	            obj.player[obj.type](obj.source, obj.num)
	                .hs_dmgrcv = true;
	            "step 9"
	            //伤害抖动
	            _status.hs_noupdate = false;
	            player.updatehsfl(event.change);
	            "step 10"
	            var sc = event.source;
	            if (event.num > 0 && sc && sc.hasgjz("qianxing")) sc.removegjz("qianxing");
	            "step 11"
	            event.i++;
	            if (event.i < event.evnum) event.goto(1);
	            "step 12"
	            event.evts = event.evts.filter(i => i.num > 0 && !i.shengdun);
	            if (event.evts.length) {
	                //结算伤害事件
	                get.HSF("evts", ["hsdmg", event.evts]);
	            }
	            "step 13"
	            //清除状态
	            _status.hs_noupdate = false;
	            get.HSF("checkfellow");
	        },
	        hs_dmgrcvaoe: function() { //aoe伤害&&回复
	            "step 0"
	            event.i = 0;
	            event.evts = [];
	            event.evnum = event.targets.length;
	            //nosort:特殊顺序aoe
	            if (!event.nosort) event.targets.sort(lib.sort.attendseq);
	            _status.hs_noupdate = true;
	            if (event.nodelay) game.delay(0.5);
	            else game.delay(2);
	            "step 1"
	            event.target = event.targets[event.i];
	            event.cur = {
	                card: event.card,
	                type: event.type,
	                source: event.source,
	                player: event.target,
	                num: event.num,
	                nature: event.nature,
	            };
	            if (event.expo && event.expo[0] == event.target) {
	                event.cur.num = event.expo[1];
	                event.cur.expo = true;
	                delete event.expo;
	            }
	            event.player = event.cur.player;
	            event.evts.add(event.cur);
	            "step 2"
	            event.orinum = event.num;
	            //奥金尼
	            if (event.type == "recover" && event.source && event.source.getLeader()
	                .hasAuras("auchenai")) event.cur.type = "damage";
	            "step 3"
	            //伤害增减阶段
	            if (event.cur.type == "damage" && card && get.type(card) == "HS_spell" && event.source) {
	                var res = event.source.countFq();
	                event.cur.num += res;
	            }
	            "step 4"
	            //伤害翻倍阶段
	            if ((event.card && get.type(event.card) == "HS_spell" || event.hs_heroskill) && event.source && event.source.hasAuras("velen")) {
	                event.cur.num *= event.source.HSF("countvelen");
	            }
	            "step 5"
	            //伤害步骤开始
	            if (event.cur.type == "damage" && player.hasgjz("mianyi")) {
	                game.log(player, "的免疫抵消了", event.cur.num, "点伤害");
	                event.cur.num = 0;
	            }
	            if (event.cur.num <= 0) event.goto(11);
	            "step 6"
	            //预伤害扳机1
	            //改变目标
	            if (event.type == "damage") get.HSF("event", ["hsdmgBefore", {
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 7"
	            if (player.hasgjz("mianyi")) {
	                game.log(player, "的免疫抵消了", event.num, "点伤害");
	                event.cur.num = 0;
	                event.goto(11);
	            } else {
	                //预伤害扳机2
	                //改变伤害量
	                if (event.type == "damage") get.HSF("event", ["hsdmgBegin1", {
	                    player: player,
	                    source: event.source,
	                    num: event.num,
	                }]);
	            }
	            "step 8"
	            //预伤害扳机3
	            //防止伤害
	            if (event.type == "damage") get.HSF("event", ["hsdmgBegin2", {
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 9"
	            if (event.cur.type == "damage" && player.hasgjz("shengdun")) {
	                player.removegjz("shengdun");
	                game.log(player, "的圣盾抵消了", event.cur.num, "点伤害");
	                event.cur.shengdun = true;
	                event.goto(11);
	            }
	            "step 10"
	            //伤害结算
	            event.cur.change = (function(e, p) {
	                var bo = e.cur.type == "recover";
	                var n = (bo ? 1 : -1) * e.cur.num;
	                var max = p.maxHp;
	                var hp = p.hp;
	                var hj = p.hujia;
	                if (bo) return Math.min(n, max - hp);
	                else {
	                    var zz = Math.min(0, hj + n);
	                    if (p.aurasEffed("hs_mlnh")) {
	                        if (zz + hj + hp < 1) {
	                            var cg = 1 - hj - hp - zz;
	                            e.num -= cg;
	                            zz = 1 - hj - hp;
	                        }
	                    }
	                    return zz;
	                }
	            })(event, player);
	            if (event.cur.change != 0) event.cur.cantri = true;
	            "step 11"
	            event.i++;
	            if (event.i < event.evnum) event.goto(1);
	            "step 12"
	            event.evts = event.evts.filter(i => i.cantri);
	            if (event.evts.length) get.HSF("dmgrcvdh", [event.evts]);
	            "step 13"
	            if (event.evts.length) {
	                //结算伤害事件
	                var n = "hs" + (event.evts[0].type == "damage" ? "dmg" : "rcv");
	                get.HSF("evts", [n, event.evts]);
	            }
	            "step 14"
	            //清除状态
	            _status.hs_noupdate = false;
	            get.HSF("checkfellow");
	        },
	        hs_dmgrcv: function() { //伤害&&回复
	            "step 0"
	            _status.hs_noupdate = true;
	            //奥金尼
	            if (event.type == "recover" && event.source && event.source.getLeader()
	                .hasAuras("auchenai")) event.type = "damage";
	            "step 1"
	            //伤害增减阶段
	            if (event.type == "damage" && card && get.type(card) == "HS_spell" && event.source) {
	                var res = event.source.countFq();
	                event.num += res;
	            }
	            "step 2"
	            //伤害翻倍阶段
	            if ((event.card && get.type(event.card) == "HS_spell" || event.hs_heroskill) && event.source && event.source.hasAuras("velen")) {
	                event.num *= event.source.HSF("countvelen");
	            }
	            "step 3"
	            //伤害步骤开始
	            if (event.type == "damage" && player.hasgjz("mianyi")) {
	                game.log(player, "的免疫抵消了", event.num, "点伤害");
	                event.num = 0;
	            }
	            if (event.num <= 0) event.goto(13);
	            "step 4"
	            //预伤害扳机1
	            //改变目标
	            if (event.type == "damage") get.HSF("event", ["hsdmgBefore", {
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 5"
	            if (player.hasgjz("mianyi")) {
	                game.log(player, "的免疫抵消了", event.num, "点伤害");
	                event.num = 0;
	                event.goto(13);
	            } else {
	                //预伤害扳机2
	                //改变伤害量
	                if (event.type == "damage") get.HSF("event", ["hsdmgBegin1", {
	                    player: player,
	                    source: event.source,
	                    num: event.num,
	                }]);
	            }
	            "step 6"
	            //预伤害扳机3
	            //防止伤害
	            if (event.type == "damage") get.HSF("event", ["hsdmgBegin2", {
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 7"
	            if (event.fangzhi) event.goto(13);
	            game.delay(0.7);
	            "step 8"
	            if (event.type == "damage" && player.hasgjz("shengdun")) {
	                player.removegjz("shengdun");
	                game.log(player, "的圣盾抵消了", event.num, "点伤害");
	                event.shengdun = true;
	                event.goto(11);
	            }
	            "step 9"
	            //伤害结算
	            if (player.hs_losing) event.goto(13);
	            if (event.num == 0) event.goto(11);
	            else {
	                event.change = (function(e, p) {
	                    var bo = e.type == "recover";
	                    var n = (bo ? 1 : -1) * e.num;
	                    var max = p.maxHp;
	                    var hp = p.hp;
	                    var hj = p.hujia;
	                    if (bo) return Math.min(n, max - hp);
	                    else {
	                        var zz = Math.min(0, hj + n);
	                        if (p.aurasEffed("hs_mlnh")) {
	                            if (zz + hj + hp < 1) {
	                                var cg = 1 - hj - hp - zz;
	                                e.num -= cg;
	                                zz = 1 - hj - hp;
	                            }
	                        }
	                        return zz;
	                    }
	                })(event, player);
	                var obj = {
	                    num: event.num,
	                    type: event.type,
	                    player: event.player,
	                    source: event.nosource ? undefined : event.source,
	                    nature: event.nature,
	                };
	                obj.player[obj.type](obj.source, obj.num, obj.nature)
	                    .hs_dmgrcv = true;
	            }
	            "step 10"
	            //伤害抖动
	            _status.hs_noupdate = false;
	            if (event.change != 0) event.cantri = true;
	            player.updatehsfl(event.change);
	            "step 11"
	            var sc = event.source;
	            if (event.type == "damage" && event.num > 0 && sc && sc.hasgjz("qianxing")) sc.removegjz("qianxing");
	            if (event.炸服 (evt => evt.player.hp < -30)) return;
	            "step 12"
	            //伤害事件
	            if (event.cantri) get.HSF("event", ["hs" + (event.type == "damage" ? "dmg" : "rcv"), {
	                card: event.card,
	                player: player,
	                source: event.source,
	                num: event.num,
	            }]);
	            "step 13"
	            //清除状态
	            _status.hs_noupdate = false;
	            get.HSF("checkfellow");
	        },
	    };
	    for (var i in cardE) {
	        hearthstone.card[i] = cardE[i];
	    }
	    for (var i in conE) {
	        hearthstone.content[i] = conE[i];
	    }
	    hearthstone.eventjsloaded = true;
	    hearthstone.custom = {}; //编辑卡组自定义变量
	    hearthstone.ranvv = {}; //自定义变量
	});